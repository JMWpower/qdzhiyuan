const API = '/api/music'
const PLATFORMS = [
  {id: 'wy', name: '网易云音乐', logo: './ico/网易云.png', disabled: false},
  {id: 'kg', name: '酷狗音乐', logo: './ico/酷狗.png', disabled: false},
  {id: 'kw', name: '酷我音乐', logo: './ico/酷我.png', disabled: false},
  {id: 'tx', name: 'QQ 音乐', logo: './ico/QQ.png', disabled: false},
  {id: 'mg', name: '咪咕音乐', logo: './ico/咪咕.png', disabled: false},
  {id: 'qs', name: '汽水音乐', logo: './ico/汽水.png', disabled: false}
]

let currentPlatform = 'wy'
let currentTab = 'recommend'
let searchPage = 1
let searchKeyword = ''
let playlist = []
let playIndex = -1
let isPlaying = false
let lyricLines = []
let lyricTimestamps = []
let enableAutoProxy = true

let currentPlayUrls = []
let currentUrlIndex = 0
let durationChecked = false
let playMode = 'sequential'
let currentLyric = null
let lyricFontSize = 'medium'
let lyricColor = '#1db954'
let lyricShowTrans = true
let searchMode = 'song'
let searchSongList = []
let songlistData = []
let searchSonglistList = []
let searchSonglistHtmlCache = ''
let searchSonglistPagCache = ''
let playlistDetailSource = ''
let previousTab = 'recommend'
let previousTabHtmlCache = ''
let searchSongCache = { keyword: '', source: '', page: 0, data: null }
let searchSonglistCache = { keyword: '', source: '', page: 0, data: null }
let tabCache = {}
let leaderboardList = []
let leaderboardDetailCache = {}
let currentLeaderboardId = ''
let leaderboardPlatform = ''

// DOM 元素
const audio = document.getElementById('audio')
const $content = document.getElementById('content')
const $recommendBody = document.getElementById('recommend-body')
const $leaderboardBody = document.getElementById('leaderboard-body')
const $searchBody = document.getElementById('search-body')
const $searchPagination = document.getElementById('search-pagination')
const $searchToolbar = document.getElementById('search-toolbar')
const $modeBtnSong = document.getElementById('mode-btn-song')
const $modeBtnSonglist = document.getElementById('mode-btn-songlist')
const $platformLogo = document.getElementById('platform-logo')
const $platformName = document.getElementById('platform-name')
const $searchInput = document.getElementById('search-input')
const $searchTag = document.getElementById('search-tag')
const $searchTagText = document.getElementById('search-tag-text')
const $searchSettingsPanel = document.getElementById('search-settings-panel')
const $searchInputM = document.getElementById('search-input-m')
const $searchTagM = document.getElementById('search-tag-m')
const $searchTagTextM = document.getElementById('search-tag-text-m')
const $searchSettingsPanelM = document.getElementById('search-settings-panel-m')
const $playerSong = document.getElementById('player-song')
const $playerSinger = document.getElementById('player-singer')
const $playerCoverImg = document.getElementById('player-cover-img')
const $playerCoverPlaceholder = document.getElementById('player-cover-placeholder')
const $progressFill = document.getElementById('progress-fill')
const $timeCur = document.getElementById('time-cur')
const $timeTotal = document.getElementById('time-total')
const $playlistPanel = document.querySelector('.playlist-panel')
const $playlistBody = document.getElementById('playlist-body')
const $plCount = document.getElementById('pl-count')
const $btnPlay = document.getElementById('btn-play')
const $modalOverlay = document.getElementById('modal-overlay')
const $platformModalOverlay = document.getElementById('platform-modal-overlay')
const $platformGrid = document.getElementById('platform-grid')
const $themeBtn = document.getElementById('theme-btn')

// 移动端播放栏元素
const $playerSongM = document.getElementById('player-song-m')
const $playerCoverImgM = document.getElementById('player-cover-img-m')
const $playerCoverPlaceholderM = document.getElementById('player-cover-placeholder-m')
const $progressFillM = document.getElementById('progress-fill-m')
const $timeCurM = document.getElementById('time-cur-m')
const $timeTotalM = document.getElementById('time-total-m')
const $btnPlayM = document.getElementById('btn-play-m')

// 搜索设置
let searchSource = 'wy'
const SOURCE_NAMES = {
  wy: '网易', kg: '酷狗', kw: '酷我', tx: 'QQ', mg: '咪咕', qs: '汽水'
}
const SOURCE_TAG_COLORS = {
  wy: '#e60026', kg: '#2ca2f9', kw: '#f09a37', tx: '#31c27c', mg: '#ff7600', qs: '#ff4757'
}
function sourceTag(source) {
  const name = SOURCE_NAMES[source]
  if (!name) return ''
  const color = SOURCE_TAG_COLORS[source] || '#9ca3af'
  return `<span class="source-badge" style="--badge-color:${color}">${name}</span>`
}
function escapeHtml(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

// 主题设置
let isLightMode = false

// 初始化
function init() {
  initTheme()
  updatePlatformDisplay()
  renderPlatformGrid()
  initSearchSettings()
  bindEvents()
  audio.volume = 0.8
  loadPlaylistFromStorage()
  showTab('recommend')
}

// 更新平台显示
function updatePlatformDisplay() {
  const platform = PLATFORMS.find(p => p.id === currentPlatform)
  if (platform) {
    $platformName.textContent = platform.name
    const logoImg = document.getElementById('platform-logo-img')
    if (logoImg) {
      logoImg.src = platform.logo
      logoImg.alt = platform.name
    }
    const logoImgM = document.getElementById('platform-logo-img-m')
    if (logoImgM) {
      logoImgM.src = platform.logo
      logoImgM.alt = platform.name
    }
  }
}

// 搜索设置初始化
function initSearchSettings() {
  updateSearchDisplay()
  
  $searchTag.addEventListener('click', (e) => {
    e.stopPropagation()
    $searchSettingsPanel.classList.toggle('hidden')
  })
  
  if ($searchTagM) {
    $searchTagM.addEventListener('click', (e) => {
      e.stopPropagation()
      if ($searchSettingsPanelM) $searchSettingsPanelM.classList.toggle('hidden')
    })
  }
  
  document.querySelectorAll('.search-source-tag').forEach(tag => {
    tag.addEventListener('click', (e) => {
      e.stopPropagation()
      searchSource = tag.dataset.source
      updateSearchDisplay()
      updateSearchSourceTags()
    })
  })
  
  document.addEventListener('click', () => {
    $searchSettingsPanel.classList.add('hidden')
    if ($searchSettingsPanelM) $searchSettingsPanelM.classList.add('hidden')
  })
  
  $searchSettingsPanel.addEventListener('click', (e) => {
    e.stopPropagation()
  })
  
  if ($searchSettingsPanelM) {
    $searchSettingsPanelM.addEventListener('click', (e) => {
      e.stopPropagation()
    })
  }
  
  updateSearchSourceTags()
}

// 更新搜索显示
function updateSearchDisplay() {
  $searchTagText.textContent = SOURCE_NAMES[searchSource]
  if ($searchTagTextM) $searchTagTextM.textContent = SOURCE_NAMES[searchSource]
}

// 更新搜索平台标签
function updateSearchSourceTags() {
  document.querySelectorAll('.search-source-tag').forEach(tag => {
    if (tag.dataset.source === searchSource) {
      tag.classList.add('bg-primary', 'text-white')
      tag.classList.remove('search-source-inactive')
    } else {
      tag.classList.remove('bg-primary', 'text-white')
      tag.classList.add('search-source-inactive')
    }
  })
}

// 主题切换
function toggleTheme() {
  isLightMode = !isLightMode
  document.body.classList.toggle('light-mode', isLightMode)
  try { localStorage.setItem('theme', isLightMode ? 'light' : 'dark') } catch (e) {}
}

function initTheme() {
  try {
    const saved = localStorage.getItem('theme')
    if (saved === 'light') {
      isLightMode = true
      document.body.classList.add('light-mode')
    }
  } catch (e) {}
}

// 渲染平台选择网格
function renderPlatformGrid() {
  $platformGrid.innerHTML = PLATFORMS.map(p => {
    const isCurrent = p.id === currentPlatform
    const isDisabled = p.disabled === true
    
    return `
      <div class="platform-option ${isCurrent ? 'active' : ''} ${isDisabled ? 'disabled' : ''}" data-platform="${p.id}" style="${isDisabled ? 'opacity: 0.5; cursor: not-allowed;' : ''}">
        <div class="platform-option-icon">
          <img src="${p.logo}" alt="${p.name}" class="w-full h-full object-cover">
        </div>
        <div class="flex-1 min-w-0">
          <div class="font-bold text-lg whitespace-nowrap">${p.name}</div>
          <div class="text-xs platform-option-desc">${isCurrent ? '当前选中主页' : (isDisabled ? '暂未开放' : '点击设为主页')}</div>
        </div>
        ${isCurrent ? '<i class="fas fa-check-circle text-primary text-xl"></i>' : ''}
      </div>
    `
  }).join('')
  
  $platformGrid.querySelectorAll('.platform-option:not(.disabled)').forEach(option => {
    option.addEventListener('click', () => {
      currentPlatform = option.dataset.platform
      searchSource = currentPlatform
      updatePlatformDisplay()
      updateSearchDisplay()
      updateSearchSourceTags()
      renderPlatformGrid()
      showTab(currentTab)
      $platformModalOverlay.classList.add('hidden')
      savePlaylistToStorage()
    })
  })
}

// 绑定事件
function bindEvents() {
  // 平台 Logo 点击
  $platformLogo.addEventListener('click', () => {
    $platformModalOverlay.classList.remove('hidden')
  })
  
  const $platformLogoM = document.getElementById('platform-logo-m')
  if ($platformLogoM) {
    $platformLogoM.addEventListener('click', () => {
      $platformModalOverlay.classList.remove('hidden')
    })
  }
  
  // 平台模态框关闭
  document.getElementById('platform-modal-close').addEventListener('click', () => {
    $platformModalOverlay.classList.add('hidden')
  })
  
  // 工具按钮
  document.getElementById('tool-btn').addEventListener('click', () => {
    $modalOverlay.classList.remove('hidden')
  })
  
  const $toolBtnM = document.getElementById('tool-btn-m')
  if ($toolBtnM) {
    $toolBtnM.addEventListener('click', () => {
      $modalOverlay.classList.remove('hidden')
    })
  }
  
  // 模态框关闭
  document.getElementById('modal-close').addEventListener('click', () => {
    $modalOverlay.classList.add('hidden')
  })
  
  // 模态框点击背景关闭
  $modalOverlay.addEventListener('click', (e) => {
    if (e.target === $modalOverlay) {
      $modalOverlay.classList.add('hidden')
    }
  })
  
  $platformModalOverlay.addEventListener('click', (e) => {
    if (e.target === $platformModalOverlay) {
      $platformModalOverlay.classList.add('hidden')
    }
  })
  
  // Tab 切换
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = btn.dataset.tab
      showTab(tab)
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === tab))
      document.querySelectorAll('.tab-btn-m').forEach(b => b.classList.toggle('active', b.dataset.tab === tab))
    })
  })
  
  document.querySelectorAll('.tab-btn-m').forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = btn.dataset.tab
      showTab(tab)
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === tab))
      document.querySelectorAll('.tab-btn-m').forEach(b => b.classList.toggle('active', b.dataset.tab === tab))
    })
  })
  
  // 主题切换
  if ($themeBtn) $themeBtn.addEventListener('click', toggleTheme)
  const $themeBtnM = document.getElementById('theme-btn-m')
  if ($themeBtnM) $themeBtnM.addEventListener('click', toggleTheme)
  
  // 回到顶部
  const backToTopBtn = document.getElementById('back-to-top')
  const mainContent = document.getElementById('main-content')
  if (mainContent && backToTopBtn) {
    mainContent.addEventListener('scroll', () => {
      if (!document.querySelector('.lb-main') || !document.querySelector('.lb-layout')) {
        backToTopBtn.classList.toggle('visible', mainContent.scrollTop > 300)
      }
    })
    backToTopBtn.addEventListener('click', () => {
      const lbMain = document.querySelector('.lb-main')
      if (lbMain && lbMain.scrollTop > 300) {
        lbMain.scrollTo({ top: 0, behavior: 'smooth' })
      } else {
        mainContent.scrollTo({ top: 0, behavior: 'smooth' })
      }
    })
  }
  
  // 搜索
  $searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const keyword = $searchInput.value.trim()
      if ($searchInputM) $searchInputM.value = keyword
      doSearch(keyword)
    }
  })
  
  if ($searchInputM) {
    $searchInputM.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const keyword = $searchInputM.value.trim()
        $searchInput.value = keyword
        doSearch(keyword)
      }
    })
  }
  
  document.querySelector('.topbar-pc .search-btn').addEventListener('click', () => {
    const keyword = $searchInput.value.trim()
    if ($searchInputM) $searchInputM.value = keyword
    doSearch(keyword)
  })
  
  const $searchBtnM = document.getElementById('search-btn-m')
  if ($searchBtnM) {
    $searchBtnM.addEventListener('click', () => {
      const keyword = $searchInputM ? $searchInputM.value.trim() : ''
      $searchInput.value = keyword
      doSearch(keyword)
    })
  }
  
  // 播放控制
  const btnPlay = document.getElementById('btn-play')
  const btnPrev = document.getElementById('btn-prev')
  const btnNext = document.getElementById('btn-next')
  const btnPlaylist = document.getElementById('btn-playlist')
  const btnVisualizer = document.getElementById('btn-visualizer')
  
  if (btnPlay) btnPlay.addEventListener('click', togglePlay)
  if (btnPrev) btnPrev.addEventListener('click', playPrev)
  if (btnNext) btnNext.addEventListener('click', playNext)
  
  const btnMode = document.getElementById('btn-mode')
  if (btnMode) btnMode.addEventListener('click', () => {
    const modes = ['sequential', 'loop', 'random']
    const labels = { sequential: '顺序播放', loop: '单曲循环', random: '随机播放' }
    const icons = { sequential: 'fa-repeat', loop: 'fa-rotate-right', random: 'fa-shuffle' }
    const idx = modes.indexOf(playMode)
    playMode = modes[(idx + 1) % modes.length]
    btnMode.innerHTML = `<i class="fas ${icons[playMode]}"></i>`
    btnMode.title = labels[playMode]
    btnMode.classList.toggle('text-primary', playMode !== 'sequential')
    showToast(labels[playMode])
    
    const btnModeM = document.getElementById('btn-mode-m')
    if (btnModeM) {
      btnModeM.innerHTML = `<i class="fas ${icons[playMode]} text-sm"></i>`
    }
  })
  
  if (btnPlaylist) btnPlaylist.addEventListener('click', () => {
    togglePlaylistPanel()
  })
  
  // 移动端播放栏控制
  const btnPlayM = document.getElementById('btn-play-m')
  const btnPrevM = document.getElementById('btn-prev-m')
  const btnNextM = document.getElementById('btn-next-m')
  const btnPlaylistM = document.getElementById('btn-playlist-m')
  const btnModeM = document.getElementById('btn-mode-m')
  
  if (btnPlayM) btnPlayM.addEventListener('click', togglePlay)
  if (btnPrevM) btnPrevM.addEventListener('click', playPrev)
  if (btnNextM) btnNextM.addEventListener('click', playNext)
  if (btnPlaylistM) btnPlaylistM.addEventListener('click', togglePlaylistPanel)
  if (btnModeM) btnModeM.addEventListener('click', () => {
    if (btnMode) btnMode.click()
  })
  
  // 移动端进度条
  const progressBarMiniM = document.getElementById('progress-bar-mini-m')
  if (progressBarMiniM) progressBarMiniM.addEventListener('click', (e) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const pct = (e.clientX - rect.left) / rect.width
    if (audio.duration) audio.currentTime = pct * audio.duration
  })
  
  try {
    const savedFontSize = localStorage.getItem('lyricFontSize')
    const savedColor = localStorage.getItem('lyricColor')
    const savedTrans = localStorage.getItem('lyricShowTrans')
    if (savedFontSize) { lyricFontSize = savedFontSize }
    if (savedColor) { lyricColor = savedColor }
    if (savedTrans !== null) { lyricShowTrans = savedTrans === 'true' }
  } catch(e) {}
  
  document.querySelectorAll('#lyric-font-size-options .fs-setting-opt').forEach(b => {
    b.classList.toggle('active', b.dataset.value === lyricFontSize)
  })
  document.querySelectorAll('#lyric-color-options .fs-color-opt').forEach(b => {
    b.classList.toggle('active', b.dataset.value === lyricColor)
  })
  const $lyricTransOn = document.getElementById('lyric-trans-on')
  const $lyricTransOff = document.getElementById('lyric-trans-off')
  if ($lyricTransOn) $lyricTransOn.classList.toggle('active', lyricShowTrans)
  if ($lyricTransOff) $lyricTransOff.classList.toggle('active', !lyricShowTrans)
  const playlistClose = document.querySelector('.playlist-close')
  if (playlistClose) playlistClose.addEventListener('click', () => {
    closePlaylistPanel()
  })

  // 清空播放列表确认模态框事件
  const clearPlModal = document.getElementById('clear-playlist-modal-overlay')
  const clearPlCancelBtn = document.getElementById('clear-pl-cancel-btn')
  const clearPlConfirmBtn = document.getElementById('clear-pl-confirm-btn')
  if (clearPlModal) {
    clearPlModal.addEventListener('click', (e) => {
      if (e.target === clearPlModal) clearPlModal.classList.add('hidden')
    })
  }
  if (clearPlCancelBtn) clearPlCancelBtn.addEventListener('click', () => {
    clearPlModal.classList.add('hidden')
  })
  if (clearPlConfirmBtn) clearPlConfirmBtn.addEventListener('click', () => {
    clearPlModal.classList.add('hidden')
    doClearPlaylist()
  })
  if (btnVisualizer) btnVisualizer.addEventListener('click', () => {
    const visualizerPanel = document.querySelector('.visualizer-panel')
    if (visualizerPanel) {
      visualizerPanel.classList.toggle('hidden')
      if (!visualizerPanel.classList.contains('hidden')) {
        initVisualizer()
      }
    }
  })
  const visualizerClose = document.querySelector('.visualizer-close')
  if (visualizerClose) visualizerClose.addEventListener('click', () => {
    const visualizerPanel = document.querySelector('.visualizer-panel')
    if (visualizerPanel) visualizerPanel.classList.add('hidden')
  })
  
  // 进度条
  const progressBarMini = document.getElementById('progress-bar-mini')
  if (progressBarMini) progressBarMini.addEventListener('click', (e) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const pct = (e.clientX - rect.left) / rect.width
    if (audio.duration) audio.currentTime = pct * audio.duration
  })
  
  // 音量
  const volumeSlider = document.getElementById('volume-slider')
  const btnVolume = document.getElementById('btn-volume')
  if (volumeSlider) {
    volumeSlider.addEventListener('input', () => {
      audio.volume = volumeSlider.value / 100
      updateVolumeIcon()
    })
  }
  if (btnVolume) btnVolume.addEventListener('click', () => {
    audio.muted = !audio.muted
    updateVolumeIcon()
  })
  // 代理
  const proxyCheckbox = document.getElementById('proxy-checkbox')
  if (proxyCheckbox) {
    proxyCheckbox.addEventListener('change', function() {
      enableAutoProxy = this.checked
      try { localStorage.setItem('rc_enable_auto_proxy', this.checked ? '1' : '0') } catch (e) {}
    })
    
    try {
      const saved = localStorage.getItem('rc_enable_auto_proxy')
      if (saved !== null) {
        enableAutoProxy = saved === '1'
        proxyCheckbox.checked = enableAutoProxy
      } else {
        enableAutoProxy = true
        proxyCheckbox.checked = true
      }
    } catch (e) {
      enableAutoProxy = true
      proxyCheckbox.checked = true
    }
  }
  
  // 音频事件
  audio.addEventListener('timeupdate', onTimeUpdate)
  audio.addEventListener('loadedmetadata', checkDurationAndSwitch)
  audio.addEventListener('durationchange', checkDurationAndSwitch)
  audio.addEventListener('canplay', function onCanPlay() {
    if (!durationChecked) checkDurationAndSwitch()
  })
  audio.addEventListener('ended', () => {
    if (playMode === 'loop') {
      audio.currentTime = 0
      audio.play()
    } else {
      playNext()
    }
  })
  audio.addEventListener('error', () => {
    currentUrlIndex++
    if (currentUrlIndex < currentPlayUrls.length) {
      console.log(`[Player] 播放链接失败，尝试第 ${currentUrlIndex + 1}/${currentPlayUrls.length} 个`)
      tryPlayUrl(currentPlayUrls[currentUrlIndex])
    } else {
      console.log('[Player] 所有播放链接均失败')
      isPlaying = false
      updatePlayBtn()
      updateFullscreenPlayer()
      if (playlist.length > 1) {
        $playerSinger.textContent = '播放失败 - 跳过'
        setTimeout(playNext, 1500)
      } else {
        $playerSinger.textContent = '播放失败'
      }
    }
  })
  
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const fsPlayer = document.getElementById('fullscreen-player')
      if (fsPlayer && !fsPlayer.classList.contains('hidden')) {
        closeFullscreenPlayer()
      }
    }
  })
  
  document.getElementById('fs-lyric-body').addEventListener('click', (e) => {
    const line = e.target.closest('.lyric-line:not(.lyric-trans)')
    if (line && currentLyric) {
      const idx = parseInt(line.dataset.index)
      if (!isNaN(idx) && currentLyric[idx]) {
        audio.currentTime = currentLyric[idx].time
      }
    }
  })
}

// 显示 Tab
function showTab(tab) {
  currentTab = tab
  
  document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none')
  document.getElementById('tab-loading').style.display = 'none'
  document.getElementById('tab-empty').style.display = 'none'
  
  const mainContent = document.getElementById('main-content')
  
  if (tab === 'search') {
    showSearch()
  } else if (tab === 'recommend') {
    const cacheKey = `recommend_${currentPlatform}`
    if (tabCache[cacheKey]) {
      $recommendBody.innerHTML = tabCache[cacheKey]
    } else {
      showRecommend()
    }
    document.getElementById('tab-recommend').style.display = ''
  } else if (tab === 'leaderboard') {
    if (leaderboardList.length > 0 && leaderboardPlatform === currentPlatform) {
      renderLeaderboardLayout()
    } else {
      showLeaderboard()
    }
    document.getElementById('tab-leaderboard').style.display = ''
  } else if (tab === 'songlist') {
    const cacheKey = `songlist_${currentPlatform}`
    if (tabCache[cacheKey]) {
      $leaderboardBody.innerHTML = tabCache[cacheKey]
    } else {
      showSonglist()
    }
    document.getElementById('tab-leaderboard').style.display = ''
  } else if (tab === 'parsed-songlist') {
    if (songlistData.length > 0) {
      renderSonglistTab(songlistData)
    }
    document.getElementById('tab-parsed-songlist').style.display = ''
  }
  
  if (mainContent) mainContent.scrollTop = 0
}

function togglePlaylistPanel() {
  const isOpen = $playlistPanel.classList.contains('translate-x-full')
  if (isOpen) {
    $playlistPanel.classList.remove('translate-x-full')
    document.getElementById('playlist-overlay').classList.remove('hidden')
  } else {
    closePlaylistPanel()
  }
}

function closePlaylistPanel() {
  $playlistPanel.classList.add('translate-x-full')
  document.getElementById('playlist-overlay').classList.add('hidden')
}

function clearPlaylistConfirm() {
  if (playlist.length === 0) return
  const modal = document.getElementById('clear-playlist-modal-overlay')
  const countEl = document.getElementById('clear-pl-count')
  if (countEl) countEl.textContent = playlist.length
  modal.classList.remove('hidden')
}

function doClearPlaylist() {
  playlist = []
  playIndex = -1
  currentPlayUrls = []
  currentUrlIndex = 0
  durationChecked = false
  currentLyric = null
  isPlaying = false
  audio.pause()
  audio.src = ''
  audio.load()
  renderPlaylist()
  $playerSong.textContent = '未播放'
  $playerSinger.textContent = '选择一首歌曲开始'
  $playerCoverImg.classList.add('hidden')
  $playerCoverPlaceholder.classList.remove('hidden')
  $progressFill.style.width = '0%'
  $timeCur.textContent = '0:00'
  $timeTotal.textContent = '0:00'
  $playerLyricLine.innerHTML = '&nbsp;'
  if ($playerCoverImgM) {
    $playerCoverImgM.classList.add('hidden')
    if ($playerCoverPlaceholderM) $playerCoverPlaceholderM.classList.remove('hidden')
  }
  if ($playerSongM) $playerSongM.textContent = '未播放'
  if ($timeCurM) $timeCurM.textContent = '0:00'
  if ($timeTotalM) $timeTotalM.textContent = '0:00'
  if ($progressFillM) $progressFillM.style.width = '0%'
  const $fsLyricBody = document.getElementById('fs-lyric-body')
  if ($fsLyricBody) $fsLyricBody.innerHTML = '<div class="text-center lyric-placeholder mt-20">暂无歌词</div>'
  updatePlayBtn()
  updateFullscreenPlayer()
  savePlaylistToStorage()
  showToast('播放列表已清空')
}

// 搜索页面
function showSearch() {
  document.getElementById('tab-search').style.display = ''
  $searchToolbar.style.display = ''
  if (searchKeyword) {
    doSearch(searchKeyword, searchPage)
  } else {
    $searchBody.innerHTML = `
      <div class="empty fade-in">
        <i class="fas fa-search text-6xl mb-4"></i>
        <p>输入关键词搜索歌曲</p>
      </div>
    `
  }
}

// 推荐页面
async function showRecommend() {
  showLoading()
  try {
    const data = await apiFetch(`/songlist?source=${currentPlatform}&sortId=hot`)
    if (!data || !data.list || data.list.length === 0) {
      showEmpty('暂无推荐数据')
      return
    }
    
    let html = ''
    
    const first = data.list[0]
    html += `
      <div class="recommend-featured fade-in" onclick="showPlaylistDetail('${first.id || first.info_sid}')">
        <div class="recommend-featured-cover">
          <img src="${proxyImgUrl(first.img || first.pic || first.cover)}" alt="${first.name}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
          <div class="recommend-featured-img-placeholder" style="display:none"><i class="fas fa-music text-4xl img-placeholder-icon"></i></div>
          <div class="recommend-featured-overlay">
            <div class="recommend-featured-play"><i class="fas fa-play"></i></div>
          </div>
        </div>
        <div class="recommend-featured-info">
          <div class="recommend-featured-title">${first.name}</div>
          <div class="recommend-featured-desc">${first.author || first.play_count || ''}</div>
        </div>
      </div>
    `
    
    if (data.list.length > 1) {
      html += '<div class="recommend-grid fade-in">'
      data.list.slice(1).forEach(pl => {
        html += `
          <div class="recommend-card" onclick="showPlaylistDetail('${pl.id || pl.info_sid}')">
            <div class="recommend-card-cover">
              <img src="${proxyImgUrl(pl.img || pl.pic || pl.cover)}" alt="${pl.name}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
              <div class="recommend-card-img-placeholder" style="display:none"><i class="fas fa-music text-3xl img-placeholder-icon"></i></div>
              <div class="recommend-card-overlay">
                <div class="recommend-card-play"><i class="fas fa-play"></i></div>
              </div>
            </div>
            <div class="recommend-card-info">
              <div class="recommend-card-title">${pl.name}</div>
              <div class="recommend-card-desc">${pl.author || pl.play_count || ''}</div>
            </div>
          </div>
        `
      })
      html += '</div>'
    }
    
    $recommendBody.innerHTML = html
    hideLoading()
    document.getElementById('tab-recommend').style.display = ''
    tabCache[`recommend_${currentPlatform}`] = html
  } catch (e) {
    showEmpty('推荐加载失败：' + e.message)
  }
}

// 排行榜页面
async function showLeaderboard() {
  showLoading()
  try {
    const data = await apiFetch(`/leaderboard?source=${currentPlatform}`)
    if (!data || !data.list || data.list.length === 0) {
      showEmpty('暂无排行榜数据')
      return
    }
    
    leaderboardList = data.list
    leaderboardDetailCache = {}
    leaderboardPlatform = currentPlatform
    
    let html = '<div class="lb-layout fade-in">'
    html += '<div class="lb-custom-select" id="lb-custom-select">'
    html += '<div class="lb-select-trigger" id="lb-select-trigger" onclick="toggleLbSelect()">'
    const firstBoard = data.list[0]
    html += `<span class="lb-select-text">${firstBoard ? firstBoard.name : '选择排行榜'}</span>`
    html += '<i class="fas fa-chevron-down lb-select-arrow"></i>'
    html += '</div>'
    html += '<div class="lb-select-dropdown hidden" id="lb-select-dropdown">'
    data.list.forEach((board, i) => {
      const bid = board.bangid || board.id
      html += `<div class="lb-select-option${i === 0 ? ' active' : ''}" data-bangid="${bid}" onclick="selectLeaderboardFromCustom('${bid}')">${board.name}</div>`
    })
    html += '</div></div>'
    html += '<div class="lb-sidebar" id="lb-sidebar">'
    data.list.forEach((board, i) => {
      html += `
        <div class="lb-sidebar-item${i === 0 ? ' active' : ''}" data-bangid="${board.bangid || board.id}" onclick="selectLeaderboard('${board.bangid || board.id}')">
          <div class="lb-sidebar-name">${board.name}</div>
        </div>
      `
    })
    html += '</div>'
    html += '<div class="lb-main" id="lb-main">'
    html += '<div class="lb-main-header" id="lb-main-header"></div>'
    html += '<div id="lb-song-list"></div>'
    html += '</div>'
    html += '</div>'
    
    $leaderboardBody.innerHTML = html
    bindLbMainScroll()
    hideLoading()
    document.getElementById('tab-leaderboard').style.display = ''
    tabCache[`leaderboard_${currentPlatform}`] = null
    
    if (data.list.length > 0) {
      selectLeaderboard(data.list[0].bangid || data.list[0].id)
    }
  } catch (e) {
    showEmpty('排行榜加载失败：' + e.message)
  }
}

function bindLbMainScroll() {
  const lbMain = document.getElementById('lb-main')
  const backToTopBtn = document.getElementById('back-to-top')
  if (lbMain && backToTopBtn) {
    lbMain.addEventListener('scroll', () => {
      backToTopBtn.classList.toggle('visible', lbMain.scrollTop > 300)
    })
  }
}

function renderLeaderboardLayout() {
  let html = '<div class="lb-layout fade-in">'
  html += '<div class="lb-custom-select" id="lb-custom-select">'
  html += '<div class="lb-select-trigger" id="lb-select-trigger" onclick="toggleLbSelect()">'
  const currentBoard = leaderboardList.find(b => (b.bangid || b.id) === currentLeaderboardId) || leaderboardList[0]
  html += `<span class="lb-select-text">${currentBoard ? currentBoard.name : '选择排行榜'}</span>`
  html += '<i class="fas fa-chevron-down lb-select-arrow"></i>'
  html += '</div>'
  html += '<div class="lb-select-dropdown hidden" id="lb-select-dropdown">'
  leaderboardList.forEach((board, i) => {
    const bid = board.bangid || board.id
    const isActive = bid === currentLeaderboardId || (i === 0 && !currentLeaderboardId)
    html += `<div class="lb-select-option${isActive ? ' active' : ''}" data-bangid="${bid}" onclick="selectLeaderboardFromCustom('${bid}')">${board.name}</div>`
  })
  html += '</div></div>'
  html += '<div class="lb-sidebar" id="lb-sidebar">'
  leaderboardList.forEach((board, i) => {
    html += `
      <div class="lb-sidebar-item${(board.bangid || board.id) === currentLeaderboardId ? ' active' : (i === 0 && !currentLeaderboardId ? ' active' : '')}" data-bangid="${board.bangid || board.id}" onclick="selectLeaderboard('${board.bangid || board.id}')">
        <div class="lb-sidebar-name">${board.name}</div>
      </div>
    `
  })
  html += '</div>'
  html += '<div class="lb-main" id="lb-main">'
  html += '<div class="lb-main-header" id="lb-main-header"></div>'
  html += '<div id="lb-song-list"></div>'
  html += '</div>'
  html += '</div>'
  $leaderboardBody.innerHTML = html
  bindLbMainScroll()
  document.getElementById('tab-leaderboard').style.display = ''
  const targetId = currentLeaderboardId || (leaderboardList.length > 0 ? (leaderboardList[0].bangid || leaderboardList[0].id) : '')
  if (targetId) selectLeaderboard(targetId)
}

function toggleLbSelect() {
  const dropdown = document.getElementById('lb-select-dropdown')
  const arrow = document.querySelector('#lb-select-trigger .lb-select-arrow')
  if (!dropdown) return
  const isOpen = !dropdown.classList.contains('hidden')
  if (isOpen) {
    dropdown.classList.add('hidden')
    if (arrow) arrow.style.transform = ''
  } else {
    dropdown.classList.remove('hidden')
    if (arrow) arrow.style.transform = 'rotate(180deg)'
    setTimeout(() => {
      document.addEventListener('click', closeLbSelectOutside)
    }, 10)
  }
}

function closeLbSelectOutside(e) {
  const select = document.getElementById('lb-custom-select')
  if (select && !select.contains(e.target)) {
    const dropdown = document.getElementById('lb-select-dropdown')
    const arrow = document.querySelector('#lb-select-trigger .lb-select-arrow')
    if (dropdown) dropdown.classList.add('hidden')
    if (arrow) arrow.style.transform = ''
    document.removeEventListener('click', closeLbSelectOutside)
  }
}

function selectLeaderboardFromCustom(bangid) {
  selectLeaderboard(bangid)
  const dropdown = document.getElementById('lb-select-dropdown')
  const arrow = document.querySelector('#lb-select-trigger .lb-select-arrow')
  if (dropdown) dropdown.classList.add('hidden')
  if (arrow) arrow.style.transform = ''
  document.removeEventListener('click', closeLbSelectOutside)
}

async function selectLeaderboard(bangid) {
  currentLeaderboardId = bangid
  
  const sidebarItems = document.querySelectorAll('#lb-sidebar .lb-sidebar-item')
  sidebarItems.forEach(item => {
    item.classList.toggle('active', item.dataset.bangid === bangid)
  })
  
  // 同步自定义下拉组件选中状态
  const selectOptions = document.querySelectorAll('#lb-select-dropdown .lb-select-option')
  selectOptions.forEach(opt => {
    opt.classList.toggle('active', opt.dataset.bangid === bangid)
  })
  const selectText = document.querySelector('#lb-select-trigger .lb-select-text')
  const board = leaderboardList.find(b => (b.bangid || b.id) === bangid)
  if (selectText && board) selectText.textContent = board.name
  const headerEl = document.getElementById('lb-main-header')
  if (headerEl && board) {
    headerEl.innerHTML = `
      <div class="lb-main-title-row">
        <h2 class="lb-main-title">${board.name}</h2>
        <div class="lb-main-actions">
          <button class="toolbar-action-btn" onclick="playAllLbSongs()"><i class="fas fa-play"></i> <span class="btn-text-full">播放全部</span><span class="btn-text-mobile">全部</span></button>
          <button class="toolbar-action-btn" onclick="addSelectedLbToPlaylist()"><i class="fas fa-plus"></i> <span class="btn-text-full">添加到</span><span class="btn-text-mobile">添加</span></button>
        </div>
      </div>
    `
  }
  
  const songListEl = document.getElementById('lb-song-list')
  if (!songListEl) return
  
  const cacheKey = `${currentPlatform}_${bangid}`
  if (leaderboardDetailCache[cacheKey]) {
    renderLbSongList(leaderboardDetailCache[cacheKey])
    return
  }
  
  songListEl.innerHTML = '<div class="loading"><div class="spinner"></div></div>'
  try {
    const detail = await apiFetch(`/leaderboard/detail?source=${currentPlatform}&bangid=${bangid}&page=1`)
    if (detail && detail.list) {
      leaderboardDetailCache[cacheKey] = detail.list
      renderLbSongList(detail.list)
    } else {
      songListEl.innerHTML = '<div class="empty"><p>暂无歌曲</p></div>'
    }
  } catch (e) {
    songListEl.innerHTML = `<div class="empty"><p>加载失败：${e.message}</p></div>`
  }
}

let lbSelectedIndices = new Set()
let lbSongList = []
let lbClickTimer = null

function renderLbSongList(list) {
  lbSongList = list
  lbSelectedIndices = new Set()
  const songListEl = document.getElementById('lb-song-list')
  if (!songListEl) return
  
  if (!list || list.length === 0) {
    songListEl.innerHTML = '<div class="empty"><p>暂无歌曲</p></div>'
    return
  }
  
  let html = '<div class="search-result-list fade-in">'
  html += `
    <div class="search-result-header">
      <div class="sr-col sr-col-index"></div>
      <div class="sr-col sr-col-img"></div>
      <div class="sr-col sr-col-name">歌曲</div>
      <div class="sr-col sr-col-artist">歌手</div>
      <div class="sr-col sr-col-actions"></div>
      <div class="sr-col sr-col-duration">时长</div>
    </div>
  `
  
  list.forEach((song, i) => {
    const imgSrc = proxyImgUrl(song.img || '')
    const sourceLetter = SOURCE_LETTERS[song.source || currentPlatform] || ''
    html += `
      <div class="search-result-item" data-index="${i}">
        <div class="sr-col sr-col-index">${i + 1}<sup class="sr-source-sup">${sourceLetter}</sup></div>
        <div class="sr-col sr-col-img">
          <img src="${imgSrc}" alt="" onerror="this.style.display='none'">
        </div>
        <div class="sr-col sr-col-name">
          <span class="sr-song-name">${song.name || '未知'}</span>
          <span class="sr-song-artist-mobile" onclick="event.stopPropagation();searchBySinger('${(song.singer || '').replace(/'/g, "\\'")}', '${song.source || currentPlatform}')">${song.singer || '未知'}</span>
        </div>
        <div class="sr-col sr-col-artist" onclick="event.stopPropagation();searchBySinger('${(song.singer || '').replace(/'/g, "\\'")}', '${song.source || currentPlatform}')">${song.singer || '未知'}</div>
        <div class="sr-col sr-col-actions">
          <button class="sr-action-btn" onclick="event.stopPropagation();lbPlayNext(${i})" title="添加到下一首播放">
            <i class="fas fa-forward"></i>
          </button>
          <button class="sr-action-btn" onclick="event.stopPropagation();lbAddToList(${i})" title="添加到播放列表">
            <i class="fas fa-plus"></i>
          </button>
        </div>
        <div class="sr-col sr-col-duration">${fmtTime(song.interval)}</div>
      </div>
    `
  })
  html += '</div>'
  songListEl.innerHTML = html
  
  songListEl.querySelectorAll('.search-result-item').forEach(item => {
    item.addEventListener('click', () => {
      const index = parseInt(item.dataset.index)
      handleLbRowClick(index, item)
    })
  })
}

function handleLbRowClick(i, el) {
  if (lbClickTimer) {
    clearTimeout(lbClickTimer)
    lbClickTimer = null
    playSong(lbSongList[i])
    clearLbSelection()
  } else {
    lbClickTimer = setTimeout(() => {
      lbClickTimer = null
      if (lbSelectedIndices.has(i)) {
        lbSelectedIndices.delete(i)
        el.classList.remove('selected')
      } else {
        lbSelectedIndices.add(i)
        el.classList.add('selected')
      }
    }, 250)
  }
}

function clearLbSelection() {
  lbSelectedIndices = new Set()
  const lbSongListEl = document.getElementById('lb-song-list')
  if (lbSongListEl) lbSongListEl.querySelectorAll('.search-result-item.selected').forEach(el => el.classList.remove('selected'))
}

function lbPlayNext(i) {
  const song = lbSongList[i]
  if (!song) return
  const existingIndex = playlist.findIndex(s => s.songmid === song.songmid && s.source === song.source)
  if (existingIndex === -1) {
    playlist.splice(playIndex + 1, 0, song)
  } else {
    const songData = playlist.splice(existingIndex, 1)[0]
    if (existingIndex < playIndex) playIndex--
    playlist.splice(playIndex + 1, 0, songData)
  }
  renderPlaylist()
  clearLbSelection()
  showToast(`「${song.name || '未知'}」将作为下一首播放`)
}

function lbAddToList(i) {
  const song = lbSongList[i]
  if (song) {
    addToPlaylist(song)
    clearLbSelection()
  }
}

function playAllLbSongs() {
  if (lbSongList.length > 0) {
    playlist = [...lbSongList]
    playIndex = 0
    renderPlaylist()
    playSong(playlist[0])
  }
}

function addSelectedLbToPlaylist() {
  if (lbSelectedIndices.size === 0) return
  let added = 0
  let skipped = 0
  lbSelectedIndices.forEach(idx => {
    const song = lbSongList[idx]
    if (song) {
      const existingIndex = playlist.findIndex(s => s.songmid === song.songmid && s.source === song.source)
      if (existingIndex === -1) {
        playlist.push(song)
        added++
      } else {
        skipped++
      }
    }
  })
  if (added > 0) {
    renderPlaylist()
    showToast(`已添加 ${added} 首歌曲到播放列表${skipped > 0 ? `，${skipped} 首已存在` : ''}`)
  } else if (skipped > 0) {
    showToast(`${skipped} 首歌曲已在播放列表中`)
  }
  clearLbSelection()
}

async function showSonglist() {
  showLoading()
  try {
    const data = await apiFetch(`/songlist/hot?source=${currentPlatform}`)
    if (!data || !data.list || data.list.length === 0) {
      showEmpty('暂无歌单数据')
      return
    }
    
    let html = '<div class="section-title fade-in"><h2 class="text-2xl font-bold mb-4">热门歌单</h2></div>'
    html += '<div class="leaderboard-grid fade-in">'
    data.list.forEach(pl => {
      html += `
        <div class="leaderboard-card" onclick="showPlaylistDetail('${pl.id || pl.info_sid}')">
          <div class="leaderboard-cover">
            <img src="${proxyImgUrl(pl.img || pl.pic || pl.cover)}" alt="${pl.name}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
            <i class="fas fa-image text-4xl img-placeholder-icon hidden" style="display:none;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)"></i>
            <div class="leaderboard-overlay">
              <div class="leaderboard-play"><i class="fas fa-play"></i></div>
            </div>
          </div>
          <div class="leaderboard-info">
            <div class="leaderboard-title">${pl.name}</div>
            <div class="leaderboard-desc">${pl.author || pl.play_count || ''}</div>
          </div>
        </div>
      `
    })
    html += '</div>'
    $leaderboardBody.innerHTML = html
    hideLoading()
    document.getElementById('tab-leaderboard').style.display = ''
    tabCache[`songlist_${currentPlatform}`] = html
  } catch (e) {
    showEmpty('歌单加载失败：' + e.message)
  }
}

// 搜索
async function doSearch(keyword, page = 1) {
  if (!keyword) return
  searchKeyword = keyword
  searchPage = page
  $searchInput.value = keyword
  if ($searchInputM) $searchInputM.value = keyword
  searchMode = searchMode || 'song'
  
  const $searchTabBtn = document.getElementById('search-tab-btn')
  if ($searchTabBtn) $searchTabBtn.classList.remove('hidden')
  const $searchTabBtnM = document.getElementById('search-tab-btn-m')
  if ($searchTabBtnM) $searchTabBtnM.classList.remove('hidden')
  currentTab = 'search'
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === 'search'))
  document.querySelectorAll('.tab-btn-m').forEach(b => b.classList.toggle('active', b.dataset.tab === 'search'))
  document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none')
  document.getElementById('tab-search').style.display = ''
  $searchToolbar.style.display = ''
  updateSearchToolbar()
  
  const mainContent = document.getElementById('main-content')
  if (mainContent) mainContent.scrollTop = 0
  
  if (searchMode === 'song') {
    const cacheHit = searchSongCache.keyword === keyword && searchSongCache.source === searchSource && searchSongCache.page === page && searchSongCache.data
    if (cacheHit) {
      searchSongList = searchSongCache.data.list || []
      renderSearchResults(searchSongList, searchSongCache.data.total, searchSongCache.data.allPage, page)
      return
    }
    showLoading()
    try {
      const data = await apiFetch(`/search?source=${searchSource}&keyword=${encodeURIComponent(keyword)}&page=${page}&limit=30`)
      searchSongCache = { keyword, source: searchSource, page, data }
      searchSongList = data.list || []
      hideLoading()
      renderSearchResults(searchSongList, data.total, data.allPage, page)
    } catch (e) {
      showEmpty('搜索失败：' + e.message)
    }
  } else {
    const cacheHit = searchSonglistCache.keyword === keyword && searchSonglistCache.source === searchSource && searchSonglistCache.page === page && searchSonglistCache.data
    if (cacheHit) {
      searchSonglistList = searchSonglistCache.data.list || []
      renderSearchSonglistResults(searchSonglistList, searchSonglistCache.data.total, searchSonglistCache.data.allPage, page)
      return
    }
    showLoading()
    try {
      const data = await apiFetch(`/songlist/search?source=${searchSource}&keyword=${encodeURIComponent(keyword)}&page=${page}&limit=30`)
      searchSonglistCache = { keyword, source: searchSource, page, data }
      searchSonglistList = data.list || []
      hideLoading()
      renderSearchSonglistResults(searchSonglistList, data.total, data.allPage, page)
    } catch (e) {
      showEmpty('搜索失败：' + e.message)
    }
  }
}

function switchSearchMode(mode) {
  if (searchMode === mode) return
  searchMode = mode
  
  if (!searchKeyword) return
  
  if (searchMode === 'song' && searchSongCache.keyword === searchKeyword && searchSongCache.source === searchSource && searchSongCache.data) {
    searchSongList = searchSongCache.data.list || []
    renderSearchResults(searchSongList, searchSongCache.data.total, searchSongCache.data.allPage, searchSongCache.page)
    return
  }
  if (searchMode === 'songlist' && searchSonglistCache.keyword === searchKeyword && searchSonglistCache.source === searchSource && searchSonglistCache.data) {
    searchSonglistList = searchSonglistCache.data.list || []
    renderSearchSonglistResults(searchSonglistList, searchSonglistCache.data.total, searchSonglistCache.data.allPage, searchSonglistCache.page)
    return
  }
  
  doSearch(searchKeyword, 1)
}

function updateSearchToolbar() {
  if ($modeBtnSong) $modeBtnSong.classList.toggle('active', searchMode === 'song')
  if ($modeBtnSonglist) $modeBtnSonglist.classList.toggle('active', searchMode === 'songlist')
  const toolbarPlayall = document.getElementById('toolbar-playall')
  const toolbarAddto = document.getElementById('toolbar-addto')
  const toolbarResolve = document.getElementById('toolbar-resolve')
  if (toolbarPlayall) toolbarPlayall.classList.toggle('hidden', searchMode !== 'song')
  if (toolbarAddto) toolbarAddto.classList.toggle('hidden', searchMode !== 'song')
  if (toolbarResolve) toolbarResolve.classList.toggle('hidden', searchMode !== 'songlist')
}

function resolveSelectedSonglist() {
  // 显示解析歌单模态框
  const modalOverlay = document.getElementById('parse-songlist-modal-overlay')
  const modalInput = document.getElementById('parse-songlist-input')
  modalOverlay.classList.remove('hidden')
  modalInput.value = ''
  modalInput.focus()
}

// 歌单解析模态框事件处理
document.addEventListener('DOMContentLoaded', function() {
  const parseModalOverlay = document.getElementById('parse-songlist-modal-overlay')
  const parseModalClose = document.getElementById('parse-songlist-modal-close')
  const parseModalConfirm = document.getElementById('parse-songlist-confirm-btn')
  const parseModalInput = document.getElementById('parse-songlist-input')
  
  // 关闭按钮
  if (parseModalClose) {
    parseModalClose.addEventListener('click', function() {
      parseModalOverlay.classList.add('hidden')
    })
  }
  
  // 点击遮罩层关闭
  if (parseModalOverlay) {
    parseModalOverlay.addEventListener('click', function(e) {
      if (e.target === parseModalOverlay) {
        parseModalOverlay.classList.add('hidden')
      }
    })
  }
  
  // 确认解析按钮
  if (parseModalConfirm) {
    parseModalConfirm.addEventListener('click', async function() {
      const url = parseModalInput.value.trim()
      if (!url) {
        showToast('请输入歌单链接')
        return
      }
      
      try {
        showToast('正在解析歌单...')
        const data = await apiFetch(`/songlist/parse?url=${encodeURIComponent(url)}`)
        if (data && data.list && data.list.length > 0) {
          parseModalOverlay.classList.add('hidden')
          songlistData = data.list
          const $songlistTabBtn = document.getElementById('songlist-tab-btn')
          if ($songlistTabBtn) $songlistTabBtn.classList.remove('hidden')
          const $songlistTabBtnM = document.getElementById('songlist-tab-btn-m')
          if ($songlistTabBtnM) $songlistTabBtnM.classList.remove('hidden')
          currentTab = 'parsed-songlist'
          document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === 'parsed-songlist'))
          document.querySelectorAll('.tab-btn-m').forEach(b => b.classList.toggle('active', b.dataset.tab === 'parsed-songlist'))
          document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none')
          document.getElementById('tab-parsed-songlist').style.display = ''
          renderSonglistTab(data.list)
          showToast(`成功解析 ${data.list.length} 首歌曲`)
        } else {
          showToast('未找到歌曲或解析失败')
        }
      } catch (e) {
        console.error('[解析歌单] 失败:', e.message)
        showToast('解析失败：' + (e.message || '未知错误'))
      }
    })
  }
})

function playAllSearch() {
  if (searchSongList.length > 0) {
    playlist = [...searchSongList]
    playIndex = 0
    renderPlaylist()
    playSong(playlist[0])
  }
}

let selectedSongIndices = new Set()
let clickTimer = null

function clearSongSelection() {
  selectedSongIndices = new Set()
  $searchBody.querySelectorAll('.search-result-item.selected').forEach(el => el.classList.remove('selected'))
  const lbSongListEl = document.getElementById('lb-song-list')
  if (lbSongListEl) lbSongListEl.querySelectorAll('.search-result-item.selected').forEach(el => el.classList.remove('selected'))
}

function addSelectedToPlaylist() {
  if (selectedSongIndices.size === 0) return
  let added = 0
  let skipped = 0
  selectedSongIndices.forEach(idx => {
    const song = searchSongList[idx]
    if (song) {
      const existingIndex = playlist.findIndex(s => s.songmid === song.songmid && s.source === song.source)
      if (existingIndex === -1) {
        playlist.push(song)
        added++
      } else {
        skipped++
      }
    }
  })
  if (added > 0) {
    renderPlaylist()
    showToast(`已添加 ${added} 首歌曲到播放列表${skipped > 0 ? `，${skipped} 首已存在` : ''}`)
  } else if (skipped > 0) {
    showToast(`${skipped} 首歌曲已在播放列表中`)
  }
  clearSongSelection()
}

function addSongToList(i) {
  event.stopPropagation()
  const song = searchSongList[i]
  if (song) {
    addToPlaylist(song)
    clearSongSelection()
  }
}

function handleSongRowClick(i, el) {
  if (clickTimer) {
    clearTimeout(clickTimer)
    clickTimer = null
    playSong(searchSongList[i])
    clearSongSelection()
  } else {
    clickTimer = setTimeout(() => {
      clickTimer = null
      if (selectedSongIndices.has(i)) {
        selectedSongIndices.delete(i)
        el.classList.remove('selected')
      } else {
        selectedSongIndices.add(i)
        el.classList.add('selected')
      }
    }, 250)
  }
}

function playNextSong(song) {
  const existingIndex = playlist.findIndex(s => s.songmid === song.songmid && s.source === song.source)
  if (existingIndex === -1) {
    playlist.splice(playIndex + 1, 0, song)
  } else {
    const songData = playlist.splice(existingIndex, 1)[0]
    if (existingIndex < playIndex) playIndex--
    playlist.splice(playIndex + 1, 0, songData)
  }
  renderPlaylist()
  clearSongSelection()
  showToast(`「${song.name || '未知'}」将作为下一首播放`)
}

const SOURCE_LETTERS = { wy: 'ʷʸ', kg: 'ᵏᵍ', kw: 'ᵏʷ', tx: 'ᵗˣ', mg: 'ᵐᵍ', qs: 'ᵈʸ' }

function searchBySinger(singer, source) {
  if (!singer || singer === '未知') return
  searchSource = source || searchSource
  updateSearchDisplay()
  updateSearchSourceTags()
  searchMode = 'song'
  doSearch(singer)
}

function renderSonglistTab(list) {
  const $body = document.getElementById('songlist-body')
  if (!$body || !list || list.length === 0) {
    if ($body) $body.innerHTML = '<div class="empty"><i class="fas fa-exclamation-circle text-6xl mb-4"></i><p>没有找到歌曲</p></div>'
    return
  }
  let html = '<div class="search-result-list fade-in">'
  html += `
    <div class="search-result-header">
      <div class="sr-col sr-col-index"></div>
      <div class="sr-col sr-col-img"></div>
      <div class="sr-col sr-col-name">歌曲</div>
      <div class="sr-col sr-col-artist">歌手</div>
      <div class="sr-col sr-col-actions"></div>
      <div class="sr-col sr-col-duration">时长</div>
    </div>
  `
  list.forEach((song, i) => {
    const imgSrc = proxyImgUrl(song.img || song.cover || '')
    const sourceLetter = SOURCE_LETTERS[song.source || currentPlatform] || ''
    const playing = playlist[playIndex] && playlist[playIndex].songmid === song.songmid && playlist[playIndex].source === song.source
    html += `
      <div class="search-result-item${playing ? ' selected' : ''}" data-index="${i}">
        <div class="sr-col sr-col-index">${i + 1}<sup class="sr-source-sup">${sourceLetter}</sup></div>
        <div class="sr-col sr-col-img">
          <img src="${imgSrc}" alt="" onerror="this.style.display='none'">
        </div>
        <div class="sr-col sr-col-name">
          <span class="sr-song-name">${song.name || song.songname || '未知'}</span>
          <span class="sr-song-artist-mobile" onclick="event.stopPropagation();searchBySinger('${(song.singer || song.artist || '').replace(/'/g, "\\'")}', '${song.source || currentPlatform}')">${song.singer || song.artist || '未知'}</span>
        </div>
        <div class="sr-col sr-col-artist" onclick="event.stopPropagation();searchBySinger('${(song.singer || song.artist || '').replace(/'/g, "\\'")}', '${song.source || currentPlatform}')">${song.singer || song.artist || '未知'}</div>
        <div class="sr-col sr-col-actions">
          <button class="sr-action-btn" onclick="event.stopPropagation();playNextSong(songlistData[${i}])" title="下一首播放">
            <i class="fas fa-forward"></i>
          </button>
          <button class="sr-action-btn" onclick="event.stopPropagation();addSonglistItemToPlaylist(${i})" title="添加到播放列表">
            <i class="fas fa-plus"></i>
          </button>
        </div>
        <div class="sr-col sr-col-duration">${fmtTime(song.interval)}</div>
      </div>
    `
  })
  html += '</div>'
  $body.innerHTML = html

  $body.querySelectorAll('.search-result-item').forEach(item => {
    item.addEventListener('click', () => {
      const index = parseInt(item.dataset.index)
      handleSonglistRowClick(index, item)
    })
  })
}

function playSonglistItem(index) {
  if (!songlistData[index]) return
  const song = songlistData[index]
  const existingIndex = playlist.findIndex(s => s.songmid === song.songmid && s.source === song.source)
  if (existingIndex !== -1) {
    playIndex = existingIndex
  } else {
    playlist.push(song)
    playIndex = playlist.length - 1
  }
  renderPlaylist()
  playSong(playlist[playIndex])
}

let selectedSonglistIndices = new Set()
let songlistClickTimer = null

function clearSonglistSelection() {
  selectedSonglistIndices = new Set()
  const $body = document.getElementById('songlist-body')
  if ($body) $body.querySelectorAll('.search-result-item.selected').forEach(el => el.classList.remove('selected'))
}

function handleSonglistRowClick(i, el) {
  if (songlistClickTimer) {
    clearTimeout(songlistClickTimer)
    songlistClickTimer = null
    playSonglistItem(i)
    clearSonglistSelection()
  } else {
    songlistClickTimer = setTimeout(() => {
      songlistClickTimer = null
      if (selectedSonglistIndices.has(i)) {
        selectedSonglistIndices.delete(i)
        el.classList.remove('selected')
      } else {
        selectedSonglistIndices.add(i)
        el.classList.add('selected')
      }
    }, 250)
  }
}

function addSonglistItemToPlaylist(index) {
  if (!songlistData[index]) return
  const song = songlistData[index]
  const existingIndex = playlist.findIndex(s => s.songmid === song.songmid && s.source === song.source)
  if (existingIndex === -1) {
    playlist.push(song)
    renderPlaylist()
    savePlaylistToStorage()
    showToast('已添加到播放列表')
  } else {
    showToast('歌曲已在播放列表中')
  }
  clearSonglistSelection()
}

function playAllSonglist() {
  if (!songlistData || songlistData.length === 0) return
  playlist = [...songlistData]
  playIndex = 0
  renderPlaylist()
  playSong(playlist[0])
  savePlaylistToStorage()
}

function addAllSonglistToPlaylist() {
  if (!songlistData || songlistData.length === 0) return
  const indices = selectedSonglistIndices.size > 0 ? [...selectedSonglistIndices] : songlistData.map((_, i) => i)
  let added = 0
  indices.forEach(idx => {
    const song = songlistData[idx]
    if (song) {
      const existingIndex = playlist.findIndex(s => s.songmid === song.songmid && s.source === song.source)
      if (existingIndex === -1) {
        playlist.push(song)
        added++
      }
    }
  })
  renderPlaylist()
  savePlaylistToStorage()
  showToast(added > 0 ? `已添加 ${added} 首歌曲到播放列表` : '歌曲已在播放列表中')
  clearSonglistSelection()
}

function renderSearchResults(list, total, allPage, page) {
  if (!list || list.length === 0) {
    showEmpty('没有找到歌曲')
    return
  }
  
  selectedSongIndices = new Set()
  updateSearchToolbar()
  document.getElementById('tab-search').style.display = ''
  
  let html = '<div class="search-result-list fade-in">'
  html += `
    <div class="search-result-header">
      <div class="sr-col sr-col-index"></div>
      <div class="sr-col sr-col-img"></div>
      <div class="sr-col sr-col-name">歌曲</div>
      <div class="sr-col sr-col-artist">歌手</div>
      <div class="sr-col sr-col-actions"></div>
      <div class="sr-col sr-col-duration">时长</div>
    </div>
  `
  
  list.forEach((song, i) => {
    const imgSrc = proxyImgUrl(song.img || '')
    const sourceLetter = SOURCE_LETTERS[song.source || searchSource] || ''
    html += `
      <div class="search-result-item" data-index="${i}">
        <div class="sr-col sr-col-index">${(page - 1) * 30 + i + 1}<sup class="sr-source-sup">${sourceLetter}</sup></div>
        <div class="sr-col sr-col-img">
          <img src="${imgSrc}" alt="" onerror="this.style.display='none'">
        </div>
        <div class="sr-col sr-col-name">
          <span class="sr-song-name">${song.name || '未知'}</span>
          <span class="sr-song-artist-mobile" onclick="event.stopPropagation();searchBySinger('${(song.singer || '').replace(/'/g, "\\'")}', '${song.source || searchSource}')">${song.singer || '未知'}</span>
        </div>
        <div class="sr-col sr-col-artist" onclick="event.stopPropagation();searchBySinger('${(song.singer || '').replace(/'/g, "\\'")}', '${song.source || searchSource}')">${song.singer || '未知'}</div>
        <div class="sr-col sr-col-actions">
          <button class="sr-action-btn" onclick="event.stopPropagation();playNextSong(searchSongList[${i}])" title="下一首播放">
            <i class="fas fa-forward"></i>
          </button>
          <button class="sr-action-btn" onclick="addSongToList(${i})" title="添加到播放列表">
            <i class="fas fa-plus"></i>
          </button>
        </div>
        <div class="sr-col sr-col-duration">${fmtTime(song.interval)}</div>
      </div>
    `
  })
  html += '</div>'
  
  $searchBody.innerHTML = html
  
  let pagHtml = ''
  if (allPage > 1) {
    pagHtml += '<div class="search-pagination">'
    if (page > 1) pagHtml += `<button class="page-btn" onclick="doSearch('${searchKeyword}', ${page - 1})">上一页</button>`
    pagHtml += `<span class="page-info">第 ${page} / ${allPage} 页</span>`
    if (page < allPage) pagHtml += `<button class="page-btn" onclick="doSearch('${searchKeyword}', ${page + 1})">下一页</button>`
    pagHtml += '</div>'
  }
  $searchPagination.innerHTML = pagHtml
  
  $searchBody.querySelectorAll('.search-result-item').forEach(item => {
    item.addEventListener('click', () => {
      const index = parseInt(item.dataset.index)
      handleSongRowClick(index, item)
    })
  })
}

function renderSearchSonglistResults(list, total, allPage, page) {
  if (!list || list.length === 0) {
    showEmpty('没有找到歌单')
    return
  }
  
  updateSearchToolbar()
  document.getElementById('tab-search').style.display = ''
  
  let html = '<div class="search-result-list search-songlist-list fade-in">'
  html += `
    <div class="search-result-header search-songlist-header">
      <div class="sr-col sr-col-index"></div>
      <div class="sr-col sr-col-img"></div>
      <div class="sr-col sr-col-name">歌单</div>
      <div class="sr-col sr-col-artist">创建人</div>
    </div>
  `
  
  list.forEach((pl, i) => {
    const imgSrc = proxyImgUrl(pl.img || pl.pic || pl.cover)
    const sourceLetter = SOURCE_LETTERS[pl.source || searchSource] || ''
    html += `
      <div class="search-result-item search-songlist-item" data-index="${i}">
        <div class="sr-col sr-col-index">${(page - 1) * 30 + i + 1}<sup class="sr-source-sup">${sourceLetter}</sup></div>
        <div class="sr-col sr-col-img">
          <img src="${imgSrc}" alt="" onerror="this.style.display='none'">
        </div>
        <div class="sr-col sr-col-name">
          <span class="sr-song-name">${pl.name || '未知'}</span>
          <span class="sr-songlist-creator-mobile">${pl.author || pl.creator || ''}</span>
        </div>
        <div class="sr-col sr-col-artist">${pl.author || pl.creator || ''}</div>
      </div>
    `
  })
  html += '</div>'
  
  $searchBody.innerHTML = html
  
  let pagHtml = ''
  if (allPage > 1) {
    pagHtml += '<div class="search-pagination">'
    if (page > 1) pagHtml += `<button class="page-btn" onclick="doSearch('${searchKeyword}', ${page - 1})">上一页</button>`
    pagHtml += `<span class="page-info">第 ${page} / ${allPage} 页</span>`
    if (page < allPage) pagHtml += `<button class="page-btn" onclick="doSearch('${searchKeyword}', ${page + 1})">下一页</button>`
    pagHtml += '</div>'
  }
  $searchPagination.innerHTML = pagHtml
  
  searchSonglistHtmlCache = html
  searchSonglistPagCache = pagHtml
  
  $searchBody.querySelectorAll('.search-result-item').forEach(item => {
    item.addEventListener('click', () => {
      const index = parseInt(item.dataset.index)
      playlistDetailSource = 'songlist-search'
      showPlaylistDetail(list[index].id)
    })
  })
}

async function addSonglistToPlaylist(playlistId, source) {
  try {
    const data = await apiFetch(`/songlist/detail?source=${source || currentPlatform}&id=${playlistId}&page=1`)
    if (data && data.list) {
      let added = 0
      data.list.forEach(song => {
        const existingIndex = playlist.findIndex(s => s.songmid === song.songmid && s.source === song.source)
        if (existingIndex === -1) {
          playlist.push(song)
          added++
        }
      })
      renderPlaylist()
      if (added > 0) showToast(`已添加 ${added} 首歌曲到播放列表`)
    }
  } catch (e) {
    console.error('[Player] 添加歌单失败:', e.message)
  }
}

function addToPlaylist(song) {
  const existingIndex = playlist.findIndex(s => s.songmid === song.songmid && s.source === song.source)
  if (existingIndex === -1) {
    playlist.push(song)
    renderPlaylist()
    showToast(`已添加「${song.name || '未知'}」到播放列表`)
    return true
  }
  showToast(`「${song.name || '未知'}」已在播放列表中`)
  return false
}

function showToast(msg) {
  let toast = document.getElementById('toast-container')
  if (!toast) {
    toast = document.createElement('div')
    toast.id = 'toast-container'
    document.body.appendChild(toast)
  }
  const el = document.createElement('div')
  el.className = 'toast-item'
  el.textContent = msg
  toast.appendChild(el)
  setTimeout(() => {
    el.classList.add('toast-fade-out')
    setTimeout(() => el.remove(), 300)
  }, 2000)
}

// 渲染歌单列表
function renderPlaylistList(list) {
  if (!list || list.length === 0) {
    showEmpty('没有找到歌单')
    return
  }
  
  let html = '<div class="leaderboard-grid fade-in">'
  list.forEach(pl => {
    html += `
      <div class="leaderboard-card">
        <div class="leaderboard-cover">
          <img src="${proxyImgUrl(pl.img || pl.pic || pl.cover)}" alt="${pl.name}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
          <i class="fas fa-image text-4xl img-placeholder-icon hidden" style="display:none;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)"></i>
        </div>
        <div class="leaderboard-info">
          <div class="leaderboard-title">${pl.name}</div>
          <div class="leaderboard-desc">${pl.author || ''}</div>
        </div>
      </div>
    `
  })
  html += '</div>'
  $leaderboardBody.innerHTML = html
  document.getElementById('tab-leaderboard').style.display = ''
}

// 播放歌曲
async function playSong(song, list = []) {
  try {
    $playerSong.innerHTML = `${sourceTag(song.source)}<span class="track-title-text">${escapeHtml(song.name || '')}</span>`
    $playerSinger.textContent = song.singer
    
    const coverUrl = proxyImgUrl(song.img || '')
    if (coverUrl) {
      $playerCoverImg.src = coverUrl
      $playerCoverImg.classList.remove('hidden')
      $playerCoverPlaceholder.classList.add('hidden')
    } else {
      $playerCoverImg.classList.add('hidden')
      $playerCoverPlaceholder.classList.remove('hidden')
    }
    
    if ($playerSongM) $playerSongM.innerHTML = `${sourceTag(song.source)}<span class="track-title-text">${escapeHtml(song.name || '')}</span>`
    if ($playerCoverImgM && coverUrl) {
      $playerCoverImgM.src = coverUrl
      $playerCoverImgM.classList.remove('hidden')
      if ($playerCoverPlaceholderM) $playerCoverPlaceholderM.classList.add('hidden')
    } else if ($playerCoverImgM) {
      $playerCoverImgM.classList.add('hidden')
      if ($playerCoverPlaceholderM) $playerCoverPlaceholderM.classList.remove('hidden')
    }
    
    const urls = await apiFetch(`/music-url?source=${song.source || currentPlatform}&songmid=${song.songmid}&quality=128k`)
    currentPlayUrls = Array.isArray(urls) ? urls : [urls]
    currentUrlIndex = 0
    durationChecked = false
    
    if (currentPlayUrls.length > 0) {
      await tryPlayUrl(currentPlayUrls[0])
    }
    
    const existingIndex = playlist.findIndex(s => s.songmid === song.songmid && s.source === song.source)
    if (existingIndex === -1) {
      playlist.push(song)
      playIndex = playlist.length - 1
      renderPlaylist()
    } else {
      playIndex = existingIndex
      updatePlaylistHighlight()
      savePlaylistToStorage()
    }
    
    isPlaying = true
    updatePlayBtn()
    updateFullscreenPlayer()
    loadLyric(song)
    
  } catch (e) {
    console.error('[Player] 播放失败:', e.message)
    $playerSinger.textContent = '播放失败'
  }
}

async function tryPlayUrl(urlInfo) {
  let url = urlInfo.url || urlInfo
  if (enableAutoProxy && url.startsWith('http://') && window.location.protocol === 'https:') {
    url = `/api/music/audio-proxy?url=${encodeURIComponent(url)}`
  }
  audio.src = url
  try {
    await audio.play()
  } catch (e) {
    if (e.name !== 'AbortError') {
      console.error('[Player] 播放错误:', e.message)
      throw e
    }
  }
}

function checkDurationAndSwitch() {
  if (durationChecked) return
  const dur = audio.duration
  if (!dur || !isFinite(dur) || dur <= 0) return
  durationChecked = true
  console.log(`[Player] 检测到音频时长: ${dur.toFixed(1)}s (链接 ${currentUrlIndex + 1}/${currentPlayUrls.length})`)
  if (dur < 15 && currentUrlIndex < currentPlayUrls.length - 1) {
    const fromName = currentPlayUrls[currentUrlIndex].from || currentPlayUrls[currentUrlIndex].sourceName || ('规则' + (currentUrlIndex + 1))
    currentUrlIndex++
    const nextFromName = currentPlayUrls[currentUrlIndex].from || currentPlayUrls[currentUrlIndex].sourceName || ('规则' + (currentUrlIndex + 1))
    console.log(`[Player] 音频时长仅 ${dur.toFixed(1)}s（来源: ${fromName}），切换到下一个链接（来源: ${nextFromName}）`)
    const currentSong = playlist[playIndex]
    $playerSinger.textContent = `${currentSong?.singer || ''} - 切换音源...`
    audio.pause()
    audio.removeAttribute('src')
    audio.load()
    durationChecked = false
    tryNextUrl()
  }
}

// 递归尝试下一个播放链接，直到找到有效链接或全部尝试完毕
function tryNextUrl() {
  if (currentUrlIndex >= currentPlayUrls.length) {
    console.log('[Player] 所有播放链接均已尝试，无法找到有效链接')
    const currentSong = playlist[playIndex]
    if (currentSong) $playerSinger.textContent = currentSong.singer || ''
    return
  }
  tryPlayUrl(currentPlayUrls[currentUrlIndex]).then(() => {
    const currentSong = playlist[playIndex]
    if (currentSong) $playerSinger.textContent = currentSong.singer || ''
  }).catch(() => {
    console.log(`[Player] 链接 ${currentUrlIndex + 1}/${currentPlayUrls.length} 播放失败，尝试下一个`)
    currentUrlIndex++
    durationChecked = false
    tryNextUrl()
  })
}

function togglePlay() {
  if (!audio.src || audio.src === window.location.href) {
    if (playlist.length > 0 && playIndex >= 0) {
      playSong(playlist[playIndex])
    }
    return
  }
  if (isPlaying) {
    audio.pause()
  } else {
    audio.play()
  }
  isPlaying = !isPlaying
  updatePlayBtn()
  updateFullscreenPlayer()
}

function updatePlayBtn() {
  const playIcon = $btnPlay.querySelector('.fa-play')
  const pauseIcon = $btnPlay.querySelector('.fa-pause')
  if (isPlaying) {
    playIcon.classList.add('hidden')
    pauseIcon.classList.remove('hidden')
  } else {
    playIcon.classList.remove('hidden')
    pauseIcon.classList.add('hidden')
  }
  const mobileBtn = document.getElementById('mobile-btn-play')
  if (mobileBtn) {
    mobileBtn.innerHTML = isPlaying ? '<i class="fas fa-pause"></i>' : '<i class="fas fa-play"></i>'
  }
  if ($btnPlayM) {
    const playIconM = $btnPlayM.querySelector('.fa-play')
    const pauseIconM = $btnPlayM.querySelector('.fa-pause')
    if (playIconM && pauseIconM) {
      if (isPlaying) {
        playIconM.classList.add('hidden')
        pauseIconM.classList.remove('hidden')
      } else {
        playIconM.classList.remove('hidden')
        pauseIconM.classList.add('hidden')
      }
    }
  }
}

function updateVolumeIcon() {
  const btn = document.getElementById('btn-volume')
  if (!btn) return
  const vol = audio.muted ? 0 : audio.volume
  let icon = 'fa-volume-high'
  if (vol === 0) icon = 'fa-volume-xmark'
  else if (vol < 0.3) icon = 'fa-volume-off'
  else if (vol < 0.7) icon = 'fa-volume-low'
  btn.innerHTML = `<i class="fas ${icon}"></i>`
}

function playPrev() {
  if (playlist.length === 0) return
  if (playMode === 'random') {
    playIndex = Math.floor(Math.random() * playlist.length)
  } else {
    playIndex = (playIndex - 1 + playlist.length) % playlist.length
  }
  playSong(playlist[playIndex])
}

function playNext() {
  if (playlist.length === 0) return
  if (playMode === 'random') {
    playIndex = Math.floor(Math.random() * playlist.length)
  } else {
    playIndex = (playIndex + 1) % playlist.length
  }
  playSong(playlist[playIndex])
}

function onTimeUpdate() {
  if (!audio.duration) return
  $timeCur.textContent = fmtTime(audio.currentTime)
  $timeTotal.textContent = fmtTime(audio.duration)
  const pct = (audio.currentTime / audio.duration) * 100
  $progressFill.style.width = pct + '%'
  updateLyricHighlight(audio.currentTime)
  
  if ($timeCurM) $timeCurM.textContent = fmtTime(audio.currentTime)
  if ($timeTotalM) $timeTotalM.textContent = fmtTime(audio.duration)
  if ($progressFillM) $progressFillM.style.width = pct + '%'
}

async function loadLyric(song) {
  currentLyric = null
  
  try {
    const data = await apiFetch(`/lyric?source=${song.source || currentPlatform}&songmid=${song.songmid}`)
    let lrcText = null
    let tlyricText = null
    if (data && data.lyric) {
      lrcText = data.lyric
      tlyricText = data.tlyric || data.tLyric || null
    } else if (data && data.lrc && data.lrc.lyric) {
      lrcText = data.lrc.lyric
      if (data.tlyric && data.tlyric.lyric) tlyricText = data.tlyric.lyric
    }
    if (lrcText) {
      currentLyric = parseLyric(lrcText, tlyricText)
      renderFsLyric()
    } else {
      const $fsLyricBody = document.getElementById('fs-lyric-body')
      if ($fsLyricBody) $fsLyricBody.innerHTML = '<div class="text-center lyric-placeholder mt-20">暂无歌词</div>'
    }
  } catch (e) {
    const $fsLyricBody = document.getElementById('fs-lyric-body')
    if ($fsLyricBody) $fsLyricBody.innerHTML = '<div class="text-center lyric-placeholder mt-20">歌词加载失败</div>'
  }
}

function parseLyric(lrcText, tlyricText) {
  const lines = lrcText.split('\n')
  const result = []
  const timeReg = /\[(\d{2}):(\d{2})(?:\.(\d{2,3}))?\]/g
  
  for (const line of lines) {
    const times = []
    let match
    while ((match = timeReg.exec(line)) !== null) {
      const min = parseInt(match[1])
      const sec = parseInt(match[2])
      const ms = match[3] ? parseInt(match[3].padEnd(3, '0')) : 0
      times.push(min * 60 + sec + ms / 1000)
    }
    const text = line.replace(/\[\d{2}:\d{2}(?:\.\d{2,3})?\]/g, '').trim()
    if (text && times.length > 0) {
      for (const t of times) {
        result.push({ time: t, text, translation: '' })
      }
    }
  }
  
  if (tlyricText) {
    const tlines = tlyricText.split('\n')
    for (const tline of tlines) {
      const ttimes = []
      let tmatch
      while ((tmatch = timeReg.exec(tline)) !== null) {
        const min = parseInt(tmatch[1])
        const sec = parseInt(tmatch[2])
        const ms = tmatch[3] ? parseInt(tmatch[3].padEnd(3, '0')) : 0
        ttimes.push(min * 60 + sec + ms / 1000)
      }
      const ttext = tline.replace(/\[\d{2}:\d{2}(?:\.\d{2,3})?\]/g, '').trim()
      if (ttext && ttimes.length > 0) {
        for (const t of ttimes) {
          const found = result.find(r => Math.abs(r.time - t) < 0.1 && !r.translation)
          if (found) found.translation = ttext
        }
      }
    }
  }
  
  result.sort((a, b) => a.time - b.time)
  return result
}

function updateLyricHighlight(currentTime) {
  if (!currentLyric || currentLyric.length === 0) return
  
  let activeIndex = -1
  for (let i = currentLyric.length - 1; i >= 0; i--) {
    if (currentTime >= currentLyric[i].time) {
      activeIndex = i
      break
    }
  }
  
  const fsLyricBody = document.getElementById('fs-lyric-body')
  if (fsLyricBody) {
    const fsLines = fsLyricBody.querySelectorAll('.lyric-line')
    fsLines.forEach(el => {
      const idx = parseInt(el.dataset.index)
      el.classList.toggle('lyric-active', idx === activeIndex)
    })
    const activeFsLine = fsLyricBody.querySelector(`.lyric-line[data-index="${activeIndex}"]`)
    if (activeFsLine) {
      activeFsLine.scrollIntoView({ behavior: 'smooth', block: 'center' })
    }
  }
  
  const $playerLyricLine = document.getElementById('player-lyric-line')
  if ($playerLyricLine) {
    if (activeIndex >= 0 && currentLyric[activeIndex]) {
      $playerLyricLine.textContent = currentLyric[activeIndex].text
    } else {
  const $lyricLine = document.getElementById('player-lyric-line')
  if ($lyricLine) $lyricLine.innerHTML = '&nbsp;'
    }
  }
}

function openFullscreenPlayer(fromCover = false) {
  const el = document.getElementById('fullscreen-player')
  if (!el) return
  el.classList.remove('hidden')
  if (fromCover) {
    el.classList.add('from-cover')
  } else {
    el.classList.remove('from-cover')
  }
  updateFullscreenPlayer()
  renderFsLyric()
  updateCoverExpandIcon(true)
}

function closeFullscreenPlayer() {
  const el = document.getElementById('fullscreen-player')
  if (el) {
    el.classList.add('hidden')
    el.classList.remove('from-cover')
  }
  const settingsPanel = document.getElementById('fs-lyric-settings-panel')
  if (settingsPanel) settingsPanel.classList.add('hidden')
  updateCoverExpandIcon(false)
}

function toggleFullscreenPlayer(fromCover = false) {
  const el = document.getElementById('fullscreen-player')
  if (!el) return
  if (el.classList.contains('hidden')) {
    openFullscreenPlayer(fromCover)
  } else {
    closeFullscreenPlayer()
  }
}

function updateCoverExpandIcon(isOpen) {
  const icon = document.getElementById('cover-expand-icon')
  if (icon) {
    icon.className = isOpen ? 'fas fa-chevron-down text-lg' : 'fas fa-chevron-up text-lg'
  }
}

function updateFullscreenPlayer() {
  const $fsCoverImg = document.getElementById('fs-cover-img')
  const $fsSongName = document.getElementById('fs-song-name')
  const $fsSongSinger = document.getElementById('fs-song-singer')
  const $fsSongNameM = document.getElementById('fs-song-name-m')
  const $fsSongSingerM = document.getElementById('fs-song-singer-m')
  if ($fsCoverImg) {
    if ($playerCoverImg.src && !$playerCoverImg.classList.contains('hidden')) {
      $fsCoverImg.src = $playerCoverImg.src
      $fsCoverImg.style.display = ''
    } else {
      $fsCoverImg.src = ''
      $fsCoverImg.style.display = 'none'
    }
  }
  if ($fsSongName) $fsSongName.innerHTML = $playerSong.innerHTML
  if ($fsSongSinger) $fsSongSinger.textContent = $playerSinger.textContent
  if ($fsSongNameM) $fsSongNameM.innerHTML = $playerSong.innerHTML
  if ($fsSongSingerM) $fsSongSingerM.textContent = $playerSinger.textContent
}

function renderFsLyric() {
  const $fsLyricBody = document.getElementById('fs-lyric-body')
  if (!$fsLyricBody) return
  if (!currentLyric || currentLyric.length === 0) {
    $fsLyricBody.innerHTML = '<div class="text-center lyric-placeholder mt-20">暂无歌词</div>'
    return
  }
  const sizeMap = { small: '0.85rem', medium: '1rem', large: '1.25rem' }
  const activeSizeMap = { small: '0.95rem', medium: '1.15rem', large: '1.4rem' }
  let html = '<div class="lyric-lines">'
  html += '<div class="lyric-spacer"></div>'
  currentLyric.forEach((line, i) => {
    html += `<div class="lyric-line" data-index="${i}" style="font-size:${sizeMap[lyricFontSize]}">${line.text}</div>`
    if (lyricShowTrans && line.translation) {
      html += `<div class="lyric-line lyric-trans" data-index="${i}" style="font-size:${sizeMap[lyricFontSize]};opacity:0.5;font-style:italic">${line.translation}</div>`
    }
  })
  html += '<div class="lyric-spacer"></div>'
  html += '</div>'
  $fsLyricBody.innerHTML = html
  
  const style = document.getElementById('fs-lyric-dynamic-style') || document.createElement('style')
  style.id = 'fs-lyric-dynamic-style'
  style.textContent = `#fs-lyric-body .lyric-line.lyric-active{color:${lyricColor}!important;font-size:${activeSizeMap[lyricFontSize]};font-weight:600;opacity:1!important}`
  if (!style.parentNode) document.head.appendChild(style)
  
  if (audio.currentTime > 0) {
    updateLyricHighlight(audio.currentTime)
    setTimeout(() => {
      const activeFsLine = $fsLyricBody.querySelector('.lyric-line.lyric-active')
      if (activeFsLine) activeFsLine.scrollIntoView({ behavior: 'auto', block: 'center' })
    }, 50)
  }
}

function toggleLyricSettings() {
  const panel = document.getElementById('fs-lyric-settings-panel')
  if (panel) {
    panel.classList.toggle('hidden')
    if (!panel.classList.contains('hidden')) {
      setTimeout(() => {
        document.addEventListener('click', closeLyricSettingsOutside)
      }, 10)
    } else {
      document.removeEventListener('click', closeLyricSettingsOutside)
    }
  }
}

function closeLyricSettingsOutside(e) {
  const panel = document.getElementById('fs-lyric-settings-panel')
  const btn = document.querySelector('.fs-settings-float-btn')
  if (panel && !panel.contains(e.target) && btn && !btn.contains(e.target)) {
    panel.classList.add('hidden')
    document.removeEventListener('click', closeLyricSettingsOutside)
  }
}

function setLyricFontSize(size) {
  lyricFontSize = size
  document.querySelectorAll('#lyric-font-size-options .fs-setting-opt').forEach(b => {
    b.classList.toggle('active', b.dataset.value === size)
  })
  renderFsLyric()
  try { localStorage.setItem('lyricFontSize', size) } catch(e) {}
}

function setLyricColor(color) {
  lyricColor = color
  document.querySelectorAll('#lyric-color-options .fs-color-opt').forEach(b => {
    b.classList.toggle('active', b.dataset.value === color)
  })
  renderFsLyric()
  try { localStorage.setItem('lyricColor', color) } catch(e) {}
}

function setLyricTrans(show) {
  lyricShowTrans = show
  document.getElementById('lyric-trans-on')?.classList.toggle('active', show)
  document.getElementById('lyric-trans-off')?.classList.toggle('active', !show)
  renderFsLyric()
  try { localStorage.setItem('lyricShowTrans', show) } catch(e) {}
}

// 播放列表
function updatePlaylistHighlight() {
  if (!$playlistBody) return
  $playlistBody.querySelectorAll('.playlist-item').forEach(item => {
    const idx = parseInt(item.dataset.index)
    item.classList.toggle('playing', idx === playIndex)
  })
}

function renderPlaylist() {
  $plCount.textContent = playlist.length
  if (playlist.length === 0) {
    $playlistBody.innerHTML = `
      <div class="text-center lyric-placeholder mt-20">
        <i class="fas fa-list text-4xl mb-4"></i>
        <p>播放列表为空</p>
      </div>
    `
    return
  }
  
  $playlistBody.innerHTML = playlist.map((song, i) => {
    const coverUrl = proxyImgUrl(song.img || '')
    return `
    <div class="playlist-item ${i === playIndex ? 'playing' : ''}" data-index="${i}">
      <div class="playlist-cover">
        ${coverUrl ? `<img src="${coverUrl}" alt="" class="w-full h-full object-cover" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"><i class="fas fa-music text-2xl img-placeholder-icon absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" style="display:none"></i>` : '<i class="fas fa-music text-2xl img-placeholder-icon absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"></i>'}
      </div>
      <div class="playlist-info flex-1 min-w-0">
        <div class="playlist-title">${sourceTag(song.source)}<span class="playlist-title-text">${escapeHtml(song.name || '未知')}</span></div>
        <div class="playlist-artist">${escapeHtml(song.singer || '未知')}</div>
      </div>
      <button class="playlist-remove" onclick="removeFromPlaylist(event, ${i})">
        <i class="fas fa-times"></i>
      </button>
    </div>
    `}).join('')
  
  $playlistBody.querySelectorAll('.playlist-item').forEach(item => {
    item.addEventListener('click', (e) => {
      if (e.target.closest('.playlist-remove')) return
      const index = parseInt(item.dataset.index)
      playIndex = index
      playSong(playlist[index])
    })
  })
  savePlaylistToStorage()
}

function removeFromPlaylist(e, index) {
  e.stopPropagation()
  playlist.splice(index, 1)
  if (playlist.length === 0) {
    playIndex = -1
    audio.pause()
    audio.src = ''
    $playerSong.textContent = '未播放'
    $playerSinger.textContent = '选择一首歌曲开始'
    isPlaying = false
    updatePlayBtn()
  } else if (index === playIndex) {
    playIndex = index % playlist.length
    playSong(playlist[playIndex])
  } else if (index < playIndex) {
    playIndex--
  }
  renderPlaylist()
}

function savePlaylistToStorage() {
  try {
    const data = { playlist, playIndex, currentPlatform }
    localStorage.setItem('playerPlaylist', JSON.stringify(data))
  } catch(e) {}
}

function loadPlaylistFromStorage() {
  try {
    const raw = localStorage.getItem('playerPlaylist')
    if (!raw) return
    const data = JSON.parse(raw)
    if (data.playlist && Array.isArray(data.playlist) && data.playlist.length > 0) {
      playlist = data.playlist
      playIndex = typeof data.playIndex === 'number' && data.playIndex < playlist.length ? data.playIndex : 0
      renderPlaylist()
    }
    if (data.currentPlatform) {
      currentPlatform = data.currentPlatform
      updatePlatformDisplay()
      searchSource = data.currentPlatform
      updateSearchDisplay()
      updateSearchSourceTags()
      renderPlatformGrid()
    }
  } catch(e) {}
}

// 工具函数
function showLoading() {
  document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none')
  document.getElementById('tab-loading').style.display = ''
}

function hideLoading() {
  document.getElementById('tab-loading').style.display = 'none'
}

function showEmpty(msg) {
  document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none')
  document.getElementById('empty-msg').textContent = msg || '暂无数据'
  document.getElementById('tab-empty').style.display = ''
}

function fmtTime(s) {
  if (!s) return '--/--'
  if (typeof s === 'string') {
    if (/^\d+:\d{2}$/.test(s)) return s
    const n = parseInt(s)
    if (isNaN(n)) return s
    s = n
  }
  if (isNaN(s)) return '--/--'
  const m = Math.floor(s / 60)
  const sec = Math.floor(s % 60)
  return `${m}:${sec < 10 ? '0' : ''}${sec}`
}

function htmlEscape(s) {
  if (!s) return ''
  const d = document.createElement('div')
  d.textContent = s
  return d.innerHTML
}

function proxyImgUrl(url) {
  if (!url) return ''
  if (window.location.protocol === 'https:' && url.startsWith('http://')) {
    return `/api/music/audio-proxy?url=${encodeURIComponent(url)}`
  }
  return url
}

async function apiFetch(path) {
  try {
    const res = await fetch(`${API}${path}`)
    
    if (!res.ok) {
      throw new Error(`HTTP 错误：${res.status} ${res.statusText}`)
    }
    
    const contentType = res.headers.get('content-type')
    if (!contentType || !contentType.includes('application/json')) {
      console.error('[API] 响应不是 JSON 格式:', res.headers.get('content-type'))
      const text = await res.text()
      console.error('[API] 响应内容:', text.substring(0, 200))
      throw new Error('API 返回了非 JSON 响应')
    }
    
    const json = await res.json()
    if (json.code === 200) return json.data
    throw new Error(json.error || json.msg || '请求失败')
  } catch (e) {
    console.error('[API] 请求失败:', path, e.message)
    throw e
  }
}

// 可视化
function initVisualizer() {
  const canvas = document.getElementById('visualizer-canvas')
  const ctx = canvas.getContext('2d')
  
  canvas.width = window.innerWidth
  canvas.height = window.innerHeight
  
  let audioContext, analyser, source
  const dataArray = new Uint8Array()
  
  function setup() {
    if (!audioContext) {
      audioContext = new (window.AudioContext || window.webkitAudioContext)()
      analyser = audioContext.createAnalyser()
      analyser.fftSize = 256
      source = audioContext.createMediaElementSource(audio)
      source.connect(analyser)
      analyser.connect(audioContext.destination)
      dataArray.length = analyser.frequencyBinCount
    }
  }
  
  function render() {
    requestAnimationFrame(render)
    
    if (!analyser) {
      setup()
      return
    }
    
    analyser.getByteFrequencyData(dataArray)
    
    ctx.fillStyle = 'rgb(0, 0, 0)'
    ctx.fillRect(0, 0, canvas.width, canvas.height)
    
    const barWidth = (canvas.width / dataArray.length) * 2.5
    let barHeight
    let x = 0
    
    for (let i = 0; i < dataArray.length; i++) {
      barHeight = dataArray[i] * 2
      
      const gradient = ctx.createLinearGradient(0, canvas.height, 0, canvas.height - barHeight)
      gradient.addColorStop(0, '#1db954')
      gradient.addColorStop(1, '#1ed760')
      
      ctx.fillStyle = gradient
      ctx.fillRect(x, canvas.height - barHeight, barWidth, barHeight)
      
      x += barWidth + 1
    }
  }
  
  render()
  
  window.addEventListener('resize', () => {
    canvas.width = window.innerWidth
    canvas.height = window.innerHeight
  })
}

function insertBackBar(label) {
  const backHtml = `<div class="search-back-bar fade-in">
    <button class="toolbar-action-btn" onclick="goBackFromDetail()"><i class="fas fa-arrow-left"></i> ${label}</button>
    <div class="search-back-bar-right">
      <button class="toolbar-action-btn" onclick="playAllSearch()"><i class="fas fa-play"></i> <span class="btn-text-full">播放全部</span><span class="btn-text-mobile">全部</span></button>
      <button class="toolbar-action-btn" onclick="addSelectedToPlaylist()"><i class="fas fa-plus"></i> <span class="btn-text-full">添加到</span><span class="btn-text-mobile">添加</span></button>
    </div>
  </div>`
  $searchBody.insertAdjacentHTML('afterbegin', backHtml)
}

function goBackFromDetail() {
  if (playlistDetailSource === 'songlist-search') {
    backToSonglistSearch()
  } else {
    document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none')
    const targetTab = previousTab || 'recommend'
    if (targetTab === 'leaderboard') {
      if (leaderboardList.length > 0) {
        renderLeaderboardLayout()
      } else {
        showLeaderboard()
      }
    } else {
      const targetEl = document.getElementById(`tab-${targetTab}`)
      if (targetEl) {
        if (targetTab === 'recommend' && previousTabHtmlCache) {
          $recommendBody.innerHTML = previousTabHtmlCache
        }
        targetEl.style.display = ''
      }
    }
    currentTab = targetTab
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === targetTab))
    document.querySelectorAll('.tab-btn-m').forEach(b => b.classList.toggle('active', b.dataset.tab === targetTab))
  }
  const mainContent = document.getElementById('main-content')
  if (mainContent) mainContent.scrollTop = 0
}

function backToSonglistSearch() {
  document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none')
  document.getElementById('tab-search').style.display = ''
  $searchToolbar.style.display = ''
  updateSearchToolbar()
  $searchBody.innerHTML = searchSonglistHtmlCache
  $searchPagination.innerHTML = searchSonglistPagCache
  bindSonglistClicks()
  const mainContent = document.getElementById('main-content')
  if (mainContent) mainContent.scrollTop = 0
}

function bindSonglistClicks() {
  $searchBody.querySelectorAll('.search-result-item').forEach(item => {
    item.addEventListener('click', () => {
      const index = parseInt(item.dataset.index)
      playlistDetailSource = 'songlist-search'
      showPlaylistDetail(searchSonglistList[index].id)
    })
  })
}

async function showPlaylistDetail(playlistId) {
  if (playlistDetailSource !== 'songlist-search') {
    playlistDetailSource = currentTab === 'search' ? 'search' : 'other'
  }
  const detailSource = (currentTab === 'search' || playlistDetailSource === 'songlist-search' || playlistDetailSource === 'search') ? searchSource : currentPlatform
  previousTab = currentTab
  if (currentTab === 'recommend') {
    previousTabHtmlCache = $recommendBody.innerHTML
  } else if (currentTab === 'leaderboard') {
    previousTabHtmlCache = $leaderboardBody.innerHTML
  }
  showLoading()
  try {
    const data = await apiFetch(`/songlist/detail?source=${detailSource}&id=${playlistId}&page=1`)
    if (data && data.list) {
      searchSongList = data.list
      $searchToolbar.style.display = 'none'
      hideLoading()
      renderSearchResults(data.list, data.total, data.allPage, 1)
      const backLabel = playlistDetailSource === 'songlist-search' ? '返回歌单列表' : `返回${previousTab === 'leaderboard' ? '排行榜' : '推荐'}`
      insertBackBar(backLabel)
      const mainContent = document.getElementById('main-content')
      if (mainContent) mainContent.scrollTop = 0
    } else {
      showEmpty('暂无歌曲')
    }
  } catch (e) {
    showEmpty('加载失败：' + e.message)
  }
}

// 启动应用
init()
