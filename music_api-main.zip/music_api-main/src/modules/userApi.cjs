const { VM } = require('vm2')
const fs = require('fs')
const path = require('path')
const needle = require('needle')
const crypto = require('crypto')
const zlib = require('zlib')
const { promisify } = require('util')

const inflate = promisify(zlib.inflate)
const deflate = promisify(zlib.deflate)

function decontextify(obj) {
  if (obj === null || obj === undefined) return obj
  if (typeof obj !== 'object') return obj
  try {
    if (Buffer.isBuffer(obj) || obj instanceof Uint8Array || (obj && obj.constructor && obj.constructor.name === 'Buffer')) {
      return Buffer.from(Uint8Array.from(obj))
    }
  } catch (e) { }
  if (Array.isArray(obj)) {
    try { return obj.map(item => decontextify(item)) } catch (e) { return [] }
  }
  if (obj instanceof Error || (obj && obj.constructor && obj.constructor.name === 'Error')) {
    const err = new Error(obj.message)
    err.stack = obj.stack
    return err
  }
  try {
    const newObj = {}
    const keys = Object.keys(obj)
    for (const key of keys) {
      try { newObj[key] = decontextify(obj[key]) } catch (e) { }
    }
    return newObj
  } catch (e) {
    try {
      const str = JSON.stringify(obj)
      return str ? JSON.parse(str) : String(obj)
    } catch (e2) {
      return String(obj)
    }
  }
}

const loadedApis = new Map()
const apiStatus = new Map()
const initCache = new Map()
const INIT_CACHE_TTL = 60000

function getApiStatus(id) {
  return apiStatus.get(id)
}

function extractMetadata(script) {
  const meta = {}
  const commentMatch = script.match(/\/\*[*!]([\s\S]*?)\*\//)
  if (commentMatch) {
    const comment = commentMatch[1]
    const nameMatch = comment.match(/@name\s+(.+)/)
    if (nameMatch) meta.name = nameMatch[1].trim()
    const descMatch = comment.match(/@description\s+(.+)/)
    if (descMatch) meta.description = descMatch[1].trim()
    const verMatch = comment.match(/@version\s+(.+)/)
    if (verMatch) meta.version = verMatch[1].trim()
    const authorMatch = comment.match(/@author\s+(.+)/)
    if (authorMatch) meta.author = authorMatch[1].trim()
    const repoMatch = comment.match(/@(?:repository|homepage)\s+(.+)/)
    if (repoMatch) meta.homepage = repoMatch[1].trim()
  }
  if (!meta.name) {
    const platMatch = script.match(/platform\s*[:=]\s*['"]([^'"]+)['"]/)
    if (platMatch) meta.name = platMatch[1].trim()
  }
  if (!meta.version) {
    const verMatch2 = script.match(/version\s*[:=]\s*['"]([^'"]+)['"]/)
    if (verMatch2) meta.version = verMatch2[1].trim()
  }
  if (!meta.author) {
    const authMatch2 = script.match(/author\s*[:=]\s*['"]([^'"]+)['"]/)
    if (authMatch2) meta.author = authMatch2[1].trim()
  }
  return meta
}

function createLxRequest(isUnsafe) {
  return (url, options, callback) => {
    const safeOptions = decontextify(options || {})
    const { method = 'get', timeout, headers, body, form, formData, rejectUnauthorized } = safeOptions
    let requestOptions = {
      headers,
      response_timeout: typeof timeout === 'number' && timeout > 0 ? Math.min(timeout, 60000) : 60000,
      rejectUnauthorized: rejectUnauthorized !== undefined ? rejectUnauthorized : false,
    }
    let data = body
    if (form) { data = form; requestOptions.json = false }
    else if (formData) { data = formData; requestOptions.json = false }
    const request = needle.request(method, url, data, requestOptions, (err, resp, body) => {
      try {
        if (err) { callback.call(null, decontextify(err), null, null) }
        else {
          let parsedBody = body
          if (typeof body === 'string') { try { parsedBody = JSON.parse(body) } catch { } }
          let safeResp = { statusCode: resp.statusCode, statusMessage: resp.statusMessage, headers: resp.headers, body: decontextify(parsedBody) }
          if (isUnsafe) {
            const jsonBody = (typeof parsedBody === 'object' && !Buffer.isBuffer(parsedBody)) ? JSON.parse(JSON.stringify(parsedBody)) : parsedBody
            safeResp = JSON.parse(JSON.stringify({ statusCode: resp.statusCode, statusMessage: resp.statusMessage, headers: resp.headers }))
            safeResp.body = jsonBody
          }
          callback.call(null, null, safeResp, safeResp.body)
        }
      } catch (error) {
        callback.call(null, decontextify(error), null, null)
      }
    })
    return () => { const reqObj = request.request; if (reqObj && !reqObj.aborted) reqObj.abort() }
  }
}

function isMusicFreePlugin(script) {
  if (/module\.exports\s*=/.test(script) && !/globalThis\s*\[\s*['"]lx['"]\s*\]/.test(script) && !/lx\s*\.\s*on\s*\(/.test(script)) return true
  if (/exports\.\w+\s*=/.test(script) && /\bplatform\s*[:=]/.test(script) && /\bsearch\s*[:=]/.test(script)) return true
  return false
}

function createFetchPolyfill() {
  return async (url, options) => {
    const opts = options || {}
    const method = (opts.method || 'GET').toUpperCase()
    const headers = opts.headers || {}
    const body = opts.body
    const needleOpts = {
      headers,
      response_timeout: 30000,
      rejectUnauthorized: false,
      json: false,
    }
    return new Promise((resolve, reject) => {
      needle.request(method, url, body, needleOpts, (err, resp, respBody) => {
        if (err) return reject(err)
        const ok = resp.statusCode >= 200 && resp.statusCode < 300
        const response = {
          ok,
          status: resp.statusCode,
          statusText: resp.statusMessage || '',
          headers: resp.headers || {},
          url,
          _rawBody: respBody,
          json() { try { return Promise.resolve(typeof respBody === 'string' ? JSON.parse(respBody) : respBody) } catch(e) { return Promise.reject(e) } },
          text() { return Promise.resolve(typeof respBody === 'string' ? respBody : (Buffer.isBuffer(respBody) ? respBody.toString('utf-8') : String(respBody))) },
        }
        resolve(response)
      })
    })
  }
}

function adaptMusicFreePlugin(mfPlugin, eventHandlers, registeredSources, fullApiInfo, initResolve) {
  const platform = mfPlugin.platform || fullApiInfo.name || 'unknown'
  const sourceId = platform.toLowerCase().replace(/[^a-z0-9]/g, '')
  const sourceName = mfPlugin.platform || fullApiInfo.name

  const actions = ['musicUrl']
  if (typeof mfPlugin.search === 'function') actions.push('search')
  if (typeof mfPlugin.getLyric === 'function') actions.push('lyric')
  if (typeof mfPlugin.getAlbumInfo === 'function') actions.push('getAlbumInfo')
  if (typeof mfPlugin.getMusicSheetInfo === 'function') actions.push('getMusicSheetInfo')
  if (typeof mfPlugin.getArtistWorks === 'function') actions.push('getArtistWorks')
  if (typeof mfPlugin.getTopLists === 'function') actions.push('getTopLists')
  if (typeof mfPlugin.getTopListDetail === 'function') actions.push('getTopListDetail')
  if (typeof mfPlugin.importMusicSheet === 'function') actions.push('importMusicSheet')

  const qualityMap = { '128k': 'standard', '192k': 'standard', '320k': 'high', 'flac': 'lossless', '24bit': 'lossless' }
  const reverseQualityMap = { 'standard': '128k', 'high': '320k', 'lossless': 'flac' }

  registeredSources[sourceId] = {
    name: sourceName,
    type: 'music',
    actions,
    qualitys: ['128k', '320k', 'flac'],
  }

  const requestHandler = async ({ action, source, musicInfo, info, keyword, page, type, quality }) => {
    switch (action) {
      case 'musicUrl': {
        if (typeof mfPlugin.getMediaSource !== 'function') throw new Error('插件不支持获取播放链接')
        const mfQuality = qualityMap[quality] || 'high'
        let songItem = musicInfo || info
        if (songItem && !songItem.id) songItem = { ...songItem, id: songItem.songmid || songItem.id }
        const result = await mfPlugin.getMediaSource(songItem, mfQuality)
        if (!result) throw new Error('未获取到播放链接')
        const url = (result && typeof result === 'object') ? (result.url || result.src) : result
        return { url, type: quality }
      }
      case 'search': {
        if (typeof mfPlugin.search !== 'function') throw new Error('插件不支持搜索')
        const searchType = type || 'music'
        const result = await mfPlugin.search(keyword, page || 1, searchType)
        if (!result) return { isEnd: true, data: [] }
        const list = (result.data || []).map(item => ({
          name: item.title || item.name || '',
          singer: item.artist || item.author || '',
          album: item.album || '',
          songmid: item.id || item.songmid || '',
          img: item.artwork || item.pic || item.cover || '',
          source: sourceId,
          duration: item.duration || 0,
          _mfRaw: item,
        }))
        return { isEnd: result.isEnd !== undefined ? result.isEnd : true, data: list, total: result.total || list.length }
      }
      case 'lyric': {
        if (typeof mfPlugin.getLyric !== 'function') throw new Error('插件不支持歌词')
        const lyricItem = musicInfo || info
        const lrcItem = (lyricItem && lyricItem._mfRaw) ? lyricItem._mfRaw : lyricItem
        const result = await mfPlugin.getLyric(lrcItem || lyricItem)
        if (!result) return ''
        return { lyric: result.rawLrc || result.lrc || result.lyric || '', translation: result.translation || result.trc || '' }
      }
      case 'getAlbumInfo': {
        if (typeof mfPlugin.getAlbumInfo !== 'function') throw new Error('插件不支持专辑信息')
        const albumItem = musicInfo || info
        return await mfPlugin.getAlbumInfo((albumItem && albumItem._mfRaw) ? albumItem._mfRaw : albumItem)
      }
      case 'getMusicSheetInfo': {
        if (typeof mfPlugin.getMusicSheetInfo !== 'function') throw new Error('插件不支持歌单信息')
        const sheetItem = musicInfo || info
        const result = await mfPlugin.getMusicSheetInfo((sheetItem && sheetItem._mfRaw) ? sheetItem._mfRaw : sheetItem, page || 1)
        return result
      }
      case 'getArtistWorks': {
        if (typeof mfPlugin.getArtistWorks !== 'function') throw new Error('插件不支持歌手作品')
        const artistItem = musicInfo || info
        const result = await mfPlugin.getArtistWorks((artistItem && artistItem._mfRaw) ? artistItem._mfRaw : artistItem, page || 1, type || 'music')
        return result
      }
      case 'getTopLists': {
        if (typeof mfPlugin.getTopLists !== 'function') throw new Error('插件不支持排行榜')
        return await mfPlugin.getTopLists()
      }
      case 'getTopListDetail': {
        if (typeof mfPlugin.getTopListDetail !== 'function') throw new Error('插件不支持排行榜详情')
        const topItem = musicInfo || info
        const result = await mfPlugin.getTopListDetail((topItem && topItem._mfRaw) ? topItem._mfRaw : topItem, page || 1)
        if (result && result.data) {
          result.data = result.data.map(item => ({
            name: item.title || item.name || '',
            singer: item.artist || item.author || '',
            album: item.album || '',
            songmid: item.id || item.songmid || '',
            img: item.artwork || item.pic || item.cover || '',
            source: sourceId,
            duration: item.duration || 0,
            _mfRaw: item,
          }))
        }
        return result
      }
      case 'importMusicSheet': {
        if (typeof mfPlugin.importMusicSheet !== 'function') throw new Error('插件不支持导入歌单')
        return await mfPlugin.importMusicSheet(musicInfo || info)
      }
      default:
        throw new Error(`不支持的操作: ${action}`)
    }
  }

  eventHandlers.set('request', requestHandler)

  if (initResolve) initResolve()

  console.log(`[UserApi-MF] ✓ MusicFree插件适配完成: ${sourceName} (sourceId: ${sourceId})`)
  console.log(`[UserApi-MF]   支持操作: ${actions.join(', ')}`)
}

async function loadUserApi(apiInfo, skipCache = false) {
  const cacheKey = apiInfo.id
  const now = Date.now()
  
  if (skipCache) {
    initCache.delete(cacheKey)
  }
  
  const cached = initCache.get(cacheKey)
  if (!skipCache && cached) {
    if (cached.loading) {
      console.log(`[UserApi] ${apiInfo.name || apiInfo.id} 正在加载中，跳过重复加载`)
      return cached.promise
    }
    if (cached.success && (now - cached.timestamp < INIT_CACHE_TTL)) {
      console.log(`[UserApi] ${apiInfo.name || apiInfo.id} 使用缓存 (${Math.round((now - cached.timestamp) / 1000)}秒前加载成功)`)
      return cached.result
    }
    if (cached.failed && (now - cached.timestamp < INIT_CACHE_TTL)) {
      console.log(`[UserApi] ${apiInfo.name || apiInfo.id} 缓存失败状态，跳过加载`)
      return cached.result
    }
  }

  const isMF = isMusicFreePlugin(apiInfo.script)
  if (isMF) console.log(`[UserApi] 检测到 MusicFree 格式插件: ${apiInfo.name || apiInfo.id}`)

  const metadata = extractMetadata(apiInfo.script)
  const fullApiInfo = { ...apiInfo, ...metadata }
  const eventHandlers = new Map()
  let registeredSources = {}
  let initResolve = null
  let initReject = null
  const initPromise = new Promise((resolve, reject) => { initResolve = resolve; initReject = reject })

  initCache.set(cacheKey, { loading: true, timestamp: now, promise: initPromise })

  const lxDataInside = {
    version: '2.0.0', env: 'desktop', platform: 'web',
    currentScriptInfo: { name: fullApiInfo.name, description: fullApiInfo.description, version: fullApiInfo.version, author: fullApiInfo.author, homepage: fullApiInfo.homepage, rawScript: fullApiInfo.script },
    EVENT_NAMES: { request: 'request', inited: 'inited', updateAlert: 'updateAlert' }
  }

  const lxUtils = {
    buffer: {
      from: (d, e) => Buffer.from(decontextify(d), decontextify(e)),
      bufToString: (b, f) => Buffer.isBuffer(b) ? b.toString(f) : Buffer.from(b, 'binary').toString(f)
    },
    crypto: {
      md5: (str) => crypto.createHash('md5').update((decontextify(str) || '')).digest('hex'),
      aesEncrypt: (buffer, mode, key, iv) => {
        const dKey = decontextify(key); const dIv = decontextify(iv); const dBuffer = decontextify(buffer)
        const algorithm = `aes-${dKey.length * 8}-${mode}`
        const cipher = crypto.createCipheriv(algorithm, dKey, dIv)
        return Buffer.concat([cipher.update(dBuffer), cipher.final()])
      },
      rsaEncrypt: (buffer, key) => crypto.publicEncrypt(decontextify(key), decontextify(buffer)),
      randomBytes: (size) => crypto.randomBytes(size),
    },
    zlib: { inflate: (buffer) => inflate(decontextify(buffer)), deflate: (buffer) => deflate(decontextify(buffer)) }
  }

  const lxObject = {
    ...lxDataInside, utils: lxUtils, request: createLxRequest(!!apiInfo.allowUnsafeVM),
    send: (eventName, data) => {
      const dData = decontextify(data)
      if (eventName === 'inited') {
        if (dData && dData.sources) {
          registeredSources = dData.sources
          console.log(`[UserApi-${fullApiInfo.name}] Registered sources:`, Object.keys(registeredSources).join(', '))
        }
        if (initResolve) initResolve()
      } else if (eventName === 'updateAlert') {
        console.warn(`[UserApi-${fullApiInfo.name}] 脚本报告发现新版本:`, JSON.stringify(dData))
        if (initReject) initReject(new Error(`发现新版本,需要更新: ${JSON.stringify(dData)}`))
      }
    },
    on: (eventName, handler) => {
      if (eventName === 'request') {
        eventHandlers.set(eventName, handler)
      }
    }
  }

  const safeConsole = {
    log: console.log.bind(console),
    info: console.info.bind(console),
    warn: console.warn.bind(console),
    error: console.error.bind(console),
    debug: console.debug ? console.debug.bind(console) : console.log.bind(console),
    group: console.group ? console.group.bind(console) : (() => {}),
    groupEnd: console.groupEnd ? console.groupEnd.bind(console) : (() => {}),
    groupCollapsed: console.groupCollapsed ? console.groupCollapsed.bind(console) : (() => {}),
    trace: console.trace ? console.trace.bind(console) : console.log.bind(console),
    dir: console.dir ? console.dir.bind(console) : console.log.bind(console),
    table: console.table ? console.table.bind(console) : console.log.bind(console),
    time: console.time ? console.time.bind(console) : (() => {}),
    timeEnd: console.timeEnd ? console.timeEnd.bind(console) : (() => {}),
    count: console.count ? console.count.bind(console) : (() => {}),
    countReset: console.countReset ? console.countReset.bind(console) : (() => {}),
    assert: console.assert ? console.assert.bind(console) : (() => {}),
    clear: console.clear ? console.clear.bind(console) : (() => {}),
  }

  const mfModuleExports = {}
  const mfModule = { exports: mfModuleExports }

  const sandbox = {
    console: safeConsole, setTimeout, clearTimeout, setInterval, clearInterval, Buffer, URL, URLSearchParams, TextEncoder, TextDecoder,
    process: { 
      nextTick: (fn, ...args) => setTimeout(() => fn(...args), 0), 
      env: { NODE_ENV: process.env.NODE_ENV || 'production' },
      on: (event, handler) => {
        if (event === 'unhandledRejection') {
          process.on('unhandledRejection', (reason, promise) => {
            console.error(`[UserApi-${fullApiInfo.name}] 未处理的 Promise 拒绝:`, reason)
            if (initReject) initReject(new Error(`脚本运行错误：${reason}`))
          })
        }
      }
    },
    Lx: lxObject, lx: lxObject,
    module: mfModule, exports: mfModuleExports,
    require: (mod) => {
      if (mod === 'https' || mod === 'http') return require(mod)
      if (mod === 'url') return require(mod)
      if (mod === 'crypto') return crypto
      if (mod === 'zlib') return zlib
      if (mod === 'path') return require(mod)
      if (mod === 'stream') return require(mod)
      if (mod === 'buffer') return { Buffer }
      throw new Error(`模块 ${mod} 不允许在沙箱中加载`)
    },
    fetch: createFetchPolyfill(),
    global: null, window: null, globalThis: null,
    atob: (s) => Buffer.from(s, 'base64').toString('binary'),
    btoa: (s) => Buffer.from(s, 'binary').toString('base64'),
    crypto: crypto,
    XMLHttpRequest: undefined,
  }
  sandbox.global = sandbox
  sandbox.window = sandbox
  sandbox.globalThis = sandbox

  try {
    if (apiInfo.allowUnsafeVM) {
      console.log(`[UserApi] ${fullApiInfo.name} 正在以原生 VM 模式启动...`)
      const vm = require('vm')
      const context = vm.createContext(sandbox)
      
      const wrappedScript = `
        (function() {
          try {
            ${apiInfo.script}
          } catch (e) {
            console.error('[UserApi] 脚本执行错误:', e.message);
            throw e;
          }
        })();
      `
      
      vm.runInContext(wrappedScript, context, { filename: `script_${fullApiInfo.id}.js`, timeout: 10000 })
    } else {
      try {
        const vmInstance = new VM({ timeout: 10000, sandbox, eval: true, wasm: false })
        
        const wrappedScript = `
          (function() {
            try {
              ${apiInfo.script}
            } catch (e) {
              console.error('[UserApi] 脚本执行错误:', e.message);
              throw e;
            }
          })();
        `
        
        vmInstance.run(wrappedScript)
      } catch (e) {
        const isContextError = e.message.includes('contextified object') || e.message.includes('Operation not allowed')
        if (isContextError) {
          console.warn(`[UserApi] ${fullApiInfo.name} 触发 vm2 安全限制`)
          throw new Error('REQUIRE_UNSAFE_VM')
        }
        throw e
      }
    }

    if (isMF) {
      const mfExports = mfModule.exports
      if (mfExports && typeof mfExports === 'object' && (mfExports.platform || mfExports.search || mfExports.getMediaSource)) {
        adaptMusicFreePlugin(mfExports, eventHandlers, registeredSources, fullApiInfo, initResolve)
      } else {
        throw new Error('MusicFree 插件未导出有效对象 (缺少 platform/search/getMediaSource)')
      }
    }

    try {
      await Promise.race([
        initPromise, 
        new Promise((_, reject) => setTimeout(() => reject(new Error('初始化超时（10秒）')), 10000))
      ])
    } catch (initError) {
      console.error(`[UserApi] ${fullApiInfo.name} 初始化失败:`, initError.message)
      throw initError
    }

    const apiInstance = {
      info: { ...fullApiInfo, sources: registeredSources, enabled: apiInfo.enabled !== false, isMusicFree: isMF },
      handlers: eventHandlers,
      callRequest: async (action, source, info) => {
        try {
          const handler = eventHandlers.get('request')
          if (!handler) throw new Error(`源 ${fullApiInfo.name} 未注册 request 处理器`)
          let inputData = { action, source, ...info, info }
          if (apiInfo.allowUnsafeVM) { inputData = JSON.parse(JSON.stringify(inputData)) }
          const result = await handler(inputData)
          return decontextify(result)
        } catch (e) {
          console.error(`[UserApi-${fullApiInfo.name}] callRequest Error:`, e.message)
          throw e
        }
      }
    }

    loadedApis.set(apiInfo.id, apiInstance)
    console.log(`[UserApi] ✓ 成功加载: ${fullApiInfo.name} v${fullApiInfo.version}`)
    console.log(`[UserApi]   支持源: ${Object.keys(registeredSources).join(', ')}`)
    
    initCache.set(cacheKey, { 
      loading: false, 
      success: true, 
      timestamp: Date.now(), 
      result: { success: true, apiInstance, error: null } 
    })
    
    return { success: true, apiInstance, error: null }
  } catch (error) {
    console.error(`[UserApi] ✗ 加载失败 ${fullApiInfo.name}:`, error.message)
    console.error(`[UserApi] 提示: 该源初始化失败，但不影响其他源运行`)
    
    initCache.set(cacheKey, { 
      loading: false, 
      failed: true, 
      timestamp: Date.now(), 
      result: { success: false, apiInstance: null, error: error.message, requireUnsafe: error.message === 'REQUIRE_UNSAFE_VM' } 
    })
    
    return { success: false, apiInstance: null, error: error.message, requireUnsafe: error.message === 'REQUIRE_UNSAFE_VM' }
  }
}

function normalizeSongInfo(songInfo) {
  const normalized = { ...songInfo }
  if (songInfo.meta) {
    Object.assign(normalized, songInfo.meta)
    if (songInfo.meta.songId && !normalized.songmid) normalized.songmid = songInfo.meta.songId
    if (songInfo.meta.picUrl && !normalized.img) normalized.img = songInfo.meta.picUrl
    if (songInfo.meta.hash && !normalized.hash) normalized.hash = songInfo.meta.hash
    if (songInfo.meta.albumId && !normalized.albumId) normalized.albumId = songInfo.meta.albumId
    if (songInfo.meta.copyrightId && !normalized.copyrightId) normalized.copyrightId = songInfo.meta.copyrightId
    if (songInfo.meta.strMediaMid && !normalized.strMediaMid) normalized.strMediaMid = songInfo.meta.strMediaMid
    if (songInfo.meta.albumMid && !normalized.albumMid) normalized.albumMid = songInfo.meta.albumMid
    if (songInfo.meta.lrcUrl && !normalized.lrcUrl) normalized.lrcUrl = songInfo.meta.lrcUrl
    if (songInfo.meta.mrcUrl && !normalized.mrcUrl) normalized.mrcUrl = songInfo.meta.mrcUrl
    if (songInfo.meta.trcUrl && !normalized.trcUrl) normalized.trcUrl = songInfo.meta.trcUrl
  }
  return normalized
}

function getCandidatesForSource(source) {
  const candidates = []
  const metaPath = path.join(getScriptRoot(), 'sources.json')
  let sourcesMeta = []
  try {
    if (fs.existsSync(metaPath)) {
      sourcesMeta = JSON.parse(fs.readFileSync(metaPath, 'utf-8'))
    }
  } catch (e) {}

  for (const [apiId, api] of loadedApis) {
    if (!api.info.enabled) continue
    if (!api.info.sources || !api.info.sources[source]) continue

    const meta = sourcesMeta.find(m => m.id === apiId)
    const enabledSources = meta ? (meta.enabledSources || meta.supportedSources || []) : null
    if (enabledSources && !enabledSources.includes(source)) continue

    candidates.push(api)
  }
  return candidates
}

function disablePlatformForApi(apiId, source) {
  try {
    const metaPath = path.join(getScriptRoot(), 'sources.json')
    if (!fs.existsSync(metaPath)) return false
    const sourcesMeta = JSON.parse(fs.readFileSync(metaPath, 'utf-8'))
    const meta = sourcesMeta.find(m => m.id === apiId)
    if (!meta) return false
    const base = meta.enabledSources || meta.supportedSources || []
    if (!base.includes(source)) return false
    meta.enabledSources = base.filter(s => s !== source)
    fs.writeFileSync(metaPath, JSON.stringify(sourcesMeta, null, 2))
    console.warn(`[UserApi] 已关闭脚本 ${apiId} 的 ${source} 平台解析`)
    return true
  } catch (e) {
    console.error(`[UserApi] 关闭 ${apiId} 的 ${source} 平台失败:`, e.message)
    return false
  }
}

async function callUserApiGetMusicUrl(source, songInfo, quality) {
  const normalizedSongInfo = normalizeSongInfo(songInfo)

  const candidates = []
  for (const [apiId, api] of loadedApis) {
    if (!api.info.enabled) continue
    if (!api.info.sources || !api.info.sources[source]) continue
    candidates.push(api)
  }

  if (candidates.length === 0) {
    throw new Error(`未找到支持 ${source} 平台的规则脚本`)
  }

  let lastError = null
  const results = []

  for (const api of candidates) {
    try {
      console.log(`[UserApi] 尝试 ${api.info.name} 获取 ${source} 音乐链接`)
      const result = await api.callRequest('musicUrl', source, { musicInfo: normalizedSongInfo, quality, type: quality })
      const url = (result && typeof result === 'object') ? (result.url || result.musicUrl || result.src) : result
      console.log(`[UserApi] ✓ ${api.info.name} 成功返回链接`)
      results.push({ url, type: quality, sourceName: api.info.name })
    } catch (error) {
      lastError = error
      console.error(`[UserApi] ✗ ${api.info.name} 获取失败:`, error.message)
    }
  }

  if (results.length === 0) {
    const finalError = new Error(`所有规则脚本获取 ${source} 链接失败 (${lastError?.message})`)
    throw finalError
  }

  return results.length === 1 ? results[0] : results
}

function getScriptRoot() {
  return path.join(__dirname, '..', '..', 'Script')
}

async function loadAllScripts() {
  const scriptRoot = getScriptRoot()
  const stats = { loadedCount: 0 }

  console.log(`[UserApi] ========================================`)
  if (!fs.existsSync(scriptRoot)) {
    fs.mkdirSync(scriptRoot, { recursive: true })
    console.log(`[UserApi] 创建脚本目录: ${scriptRoot}`)
    console.log(`[UserApi] ========================================`)
    return
  }

  console.log(`[UserApi] 初始化规则脚本: ${scriptRoot}`)
  loadedApis.clear()
  apiStatus.clear()

  const metaPath = path.join(scriptRoot, 'sources.json')
  if (!fs.existsSync(metaPath)) {
    console.log(`[UserApi] sources.json 不存在`)
    console.log(`[UserApi] ========================================`)
    return
  }

  try {
    const sources = JSON.parse(fs.readFileSync(metaPath, 'utf-8'))
    let needsSave = false
    for (const source of sources) {
      if (!source.enabled) {
        apiStatus.set(source.id, { status: 'disabled' })
        continue
      }
      const scriptPath = path.join(scriptRoot, source.id)
      let resolvedScriptPath = scriptPath
      if (!fs.existsSync(scriptPath)) {
        if (fs.existsSync(scriptPath + '.js')) {
          resolvedScriptPath = scriptPath + '.js'
        } else {
          console.warn(`[UserApi] 脚本文件未找到: ${source.id}`)
          continue
        }
      }
      try {
        const script = fs.readFileSync(resolvedScriptPath, 'utf-8')
        const metadata = extractMetadata(script)
        const result = await loadUserApi({
          id: source.id,
          name: metadata.name || source.name,
          description: metadata.description || '',
          version: metadata.version || 1,
          author: metadata.author || '',
          homepage: metadata.homepage || '',
          script,
          sources: {},
          enabled: source.enabled,
          allowUnsafeVM: source.allowUnsafeVM,
        })
        if (result.success) {
          stats.loadedCount++
          apiStatus.set(source.id, { status: 'success' })
          const runtimeSources = Object.keys(result.apiInstance.info.sources).sort()
          const storedSources = (source.supportedSources || []).sort()
          if (JSON.stringify(runtimeSources) !== JSON.stringify(storedSources)) {
            source.supportedSources = runtimeSources
            needsSave = true
          }
          const metadata = extractMetadata(result.apiInstance.info.rawScript || '')
          if (metadata.version && source.version !== metadata.version) { source.version = metadata.version; needsSave = true }
          if (metadata.author && source.author !== metadata.author) { source.author = metadata.author; needsSave = true }
          if (metadata.description && source.description !== metadata.description) { source.description = metadata.description; needsSave = true }
          if (metadata.homepage && source.homepage !== metadata.homepage) { source.homepage = metadata.homepage; needsSave = true }
        } else {
          apiStatus.set(source.id, { status: 'failed', error: result.error })
        }
      } catch (error) {
        apiStatus.set(source.id, { status: 'failed', error: error.message })
      }
    }
    if (needsSave) { fs.writeFileSync(metaPath, JSON.stringify(sources, null, 2)) }
  } catch (error) {
    console.error(`[UserApi] 读取 sources.json 失败:`, error.message)
  }

  console.log(`[UserApi] 本次加载: ${stats.loadedCount} 个脚本`)
  console.log(`[UserApi] 当前总计: ${loadedApis.size} 个脚本`)
  console.log(`[UserApi] ========================================`)
}

let fsWatcher = null
let reloadTimer = null
const RELOAD_DEBOUNCE = 5000

function startWatcher() {
  const scriptRoot = getScriptRoot()
  if (fsWatcher) return
  console.log(`[UserApi] 启动脚本文件监控: ${scriptRoot}`)
  try {
    fsWatcher = fs.watch(scriptRoot, (eventType, filename) => {
      if (!filename) return
      if (!filename.endsWith('.js') && filename !== 'sources.json') return
      if (reloadTimer) clearTimeout(reloadTimer)
      reloadTimer = setTimeout(() => {
        console.log(`[UserApi] [Watcher] 检测到文件变动: ${filename} -> 重新加载`)
        initCache.clear()
        loadAllScripts().catch(err => console.error(`[UserApi] [Watcher] 重新加载失败:`, err))
      }, RELOAD_DEBOUNCE)
    })
    process.on('exit', () => { if (fsWatcher) fsWatcher.close() })
  } catch (e) { console.error('[UserApi] 启动文件监控失败:', e) }
}

async function initUserApis() {
  await loadAllScripts()
  startWatcher()
}

function getLoadedApis() {
  return Array.from(loadedApis.values()).map(api => api.info)
}

module.exports = { loadUserApi, callUserApiGetMusicUrl, getCandidatesForSource, disablePlatformForApi, initUserApis, getLoadedApis, getApiStatus, extractMetadata, normalizeSongInfo, getScriptRoot, isMusicFreePlugin }
