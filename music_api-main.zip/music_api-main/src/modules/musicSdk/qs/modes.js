import { httpFetch } from '../../../request.js'
import { formatPlayTime } from '../../../utils.js'

const API = 'https://api.qishui.com'

const defaultHeaders = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
  Referer: 'https://music.douyin.com/',
  Accept: 'application/json, text/plain, */*',
}

const HOT_CHART_ID = '7036274230471712007'
const NEW_CHART_ID = '7060812597884869927'
const NOSTALGIA_RADIO_ID = '7408841207276748809'

const HOME_ORDER = [
  '默认模式', '熟悉模式', '新鲜模式', '图书馆', '专注模式', '摸鱼', '深夜EMO', 'DJ模式', '助眠模式',
  '动感健身', '抖音漫游', '洗澡', 'Chill放松', '快乐时光', '电音', '好运', '粤语', '通勤必听',
  '失恋必听', '躺平', '欧美', '打扫', '国风', '打游戏', '驾车', '说唱', '沉浸0.8x', '夜晚',
  '治愈', '轻音乐', '小酒馆', 'KTV必点', '起床', '浪漫情歌', '摇滚', 'R&B', '佛系时间',
  '怀旧老歌', '民谣', '甜美女声', 'K-pop', '日语', '旅行', '儿歌', '雨天', '海边', '乡村', '古典',
]

const ICON = 'https://is1-ssl.mzstatic.com/image/thumb/Purple211/v4/23/19/5a/23195ac8-3fbf-d33b-16ed-20854f9afd35/AppIcon-0-0-1x_U007epad-0-1-0-85-220.png/512x512bb.jpg'

function safeGet(obj, path, defaultValue = null) {
  if (!obj || typeof obj !== 'object') return defaultValue
  let current = obj
  for (const key of path) {
    if (current == null || typeof current !== 'object') return defaultValue
    current = current[key]
  }
  return current != null ? current : defaultValue
}

function formatSingerName(artists) {
  if (!Array.isArray(artists)) return ''
  return artists
    .filter(a => a && typeof a === 'object')
    .map(a => a.name || a.simple_display_name || '')
    .filter(Boolean)
    .join(' / ')
}

function buildImageUrl(image, suffix = '~c5_375x375.jpg') {
  if (!image || typeof image !== 'object') return ''
  const urls = image.urls || []
  const uri = image.uri || ''
  if (urls.length === 0) return ''
  let cover = String(urls[0]).trim()
  if (uri && !cover.includes(uri)) cover += uri
  if (cover && suffix && !cover.includes('~')) cover += suffix
  return cover
}

function trackToCard(track, prefix = '') {
  if (!track || !track.id) return null
  const artists = formatSingerName(track.artists)
  const album = track.album || {}
  const remark = artists || album.name || '汽水音乐'
  const albumCover = album.url_cover || track.url_cover || {}
  return {
    songmid: String(track.id),
    name: track.name || '未知歌曲',
    singer: artists,
    albumName: album.name || '',
    albumId: album.id || '',
    img: buildImageUrl(albumCover),
    duration: track.duration || 0,
    interval: track.duration ? formatPlayTime(Math.floor(track.duration / 1000)) : null,
    remark: prefix ? `${prefix}${artists ? ' · ' + artists : ''}` : remark,
    source: 'qs',
  }
}

// 基础偏好模式（默认、熟悉、新鲜）
const PREFERENCE_MODES = [
  { id: 'default', name: '默认模式', kind: 'preference' },
  { id: 'familiar', name: '熟悉模式', kind: 'preference' },
  { id: 'fresh', name: '新鲜模式', kind: 'preference' },
]

// 获取推荐模式列表
export async function getModes() {
  try {
    const requestObj = httpFetch(`${API}/luna/feed/mode`, {
      method: 'POST',
      headers: {
        ...defaultHeaders,
        'Content-Type': 'application/json; charset=utf-8',
      },
      body: JSON.stringify({ ab_param: '', feed_extra: null }),
    })

    const { body: data } = await requestObj.promise

    const modes = [...PREFERENCE_MODES]

    // 解析场景模式
    const feedModeBlock = data?.feed_mode_block || []
    for (const group of feedModeBlock) {
      const feedModes = group?.feed_mode || []
      for (const mode of feedModes) {
        const entity = mode?.entity || {}
        const scene = entity.feed_scene_mode || {}
        const sceneId = scene.scene_mode_id
        const name = mode?.text || '听歌模式'
        if (sceneId) {
          modes.push({
            id: String(sceneId),
            name: String(name),
            kind: 'scene',
            sub: scene.sub_queue_type || '',
          })
        }
      }
    }

    // 去重并按固定顺序排序
    const seen = new Set()
    const cards = []
    for (const info of modes) {
      const normalized = info.name.toLowerCase().replace(/\s/g, '')
      if (seen.has(normalized)) continue
      seen.add(normalized)
      cards.push(info)
    }

    const order = new Map(
      HOME_ORDER.map((name, idx) => [name.toLowerCase().replace(/\s/g, ''), idx])
    )

    cards.sort((a, b) => {
      const orderA = order.get(a.name.toLowerCase().replace(/\s/g, '')) ?? HOME_ORDER.length
      const orderB = order.get(b.name.toLowerCase().replace(/\s/g, '')) ?? HOME_ORDER.length
      return orderA - orderB
    })

    return {
      list: cards.map(m => ({
        id: m.id,
        name: m.name,
        kind: m.kind,
        pic: ICON,
        source: 'qs',
      })),
      source: 'qs',
    }
  } catch (e) {
    // API失败时返回基础模式列表
    console.warn('[Modes] API请求失败，返回基础模式列表:', e.message)
    return {
      list: PREFERENCE_MODES.map(m => ({
        id: m.id,
        name: m.name,
        kind: m.kind,
        pic: ICON,
        source: 'qs',
      })),
      source: 'qs',
    }
  }
}

// 获取模式下的曲目列表
export async function getModeTracks(modeId, modeName) {
  // 基础偏好模式映射到榜单
  if (modeId === 'default') {
    return getChartTracks(HOT_CHART_ID, modeName)
  }
  if (modeId === 'familiar') {
    return getRadioTracks(NOSTALGIA_RADIO_ID, modeName)
  }
  if (modeId === 'fresh') {
    return getChartTracks(NEW_CHART_ID, modeName)
  }

  // 场景模式：使用搜索接口获取相关曲目
  return searchModeTracks(modeName)
}

// 获取电台曲目
export async function getRadioTracks(radioId, radioName = '电台') {
  const requestObj = httpFetch(`${API}/luna/feed/radio/tracks`, {
    method: 'POST',
    headers: {
      ...defaultHeaders,
      'Content-Type': 'application/json; charset=utf-8',
    },
    body: JSON.stringify({
      radio_id: String(radioId),
      played_media: [],
      feed_radio_media_extra: { real_groups: [] },
      flow_type: 2,
      full_media: true,
    }),
  })

  const { body: data } = await requestObj.promise
  const items = data?.items || []
  const tracks = items
    .map(item => extractTrack(item))
    .filter(Boolean)

  return {
    list: tracks.map(t => trackToCard(t)).filter(Boolean),
    total: tracks.length,
    name: radioName,
    source: 'qs',
  }
}

// 获取榜单曲目
export async function getChartTracks(chartId, chartName = '排行榜') {
  const requestObj = httpFetch(`${API}/luna/charts/${encodeURIComponent(String(chartId))}`, {
    method: 'GET',
    headers: defaultHeaders,
  })

  const { body: data } = await requestObj.promise
  const chart = data?.chart || {}
  const items = chart.track_ranks || chart.tracks ||
    data?.track_ranks || data?.tracks || data?.items || []

  const tracks = items
    .map(item => extractTrack(item))
    .filter(Boolean)

  return {
    list: tracks.map(t => trackToCard(t)).filter(Boolean),
    total: tracks.length,
    name: chartName || chart.name || '排行榜',
    pic: ICON,
    source: 'qs',
  }
}

// 搜索模式曲目
async function searchModeTracks(keyword) {
  const params = new URLSearchParams({
    q: keyword,
    cursor: '0',
    search_method: 'input',
    aid: '386088',
    device_platform: 'web',
    channel: 'pc_web',
  })

  const requestObj = httpFetch(`${API}/luna/pc/search/track?${params}`, {
    headers: defaultHeaders,
  })

  const { body: result } = await requestObj.promise
  const data = safeGet(result, ['result_groups', 0, 'data'], [])
  const tracks = data
    .map(item => {
      const track = safeGet(item, ['entity', 'track'])
      return track && track.id ? track : null
    })
    .filter(Boolean)

  return {
    list: tracks.map(t => trackToCard(t)).filter(Boolean),
    total: tracks.length,
    name: keyword,
    source: 'qs',
  }
}

// 从各种格式中提取track
function extractTrack(obj) {
  if (!obj || typeof obj !== 'object') return null

  if (obj.id && (obj.name || obj.title)) {
    return obj
  }

  const paths = [
    ['track'],
    ['entity', 'track_wrapper', 'track'],
    ['track_wrapper', 'track'],
    ['entity', 'track'],
  ]

  for (const path of paths) {
    let value = obj
    for (const key of path) {
      value = (value && typeof value === 'object') ? value[key] : null
    }
    if (value && typeof value === 'object' && value.id) {
      return value
    }
  }

  return null
}

export default {
  getModes,
  getModeTracks,
  getRadioTracks,
  getChartTracks,
}
