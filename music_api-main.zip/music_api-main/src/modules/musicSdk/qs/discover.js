import { httpFetch } from '../../../request.js'
import { formatPlayCount } from '../../../utils.js'

const API = 'https://api.qishui.com'

const defaultHeaders = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
  Referer: 'https://music.douyin.com/',
  Accept: 'application/json, text/plain, */*',
}

function safeGet(obj, path, defaultValue = null) {
  if (!obj || typeof obj !== 'object') return defaultValue
  let current = obj
  for (const key of path) {
    if (current == null || typeof current !== 'object') return defaultValue
    current = current[key]
  }
  return current != null ? current : defaultValue
}

function buildImageUrl(image, suffix = '~c5_300x300.jpg') {
  if (!image || typeof image !== 'object') return ''
  const urls = image.urls || []
  const uri = image.uri || ''
  if (urls.length === 0) return ''
  let cover = String(urls[0]).trim()
  if (uri && !cover.includes(uri)) cover += uri
  if (cover && suffix && !cover.includes('~')) cover += suffix
  return cover
}

// 获取发现页面内容
export async function getDiscover() {
  const requestObj = httpFetch(`${API}/luna/discover`, {
    method: 'POST',
    headers: {
      ...defaultHeaders,
      'Content-Type': 'application/json; charset=utf-8',
    },
    body: JSON.stringify({
      ab_param: '',
      selected_boost: null,
      playlist_mix_param: null,
      feed_discover_extra: null,
      first_request: true,
    }),
  })

  const { body: data } = await requestObj.promise
  const blocks = data?.blocks || []

  // 继续加载推荐混合流
  for (let i = 0; i < 2; i++) {
    try {
      const mixReq = httpFetch(`${API}/luna/discover/mix`, {
        method: 'POST',
        headers: {
          ...defaultHeaders,
          'Content-Type': 'application/json; charset=utf-8',
        },
        body: JSON.stringify({
          block_type: 'discover_playlist_mix',
          sub_channel_id: 0,
          latest_douyin_liked_playlist_show_ts: null,
          feed_discover_extra: {},
          cursor: null,
          count: 50,
          session_id: null,
          ab_param: '',
        }),
      })
      const { body: mixed } = await mixReq.promise
      blocks.push({
        inner_block: mixed?.inner_block || [],
        title: '发现',
      })
    } catch (e) {
      // 忽略混合流加载错误
    }
  }

  const cards = []
  const seen = new Set()

  for (const block of blocks) {
    const inners = block?.inner_block || (block?.resources ? [block] : [])
    for (const inner of inners) {
      const resources = inner?.resources || []
      for (const resource of resources) {
        const style = resource?.style || {}
        const kind = String(resource?.type || 'radio')
        const rid = String(resource?.resource_id || inner?.inner_block_id || '')
        const marker = `${kind}:${rid}`

        if (!rid || seen.has(marker)) continue
        seen.add(marker)

        const cover = style?.cover_url || (Array.isArray(style?.cover_url_list) && style.cover_url_list[0]) || {}
        const entity = resource?.entity || {}
        let finalCover = cover
        if (!finalCover && entity?.playlist) {
          finalCover = entity.playlist.url_cover || {}
        }

        cards.push({
          id: rid,
          kind,
          name: style?.title || inner?.title || '发现',
          desc: style?.desc || block?.title || '发现',
          img: buildImageUrl(finalCover),
          source: 'qs',
        })
      }
    }
  }

  return {
    list: cards,
    total: cards.length,
    source: 'qs',
  }
}

// 获取发现详情（歌单/电台/榜单）
export async function getDiscoverDetail(id, kind) {
  const qs = new URLSearchParams({
    device_platform: 'web',
  })

  if (kind === 'radio') {
    // 电台
    const radioReq = httpFetch(`${API}/luna/feed/radio/tracks`, {
      method: 'POST',
      headers: {
        ...defaultHeaders,
        'Content-Type': 'application/json; charset=utf-8',
      },
      body: JSON.stringify({
        radio_id: String(id),
        played_media: [],
        feed_radio_media_extra: { real_groups: [] },
        flow_type: 2,
        full_media: true,
      }),
    })
    const { body: data } = await radioReq.promise
    const items = data?.items || []
    const tracks = items
      .map(item => extractTrack(item))
      .filter(Boolean)

    return {
      list: tracks.map(t => trackToCard(t)).filter(Boolean),
      total: tracks.length,
      source: 'qs',
    }
  }

  if (kind === 'brief_chart' || kind === 'chart') {
    // 榜单
    const chartReq = httpFetch(`${API}/luna/charts/${encodeURIComponent(String(id))}`, {
      headers: defaultHeaders,
    })
    const { body: data } = await chartReq.promise
    const chart = data?.chart || {}
    const items = chart.track_ranks || chart.tracks ||
      data?.track_ranks || data?.tracks || data?.items || []

    const tracks = items
      .map(item => extractTrack(item))
      .filter(Boolean)

    return {
      list: tracks.map(t => trackToCard(t)).filter(Boolean),
      total: tracks.length,
      name: chart.name || '排行榜',
      source: 'qs',
    }
  }

  // 歌单
  const playlistReq = httpFetch(`${API}/luna/playlist/detail`, {
    method: 'POST',
    headers: {
      ...defaultHeaders,
      'Content-Type': 'application/json; charset=utf-8',
    },
    body: JSON.stringify({
      playlist_id: String(id),
      cursor: null,
      count: 100,
      type: null,
      feed_playlist_extra: { har: null, commerce_block_pattern: null },
      sort_type: null,
      session_id: null,
      reverse: false,
      ab_param: '',
      limited_free_scene: 0,
    }),
  })

  const { body: data } = await playlistReq.promise
  const mediaResources = data?.media_resources || []
  const tracks = mediaResources
    .map(item => {
      const track = safeGet(item, ['entity', 'track_wrapper', 'track']) ||
                    safeGet(item, ['entity', 'track'])
      return track && track.id ? track : null
    })
    .filter(Boolean)

  return {
    list: tracks.map(t => trackToCard(t)).filter(Boolean),
    total: tracks.length,
    source: 'qs',
  }
}

function extractTrack(obj) {
  if (!obj || typeof obj !== 'object') return null
  if (obj.id && (obj.name || obj.title)) return obj

  const paths = [
    ['track'],
    ['entity', 'track_wrapper', 'track'],
    ['track_wrapper', 'track'],
    ['entity', 'track'],
  ]

  for (const path of paths) {
    let value = obj
    for (const key of path) {
      value = (value && typeof value === 'object') ? value[key] : null
    }
    if (value && typeof value === 'object' && value.id) {
      return value
    }
  }
  return null
}

function formatSingerName(artists) {
  if (!Array.isArray(artists)) return ''
  return artists
    .filter(a => a && typeof a === 'object')
    .map(a => a.name || a.simple_display_name || '')
    .filter(Boolean)
    .join(' / ')
}

function trackToCard(track) {
  if (!track || !track.id) return null
  const artists = formatSingerName(track.artists)
  const album = track.album || {}
  const albumCover = album.url_cover || track.url_cover || {}
  return {
    songmid: String(track.id),
    name: track.name || '未知歌曲',
    singer: artists,
    albumName: album.name || '',
    albumId: album.id || '',
    img: buildImageUrl(albumCover, '~c5_375x375.jpg'),
    duration: track.duration || 0,
    source: 'qs',
  }
}

export default {
  getDiscover,
  getDiscoverDetail,
}
