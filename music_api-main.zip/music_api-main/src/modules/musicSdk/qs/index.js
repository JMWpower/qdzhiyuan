import musicSearch from './musicSearch.js'
import leaderboard from './leaderboard.js'
import songList from './songList.js'
import lyric from './lyric.js'
import hotSearch from './hotSearch.js'
import tipSearch from './tipSearch.js'
import musicInfo from './musicInfo.js'
import { apis, supportQuality } from '../api-source.js'
import { getModes, getModeTracks, getRadioTracks, getChartTracks } from './modes.js'
import { getDiscover, getDiscoverDetail } from './discover.js'

export default {
  musicSearch,
  leaderboard,
  songList,
  lyric,
  getLyric(songInfo) {
    const songmid = typeof songInfo === 'string' ? songInfo : (songInfo.songmid || songInfo.music_id)
    return lyric(songmid)
  },
  hotSearch,
  comment: null,
  tipSearch,
  singer: null,
  musicInfo,

  // 汽水分页专属方法
  getModes,
  getModeTracks,
  getRadioTracks,
  getChartTracks,
  getDiscover,
  getDiscoverDetail,

  async getMusicUrl(songInfo, type) {
    const sources = supportQuality['qsvip'] ? ['qsvip'] : []
    const qsSources = supportQuality['qs'] ? ['qs'] : []
    const ruleSources = [...sources, ...qsSources]

    for (const source of ruleSources) {
      try {
        return await apis(source).getMusicUrl(songInfo, type)
      } catch (e) {
        continue
      }
    }

    return musicInfo.getMusicUrl(songInfo.songmid || songInfo.music_id, type)
  },
}
