import https from 'https'
import zlib from 'zlib'

const defaultHeaders = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
  Referer: 'https://music.douyin.com/',
  Cookie: 'odin_tt=1; ttwid=1',
  Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
}

// 原生HTTPS请求
function httpsGet(url) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url)
    const options = {
      hostname: urlObj.hostname,
      port: 443,
      path: urlObj.pathname + urlObj.search,
      method: 'GET',
      headers: defaultHeaders,
      rejectUnauthorized: false,
    }

    const req = https.request(options, (res) => {
      // 处理重定向
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return httpsGet(res.headers.location).then(resolve).catch(reject)
      }

      const chunks = []
      res.on('data', chunk => chunks.push(chunk))
      res.on('end', () => {
        const buffer = Buffer.concat(chunks)
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          body: buffer,
        })
      })
    })

    req.on('error', (err) => {
      reject(new Error('HTTP error: ' + err.message))
    })
    
    req.setTimeout(30000, () => {
      req.destroy()
      reject(new Error('Request timeout after 30s'))
    })
    
    req.end()
  })
}

// 从HTML中提取JSON对象
function extractJsonObject(html, startMarker) {
  const startIndex = html.indexOf(startMarker)
  if (startIndex === -1) return null

  const braceStart = html.indexOf('{', startIndex)
  if (braceStart === -1) return null

  let depth = 0
  let inString = false
  let escapeNext = false

  for (let i = braceStart; i < html.length; i++) {
    const char = html[i]

    if (escapeNext) {
      escapeNext = false
      continue
    }

    if (char === '\\' && inString) {
      escapeNext = true
      continue
    }

    if (char === '"') {
      if (i > 0 && html[i - 1] === '\\') {
        continue
      }
      inString = !inString
      continue
    }

    if (!inString) {
      if (char === '{') depth++
      if (char === '}') {
        depth--
        if (depth === 0) {
          return html.substring(braceStart, i + 1)
        }
      }
    }
  }

  return null
}

export default async (songmid) => {
  const url = `https://music.douyin.com/qishui/share/track?track_id=${songmid}`

  const response = await httpsGet(url)

  if (response.statusCode !== 200) {
    throw new Error(`HTTP ${response.statusCode}`)
  }

  // 解码响应体
  let html
  const encoding = response.headers['content-encoding']
  
  try {
    if (encoding === 'br') {
      html = zlib.brotliDecompressSync(response.body).toString('utf-8')
    } else if (encoding === 'gzip') {
      html = zlib.gunzipSync(response.body).toString('utf-8')
    } else if (encoding === 'deflate') {
      html = zlib.inflateSync(response.body).toString('utf-8')
    } else {
      html = response.body.toString('utf-8')
    }
  } catch (e) {
    // 解压失败时尝试直接转字符串
    html = response.body.toString('utf-8')
  }

  if (!html || html.length < 100) {
    throw new Error('获取歌词页面失败：内容为空')
  }

  // 提取 _ROUTER_DATA JSON
  const jsonStr = extractJsonObject(html, '_ROUTER_DATA')
  if (!jsonStr) {
    throw new Error('未找到歌词数据')
  }

  let routerData
  try {
    routerData = JSON.parse(jsonStr)
  } catch (e) {
    throw new Error('歌词数据解析失败: ' + e.message)
  }

  if (!routerData || typeof routerData !== 'object') {
    throw new Error('歌词数据解析为空')
  }

  // 尝试多种路径获取歌词
  const lyricsPaths = [
    ['loaderData', 'track_page', 'audioWithLyricsOption', 'lyrics', 'sentences'],
    ['loaderData', 'track_page', 'lyrics', 'sentences'],
    ['page_data', 'lyrics', 'sentences'],
    ['track_page', 'lyrics', 'sentences'],
  ]

  let sentences = null
  for (const path of lyricsPaths) {
    let value = routerData
    for (const key of path) {
      value = (value && typeof value === 'object') ? value[key] : null
    }
    if (value && Array.isArray(value) && value.length > 0) {
      sentences = value
      break
    }
  }

  if (!sentences) {
    throw new Error('未找到歌词内容')
  }

  const lrcLines = []
  const lxlrcLines = []

  for (const sentence of sentences) {
    if (!sentence || typeof sentence !== 'object') continue
    const startMs = sentence.startMs || 0
    const words = sentence.words || []
    const text = sentence.text || words.filter(w => w && typeof w === 'object').map(w => w.text || '').join('')

    const minutes = Math.floor(startMs / 60000)
    const seconds = Math.floor((startMs % 60000) / 1000)
    const mSeconds = startMs % 1000
    const timeTag = `[${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${String(mSeconds).padStart(3, '0')}]`

    lrcLines.push(`${timeTag}${text}`)

    if (words.length > 0 && words.every(w => w && typeof w === 'object' && w.startMs != null)) {
      const wordTags = []
      for (const word of words) {
        const wordStart = Math.max((word.startMs || 0) - startMs, 0)
        const wordDur = word.durationMs || (word.endMs ? word.endMs - word.startMs : 0)
        wordTags.push(`<${wordStart},${wordDur}>${word.text || ''}`)
      }
      lxlrcLines.push(`${timeTag}${wordTags.join('')}`)
    }
  }

  if (lrcLines.length === 0) {
    throw new Error('歌词解析为空')
  }

  return {
    lyric: lrcLines.join('\n'),
    lxlyric: lxlrcLines.join('\n'),
    tlyric: '',
    rlyric: '',
  }
}
