import { httpFetch } from '../../../request.js'
import { sizeFormate, formatPlayTime } from '../../../utils.js'
import { formatSingerName } from '../utils.js'

const API = 'https://api.qishui.com'

const defaultHeaders = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
  Referer: 'https://music.douyin.com/',
  Cookie: 'odin_tt=1; ttwid=1',
}

const mobileHeaders = {
  'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
  Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
}

function safeGet(obj, path, defaultValue = null) {
  if (!obj || typeof obj !== 'object') return defaultValue
  let current = obj
  for (const key of path) {
    if (current == null || typeof current !== 'object') return defaultValue
    current = current[key]
  }
  return current != null ? current : defaultValue
}

const qualityMap = {
  '128k': { bitrate: 128000, label: '标准音质(128K)' },
  '320k': { bitrate: 320000, label: '极高音质(320K)' },
  'flac': { bitrate: 999000, label: '无损音质' },
  'flac24bit': { bitrate: 1999000, label: 'Hi-Res音质' },
}

// 音质排序：从高到低
const QUALITY_ORDER = ['flac24bit', 'flac', '320k', '128k']

function rankAudioList(playInfoList) {
  if (!Array.isArray(playInfoList)) return []
  return [...playInfoList].sort((a, b) => {
    const brA = a.Bitrate || 0
    const brB = b.Bitrate || 0
    if (brB !== brA) return brB - brA
    const sizeA = a.Size || 0
    const sizeB = b.Size || 0
    return sizeB - sizeA
  })
}

function getQualityType(audioInfo) {
  const bitrate = audioInfo.Bitrate || 0
  const format = (audioInfo.Format || '').toLowerCase()
  if (bitrate > 1000000 || (format === 'flac' && bitrate > 800000)) return 'flac24bit'
  if (bitrate > 800000 || format === 'flac') return 'flac'
  if (bitrate > 200000) return '320k'
  return '128k'
}

function getStreamLabel(bitrate, index) {
  const kbps = Math.max(0, Math.floor((bitrate || 0) / 1000))
  let name = '无损音质'
  if (kbps >= 900) name = '无损音质'
  else if (kbps >= 190) name = '极高音质'
  else if (kbps >= 96) name = '标准音质'
  else name = '省流音质'
  return kbps ? `${name}(${kbps}K)` : `${name}${index + 1}`
}

/**
 * 解析音频流列表（与Python的 _audio_streams 逻辑一致）
 */
function parseAudioStreams(data) {
  const player = data?.track_player || {}
  const result = []

  // 方法1: 从 video_model 解析
  let model = player.video_model
  if (typeof model === 'string' && model) {
    try {
      model = JSON.parse(model)
    } catch (e) {
      model = {}
    }
  }

  if (model && typeof model === 'object') {
    const videoList = model.video_list || []
    videoList.forEach((item, index) => {
      if (!item || typeof item !== 'object' || item.encrypt_info) return
      const meta = item.video_meta || {}
      const bitrate = meta.bitrate || meta.real_bitrate || 0
      const url = item.main_url || item.backup_url
      if (url) {
        result.push({
          key: String(meta.quality || index),
          label: getStreamLabel(bitrate, index),
          bitrate: Number(bitrate) || 0,
          url: String(url),
        })
      }
    })
  }

  // 方法2: 从 url_player_info 获取（备用）
  if (result.length === 0 && player.url_player_info) {
    // url_player_info 需要在外部请求，这里只返回标记
    result.push({ needFetchUrl: player.url_player_info })
  }

  // 去重并按码率排序
  const unique = new Map()
  for (const item of result) {
    if (item.needFetchUrl) continue
    const key = `${item.key}_${item.bitrate}`
    if (!unique.has(key)) unique.set(key, item)
  }

  return Array.from(unique.values()).sort((a, b) => b.bitrate - a.bitrate)
}

/**
 * 获取曲目的SEO信息（与Python的 _seo 逻辑一致）
 */
async function getSeoTrack(trackId) {
  const params = new URLSearchParams({
    track_id: String(trackId),
    device_platform: 'web',
  })
  const requestObj = httpFetch(`${API}/luna/h5/seo_track?${params}`, {
    headers: defaultHeaders,
  })
  const { body } = await requestObj.promise
  return body
}

export default {
  /**
   * 获取音乐播放链接（多音质）
   * 与Python文件的 playerContent 和 _audio_streams 逻辑一致
   */
  async getMusicUrl(songmid, quality = '128k') {
    const seoData = await getSeoTrack(songmid)
    const streams = parseAudioStreams(seoData)

    // 如果需要通过 url_player_info 获取
    const needFetchStream = streams.find(s => s.needFetchUrl)
    if (needFetchStream) {
      const playerResp = await httpFetch(needFetchStream.needFetchUrl, {
        headers: defaultHeaders,
      }).promise
      const playerData = playerResp.body
      const playInfoList = safeGet(playerData, ['Result', 'Data', 'PlayInfoList'], [])
      const rankedList = rankAudioList(playInfoList).filter(a => a.MainPlayUrl || a.BackupPlayUrl)

      rankedList.forEach((item, index) => {
        const bitrate = item.Bitrate || 0
        const url = item.MainPlayUrl || item.BackupPlayUrl
        if (url) {
          streams.push({
            key: String(getQualityType(item)),
            label: getStreamLabel(bitrate, index),
            bitrate,
            url,
            playAuth: item.PlayAuth || '',
            format: (item.Format || 'm4a').toLowerCase(),
            size: item.Size || 0,
            duration: item.Duration || 0,
          })
        }
      })
    }

    // 去重
    const unique = new Map()
    for (const s of streams) {
      if (s.needFetchUrl) continue
      const key = `${s.key}_${s.bitrate}`
      if (!unique.has(key)) unique.set(key, s)
    }
    const sortedStreams = Array.from(unique.values()).sort((a, b) => b.bitrate - a.bitrate)

    if (sortedStreams.length === 0) {
      throw new Error('未找到可用的播放链接')
    }

    // 选择最匹配的音质
    const qualityOrder = QUALITY_ORDER.includes(quality) ? QUALITY_ORDER.slice(QUALITY_ORDER.indexOf(quality)) : QUALITY_ORDER
    let selectedStream = null

    for (const q of qualityOrder) {
      selectedStream = sortedStreams.find(s => getQualityType({ bitrate: s.bitrate, Format: s.format || 'm4a' }) === q)
      if (selectedStream) break
    }

    if (!selectedStream) {
      if (quality === '128k' || quality === '320k') {
        selectedStream = sortedStreams.find(s => getQualityType({ bitrate: s.bitrate }) === '128k') ||
                        sortedStreams[sortedStreams.length - 1]
      } else {
        selectedStream = sortedStreams[0]
      }
    }

    if (!selectedStream) {
      selectedStream = sortedStreams[0]
    }

    // 构建代理URL
    const originalUrl = selectedStream.url
    const format = (selectedStream.format || 'm4a').toLowerCase()
    const playAuth = selectedStream.playAuth || ''

    let proxyUrl
    if (playAuth) {
      proxyUrl = `/api/music/audio-proxy/${format}?url=${encodeURIComponent(originalUrl)}&playAuth=${encodeURIComponent(playAuth)}`
    } else {
      proxyUrl = `/api/music/audio-proxy/${format}?url=${encodeURIComponent(originalUrl)}`
    }

    const audioType = getQualityType({ bitrate: selectedStream.bitrate, Format: format })

    return {
      url: proxyUrl,
      originalUrl,
      type: audioType,
      quality: audioType,
      format,
      bitrate: selectedStream.bitrate || 0,
      size: selectedStream.size || 0,
      sizeStr: sizeFormate(selectedStream.size || 0),
      duration: selectedStream.duration || 0,
      playAuth,
    }
  },

  /**
   * 获取音乐详情（与Python的 _song_detail 逻辑一致）
   */
  async getMusicDetail(songmid) {
    const seoData = await getSeoTrack(songmid)
    const seoTrack = seoData?.seo_track || {}

    // 从SEO数据中提取track
    const track = seoTrack.track || seoTrack || {}
    const artists = track.artists || []
    const album = track.album || {}
    const coverUrls = safeGet(album, ['url_cover', 'urls'], [])
    const coverUri = safeGet(album, ['url_cover', 'uri'], '')

    let img = ''
    if (coverUrls && coverUrls.length > 0) {
      img = String(coverUrls[0]) + String(coverUri) + '~c5_375x375.jpg'
    }

    // 解析可用音质
    const streams = parseAudioStreams(seoData)
    const types = []
    const _types = {}

    // 如果需要通过url_player_info获取完整音质信息
    const needFetchStream = streams.find(s => s.needFetchUrl)
    if (needFetchStream) {
      try {
        const playerResp = await httpFetch(needFetchStream.needFetchUrl, {
          headers: defaultHeaders,
        }).promise
        const playerData = playerResp.body
        const playInfoList = safeGet(playerData, ['Result', 'Data', 'PlayInfoList'], [])
        const rankedList = rankAudioList(playInfoList)
        for (const audio of rankedList) {
          if (!audio.MainPlayUrl && !audio.BackupPlayUrl) continue
          const qType = getQualityType(audio)
          const size = sizeFormate(audio.Size || 0)
          if (!_types[qType]) {
            types.push({ type: qType, size })
            _types[qType] = { size }
          }
        }
      } catch (e) { }
    }

    // 如果没有从url_player_info获取到音质，从streams中获取
    if (types.length === 0) {
      for (const s of streams) {
        if (s.needFetchUrl) continue
        const qType = getQualityType({ bitrate: s.bitrate, Format: s.format || 'm4a' })
        const size = sizeFormate(s.size || 0)
        if (!_types[qType]) {
          types.push({ type: qType, size })
          _types[qType] = { size }
        }
      }
    }

    return {
      singer: formatSingerName(artists, 'name'),
      name: track.name || '',
      albumName: album.name || '',
      albumId: album.id || '',
      songmid: String(track.id || songmid),
      source: 'qs',
      interval: track.duration ? formatPlayTime(Math.floor(track.duration / 1000)) : null,
      img,
      lrc: null,
      types,
      _types,
      typeUrl: {},
      songId: String(track.id || songmid),
    }
  },
}
