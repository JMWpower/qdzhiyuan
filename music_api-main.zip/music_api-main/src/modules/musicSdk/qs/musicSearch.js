import crypto from 'crypto'
import { httpFetch } from '../../../request.js'
import { sizeFormate, formatPlayTime } from '../../../utils.js'
import { formatSingerName } from '../utils.js'

const API = 'https://api.qishui.com'

const defaultHeaders = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
  Referer: 'https://music.douyin.com/',
  Cookie: 'odin_tt=1; ttwid=1',
}

function safeGet(obj, path, defaultValue = null) {
  if (!obj || typeof obj !== 'object') return defaultValue
  let current = obj
  for (const key of path) {
    if (current == null || typeof current !== 'object') return defaultValue
    current = current[key]
  }
  return current != null ? current : defaultValue
}

/**
 * 从各种API返回格式中提取track对象（与Python的_track逻辑一致）
 */
function extractTrack(obj) {
  if (!obj || typeof obj !== 'object') return null
  if (obj.id && (obj.name || obj.title)) return obj

  const paths = [
    ['track'],
    ['entity', 'track_wrapper', 'track'],
    ['track_wrapper', 'track'],
    ['entity', 'track'],
  ]

  for (const path of paths) {
    let value = obj
    for (const key of path) {
      value = (value && typeof value === 'object') ? value[key] : null
    }
    if (value && typeof value === 'object' && value.id) {
      return value
    }
  }
  return null
}

export default {
  limit: 20,
  total: 0,
  page: 0,
  allPage: 1,

  /**
   * 搜索曲目（与Python的 _search_tracks 逻辑一致）
   * 使用 /luna/search/track 端点，POST JSON body
   */
  musicSearch(keyword, page, limit) {
    const cursor = page === 1 ? null : String((page - 1) * limit)
    const searchId = crypto.createHash('md5').update(keyword).digest('hex')

    const payload = {
      search_type: 'track',
      q: keyword,
      cursor,
      search_id: searchId,
      search_method: 'input',
      search_scene: 'search_result',
    }

    const requestObj = httpFetch(`${API}/luna/search/track?device_platform=web`, {
      method: 'POST',
      headers: {
        ...defaultHeaders,
        'Content-Type': 'application/json; charset=utf-8',
      },
      body: JSON.stringify(payload),
    })
    return requestObj.promise.then(({ body }) => body)
  },

  /**
   * 处理搜索结果（与Python的_track_card逻辑一致）
   */
  handleResult(rawList) {
    if (!rawList || !Array.isArray(rawList)) return []
    const list = []
    const ids = new Set()

    for (const item of rawList) {
      const track = extractTrack(item)
      if (!track || !track.id || ids.has(track.id)) continue
      ids.add(track.id)

      const artists = track.artists || []
      const album = track.album || {}
      const coverUrls = safeGet(album, ['url_cover', 'urls'], [])
      const coverUri = safeGet(album, ['url_cover', 'uri'], '')
      let img = ''
      if (coverUrls && coverUrls.length > 0) {
        img = String(coverUrls[0]) + String(coverUri) + '~c5_375x375.jpg'
      }

      list.push({
        singer: formatSingerName(artists, 'name'),
        name: track.name || '',
        albumName: album.name || '',
        albumId: album.id || '',
        songmid: String(track.id),
        songId: String(track.id),
        source: 'qs',
        interval: track.duration ? formatPlayTime(Math.floor(track.duration / 1000)) : null,
        img,
        lrc: null,
        types: [],
        _types: {},
        typeUrl: {},
        duration: track.duration || 0,
      })
    }
    return list
  },

  /**
   * 搜索入口（与Python的 searchContentPage 逻辑一致）
   */
  search(keyword, page = 1, limit, retryNum = 0) {
    if (++retryNum > 3) return Promise.reject(new Error('try max num'))
    if (limit == null) limit = this.limit
    limit = Math.min(limit, 20)

    return this.musicSearch(keyword, page, limit).then(result => {
      if (!result) return Promise.reject(new Error('搜索失败'))

      // 从 result_groups 中提取数据（与Python一致）
      const resultGroups = result.result_groups || []
      const tracksGroup = resultGroups.find(g => g.id === 'tracks') || resultGroups[0] || {}
      const data = tracksGroup.data || []
      let list = this.handleResult(data)

      if (list == null) return this.search(keyword, page, limit, retryNum)

      const total = tracksGroup.total || list.length
      this.total = total
      this.page = page
      this.allPage = Math.ceil(this.total / limit)

      return {
        list,
        allPage: this.allPage,
        limit,
        total: this.total,
        source: 'qs',
      }
    })
  },
}
