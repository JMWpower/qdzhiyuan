import { httpFetch } from '../../../request.js'

const API = 'https://api.qishui.com'

const defaultHeaders = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
  Referer: 'https://music.douyin.com/',
  Accept: 'application/json, text/plain, */*',
}

function safeGet(obj, path, defaultValue = null) {
  if (!obj || typeof obj !== 'object') return defaultValue
  let current = obj
  for (const key of path) {
    if (current == null || typeof current !== 'object') return defaultValue
    current = current[key]
  }
  return current != null ? current : defaultValue
}

// 获取热搜列表
async function getList() {
  try {
    const params = new URLSearchParams({
      aid: '386088',
      app_name: 'luna_pc',
      region: 'cn',
      device_platform: 'web',
    })

    const requestObj = httpFetch(`${API}/luna/pc/search/hot?${params}`, {
      method: 'GET',
      headers: defaultHeaders,
    })

    const { body: data } = await requestObj.promise
    const hotList = data?.hot_list || data?.list || data?.items || data?.words || []

    if (Array.isArray(hotList) && hotList.length > 0) {
      const list = hotList.map((item, idx) => {
        if (typeof item === 'string') {
          return { keyword: item, rank: idx + 1, source: 'qs' }
        }
        return {
          keyword: item.keyword || item.word || item.name || item.query || '',
          rank: item.rank || item.hot || idx + 1,
          icon: item.icon_url || item.icon || '',
          source: 'qs',
        }
      }).filter(item => item.keyword)

      return { list, source: 'qs' }
    }
  } catch (e) {
    // 失败时返回默认热搜
  }

  // 默认热搜词
  const defaultKeywords = [
    '晴天', '七里香', '稻香', '告白气球', '青花瓷',
    '演员', '平凡之路', '后来', '海阔天空', '红豆',
  ]

  return {
    list: defaultKeywords.map((k, i) => ({ keyword: k, rank: i + 1, source: 'qs' })),
    source: 'qs',
  }
}

export default {
  getList,
}
