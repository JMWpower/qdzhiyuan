import { httpFetch } from '../../../request.js'
import { formatPlayTime } from '../../../utils.js'

const API = 'https://api.qishui.com'

const defaultHeaders = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
  Referer: 'https://music.douyin.com/',
  Accept: 'application/json, text/plain, */*',
}

const ICON = 'https://is1-ssl.mzstatic.com/image/thumb/Purple211/v4/23/19/5a/23195ac8-3fbf-d33b-16ed-20854f9afd35/AppIcon-0-0-1x_U007epad-0-1-0-85-220.png/512x512bb.jpg'

// 内置榜单ID
const CHART_IDS = {
  hot: '7036274230471712007',     // 热歌榜
  new: '7060812597884869927',     // 新歌榜
  nostalgia: '7408841207276748809', // 怀旧电台
}

function safeGet(obj, path, defaultValue = null) {
  if (!obj || typeof obj !== 'object') return defaultValue
  let current = obj
  for (const key of path) {
    if (current == null || typeof current !== 'object') return defaultValue
    current = current[key]
  }
  return current != null ? current : defaultValue
}

function formatSingerName(artists) {
  if (!Array.isArray(artists)) return ''
  return artists
    .filter(a => a && typeof a === 'object')
    .map(a => a.name || a.simple_display_name || '')
    .filter(Boolean)
    .join(' / ')
}

function buildImageUrl(image, suffix = '~c5_375x375.jpg') {
  if (!image || typeof image !== 'object') return ''
  const urls = image.urls || []
  const uri = image.uri || ''
  if (urls.length === 0) return ''
  let cover = String(urls[0]).trim()
  if (uri && !cover.includes(uri)) cover += uri
  if (cover && suffix && !cover.includes('~')) cover += suffix
  return cover
}

function extractTrack(obj) {
  if (!obj || typeof obj !== 'object') return null
  if (obj.id && (obj.name || obj.title)) return obj

  const paths = [
    ['track'],
    ['entity', 'track_wrapper', 'track'],
    ['track_wrapper', 'track'],
    ['entity', 'track'],
  ]

  for (const path of paths) {
    let value = obj
    for (const key of path) {
      value = (value && typeof value === 'object') ? value[key] : null
    }
    if (value && typeof value === 'object' && value.id) {
      return value
    }
  }
  return null
}

function trackToCard(track) {
  if (!track || !track.id) return null
  const artists = formatSingerName(track.artists)
  const album = track.album || {}
  const albumCover = album.url_cover || track.url_cover || {}
  return {
    songmid: String(track.id),
    name: track.name || '未知歌曲',
    singer: artists,
    albumName: album.name || '',
    albumId: album.id || '',
    img: buildImageUrl(albumCover),
    duration: track.duration || 0,
    interval: track.duration ? formatPlayTime(Math.floor(track.duration / 1000)) : null,
    source: 'qs',
  }
}

// 获取榜单列表
async function getBoards() {
  const boards = [
    { id: CHART_IDS.hot, name: '热歌榜', pic: ICON, desc: '热门歌曲排行榜', source: 'qs' },
    { id: CHART_IDS.new, name: '新歌榜', pic: ICON, desc: '最新发布歌曲', source: 'qs' },
    { id: CHART_IDS.nostalgia, name: '怀旧电台', pic: ICON, desc: '经典怀旧歌曲', source: 'qs', kind: 'radio' },
  ]

  return {
    list: boards,
    source: 'qs',
  }
}

// 获取榜单详情
async function getList(chartId, page = 1) {
  const id = String(chartId)

  // 判断是否为电台
  if (id === CHART_IDS.nostalgia) {
    return getRadioTracks(id, '怀旧电台')
  }

  return getChartTracks(id)
}

// 获取榜单曲目
async function getChartTracks(chartId, chartName = '排行榜') {
  const requestObj = httpFetch(`${API}/luna/charts/${encodeURIComponent(String(chartId))}`, {
    method: 'GET',
    headers: defaultHeaders,
  })

  const { body: data } = await requestObj.promise
  const chart = data?.chart || {}
  const items = chart.track_ranks || chart.tracks ||
    data?.track_ranks || data?.tracks || data?.items || []

  const tracks = items
    .map(item => extractTrack(item))
    .filter(Boolean)

  return {
    list: tracks.map(t => trackToCard(t)).filter(Boolean),
    total: tracks.length,
    page: 1,
    limit: tracks.length,
    allPage: 1,
    name: chartName || chart.name || '排行榜',
    pic: ICON,
    source: 'qs',
  }
}

// 获取电台曲目
async function getRadioTracks(radioId, radioName = '电台') {
  const requestObj = httpFetch(`${API}/luna/feed/radio/tracks`, {
    method: 'POST',
    headers: {
      ...defaultHeaders,
      'Content-Type': 'application/json; charset=utf-8',
    },
    body: JSON.stringify({
      radio_id: String(radioId),
      played_media: [],
      feed_radio_media_extra: { real_groups: [] },
      flow_type: 2,
      full_media: true,
    }),
  })

  const { body: data } = await requestObj.promise
  const items = data?.items || []
  const tracks = items
    .map(item => extractTrack(item))
    .filter(Boolean)

  return {
    list: tracks.map(t => trackToCard(t)).filter(Boolean),
    total: tracks.length,
    page: 1,
    limit: tracks.length,
    allPage: 1,
    name: radioName,
    pic: ICON,
    source: 'qs',
  }
}

export default {
  list: [
    { id: CHART_IDS.hot, name: '热歌榜' },
    { id: CHART_IDS.new, name: '新歌榜' },
    { id: CHART_IDS.nostalgia, name: '怀旧电台' },
  ],
  getBoards,
  getList,
  getDetailPageUrl(id) {
    return `https://music.douyin.com/qishui/chart?chart_id=${id}`
  },
}
