import { httpFetch } from '../../../request.js'
import { formatPlayTime } from '../../../utils.js'

const API = 'https://api.qishui.com'

const defaultHeaders = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
  Referer: 'https://music.douyin.com/',
  Accept: 'application/json, text/plain, */*',
}

const ICON = 'https://is1-ssl.mzstatic.com/image/thumb/Purple211/v4/23/19/5a/23195ac8-3fbf-d33b-16ed-20854f9afd35/AppIcon-0-0-1x_U007epad-0-1-0-85-220.png/512x512bb.jpg'

// 内置榜单ID集合
const CHART_IDS = [
  { id: '7036274230471712007', name: '热歌榜', kind: 'chart', desc: '热门歌曲排行榜' },
  { id: '7060812597884869927', name: '新歌榜', kind: 'chart', desc: '最新发布歌曲' },
  { id: '7060812597884869928', name: '原创榜', kind: 'chart', desc: '原创音乐排行榜' },
  { id: '7221513167111747596', name: '流行音乐榜', kind: 'chart', desc: '流行音乐排行榜' },
  { id: '7263745369993918520', name: '音乐之声电台', kind: 'radio', desc: '好音乐看得见' },
  { id: '7408841207276748809', name: '怀旧电台', kind: 'radio', desc: '经典怀旧歌曲' },
  { id: '7434078587398227977', name: '古风电台', kind: 'radio', desc: '古风音乐推荐' },
  { id: '7444645932691716111', name: '电子电台', kind: 'radio', desc: '电子音乐推荐' },
  { id: '7445727762873632819', name: 'R&B电台', kind: 'radio', desc: 'R&B音乐推荐' },
]

// 榜单名称映射
const CHART_NAMES = CHART_IDS.reduce((acc, c) => {
  acc[c.id] = c.name
  return acc
}, {})

// 电台ID集合
const RADIO_IDS = CHART_IDS.filter(c => c.kind === 'radio')
// 榜单ID集合
const BOARD_IDS = CHART_IDS.filter(c => c.kind === 'chart')

function safeGet(obj, path, defaultValue = null) {
  if (!obj || typeof obj !== 'object') return defaultValue
  let current = obj
  for (const key of path) {
    if (current == null || typeof current !== 'object') return defaultValue
    current = current[key]
  }
  return current != null ? current : defaultValue
}

function formatSingerName(artists) {
  if (!Array.isArray(artists)) return ''
  return artists
    .filter(a => a && typeof a === 'object')
    .map(a => a.name || a.simple_display_name || '')
    .filter(Boolean)
    .join(' / ')
}

function buildImageUrl(image, suffix = '~c5_375x375.jpg') {
  if (!image || typeof image !== 'object') return ''
  const urls = image.urls || []
  const uri = image.uri || ''
  if (urls.length === 0) return ''
  let cover = String(urls[0]).trim()
  if (uri && !cover.includes(uri)) cover += uri
  if (cover && suffix && !cover.includes('~')) cover += suffix
  return cover
}

function extractTrack(obj) {
  if (!obj || typeof obj !== 'object') return null
  if (obj.id && (obj.name || obj.title)) return obj

  const paths = [
    ['track'],
    ['entity', 'track_wrapper', 'track'],
    ['track_wrapper', 'track'],
    ['entity', 'track'],
  ]

  for (const path of paths) {
    let value = obj
    for (const key of path) {
      value = (value && typeof value === 'object') ? value[key] : null
    }
    if (value && typeof value === 'object' && value.id) {
      return value
    }
  }
  return null
}

function trackToCard(track) {
  if (!track || !track.id) return null
  const artists = formatSingerName(track.artists)
  const album = track.album || {}
  const albumCover = album.url_cover || track.url_cover || {}
  return {
    songmid: String(track.id),
    name: track.name || '未知歌曲',
    singer: artists,
    albumName: album.name || '',
    albumId: album.id || '',
    img: buildImageUrl(albumCover),
    duration: track.duration || 0,
    interval: track.duration ? formatPlayTime(Math.floor(track.duration / 1000)) : null,
    source: 'qs',
  }
}

// 获取榜单列表
async function getBoards() {
  return {
    list: CHART_IDS.map(c => ({
      id: c.id,
      name: c.name,
      pic: ICON,
      desc: c.desc || (c.kind === 'radio' ? '电台推荐' : '热门排行榜'),
      kind: c.kind,
      source: 'qs',
    })),
    source: 'qs',
  }
}

// 获取榜单详情（根据ID自动判断是榜单还是电台）
async function getList(chartId, page = 1) {
  const id = String(chartId)
  const chartInfo = CHART_IDS.find(c => c.id === id)

  if (chartInfo?.kind === 'radio') {
    return getRadioTracks(id, chartInfo.name)
  }

  return getChartTracks(id, chartInfo?.name || '排行榜')
}

// 获取多个榜单的曲目（合并集合模式）
async function getMergedCharts(chartIds, limit = 50) {
  const results = await Promise.allSettled(
    chartIds.map(id => getList(id, 1))
  )

  const tracks = []
  for (const result of results) {
    if (result.status === 'fulfilled' && result.value?.list) {
      tracks.push(...result.value.list.slice(0, limit))
    }
  }

  // 去重
  const seen = new Set()
  const uniqueTracks = []
  for (const track of tracks) {
    if (track.songmid && !seen.has(track.songmid)) {
      seen.add(track.songmid)
      uniqueTracks.push(track)
    }
  }

  return {
    list: uniqueTracks,
    total: uniqueTracks.length,
    page: 1,
    limit: uniqueTracks.length,
    allPage: 1,
    source: 'qs',
  }
}

// 获取所有榜单的曲目（合并集合）
async function getAllMerged(limit = 30) {
  return getMergedCharts(BOARD_IDS.map(c => c.id), limit)
}

// 获取所有电台的曲目（合并集合）
async function getAllRadioMerged(limit = 30) {
  return getMergedCharts(RADIO_IDS.map(c => c.id), limit)
}

// 获取榜单曲目
async function getChartTracks(chartId, chartName = '排行榜') {
  const requestObj = httpFetch(`${API}/luna/charts/${encodeURIComponent(String(chartId))}`, {
    method: 'GET',
    headers: defaultHeaders,
  })

  const { body: data } = await requestObj.promise
  const chart = data?.chart || {}
  const items = chart.track_ranks || chart.tracks ||
    data?.track_ranks || data?.tracks || data?.items || []

  const tracks = items
    .map(item => extractTrack(item))
    .filter(Boolean)

  return {
    list: tracks.map(t => trackToCard(t)).filter(Boolean),
    total: tracks.length,
    page: 1,
    limit: tracks.length,
    allPage: 1,
    name: chartName || chart.name || '排行榜',
    pic: ICON,
    source: 'qs',
  }
}

// 获取电台曲目
async function getRadioTracks(radioId, radioName = '电台') {
  const requestObj = httpFetch(`${API}/luna/feed/radio/tracks`, {
    method: 'POST',
    headers: {
      ...defaultHeaders,
      'Content-Type': 'application/json; charset=utf-8',
    },
    body: JSON.stringify({
      radio_id: String(radioId),
      played_media: [],
      feed_radio_media_extra: { real_groups: [] },
      flow_type: 2,
      full_media: true,
    }),
  })

  const { body: data } = await requestObj.promise
  const items = data?.items || []
  const tracks = items
    .map(item => extractTrack(item))
    .filter(Boolean)

  return {
    list: tracks.map(t => trackToCard(t)).filter(Boolean),
    total: tracks.length,
    page: 1,
    limit: tracks.length,
    allPage: 1,
    name: radioName,
    pic: ICON,
    source: 'qs',
  }
}

export default {
  list: CHART_IDS.map(c => ({ id: c.id, name: c.name, kind: c.kind })),
  getBoards,
  getList,
  getMergedCharts,
  getAllMerged,
  getAllRadioMerged,
  getDetailPageUrl(id) {
    return `https://music.douyin.com/qishui/chart?chart_id=${id}`
  },
}
