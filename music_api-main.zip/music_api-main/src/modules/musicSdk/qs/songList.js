import { httpFetch } from '../../../request.js'
import { formatPlayCount, formatPlayTime, sizeFormate } from '../../../utils.js'
import { formatSingerName } from '../utils.js'
import { getDiscover } from './discover.js'
import { getModes } from './modes.js'

const defaultHeaders = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
  Referer: 'https://music.douyin.com/',
  Cookie: 'odin_tt=1; ttwid=1',
}

function safeGet(obj, path, defaultValue = null) {
  if (!obj || typeof obj !== 'object') return defaultValue
  let current = obj
  for (const key of path) {
    if (current == null || typeof current !== 'object') return defaultValue
    current = current[key]
  }
  return current != null ? current : defaultValue
}

function buildImageUrl(urlCover, suffix = '~c5_300x300.jpg') {
  if (!urlCover) return ''
  const urls = urlCover.urls || []
  const uri = urlCover.uri || ''
  if (urls.length === 0) return ''
  let cover = String(urls[0]).trim()
  if (uri && !cover.includes(uri)) cover += uri
  if (cover && suffix && !cover.includes('~')) cover += suffix
  return cover
}

function buildSearchUrl(type, keyword, cursor = 0) {
  const params = new URLSearchParams({
    q: keyword,
    cursor: String(cursor),
    search_method: 'input',
    aid: '386088',
    device_platform: 'web',
    channel: 'pc_web',
  })
  return `https://api.qishui.com/luna/pc/search/${type}?${params.toString()}`
}

export default {
  _requestObj_list: null,
  limit_list: 20,
  limit_song: 50,

  sortList: [
    { name: '推荐', id: 'recommend' },
    { name: '模式', id: 'mode' },
  ],

  async getList(sortId, tagId, page = 1) {
    // sortId为mode时返回模式列表，否则返回发现歌单
    if (sortId === 'mode') {
      return this.getModeList()
    }
    return this.getDiscoverList(page)
  },

  // 获取发现页歌单列表
  async getDiscoverList(page = 1) {
    try {
      const data = await getDiscover()
      return {
        list: data.list || [],
        total: data.total || data.list?.length || 0,
        page,
        limit: this.limit_list,
        source: 'qs',
      }
    } catch (e) {
      return { list: [], total: 0, page, limit: this.limit_list, source: 'qs' }
    }
  },

  // 获取模式列表
  async getModeList() {
    try {
      const data = await getModes()
      return {
        list: data.list || [],
        total: data.list?.length || 0,
        page: 1,
        limit: this.limit_list,
        source: 'qs',
      }
    } catch (e) {
      return { list: [], total: 0, page: 1, limit: this.limit_list, source: 'qs' }
    }
  },

  async search(keyword, page = 1, limit = 20) {
    if (!keyword) return { list: [], total: 0, page: 1, limit, source: 'qs' }

    const cursor = (page - 1) * limit
    const requestObj = httpFetch(buildSearchUrl('playlist', keyword, cursor), {
      headers: defaultHeaders,
    })

    const { body } = await requestObj.promise
    if (!body) return { list: [], total: 0, page, limit, source: 'qs' }

    const resultGroups = body.result_groups || []
    if (resultGroups.length === 0) return { list: [], total: 0, page, limit, source: 'qs' }

    const list = []
    for (const item of resultGroups[0].data || []) {
      const pl = safeGet(item, ['entity', 'playlist'])
      if (!pl || !pl.id) continue

      const creator = (pl.owner && (pl.owner.public_name || pl.owner.nickname)) || ''
      const cover = buildImageUrl(pl.url_cover)

      list.push({
        id: String(pl.id),
        name: pl.title || '',
        img: cover,
        play_count: formatPlayCount(pl.count_tracks || 0),
        creator,
        desc: pl.desc || '',
        source: 'qs',
      })
    }

    const hasMore = resultGroups[0]?.has_more || false
    return {
      list,
      total: hasMore ? page * limit + 1 : (page - 1) * limit + list.length,
      page,
      limit,
      source: 'qs',
    }
  },

  async searchAlbum(keyword, page = 1, limit = 20) {
    if (!keyword) return { list: [], total: 0, page: 1, limit, source: 'qs' }

    const cursor = (page - 1) * limit
    const requestObj = httpFetch(buildSearchUrl('album', keyword, cursor), {
      headers: defaultHeaders,
    })

    const { body } = await requestObj.promise
    if (!body) return { list: [], total: 0, page, limit, source: 'qs' }

    const resultGroups = body.result_groups || []
    if (resultGroups.length === 0) return { list: [], total: 0, page, limit, source: 'qs' }

    const list = []
    for (const item of resultGroups[0].data || []) {
      const album = safeGet(item, ['entity', 'album'])
      if (!album || !album.id) continue

      const artists = album.artists || []
      const artistName = formatSingerName(artists, 'name')
      const cover = buildImageUrl(album.url_cover)

      list.push({
        id: String(album.id),
        name: album.name || '',
        img: cover,
        play_count: formatPlayCount(album.count_tracks || 0),
        creator: artistName,
        desc: album.company || '',
        source: 'qs',
      })
    }

    const hasMore = resultGroups[0]?.has_more || false
    return {
      list,
      total: hasMore ? page * limit + 1 : (page - 1) * limit + list.length,
      page,
      limit,
      source: 'qs',
    }
  },

  async getListDetail(id, page = 1, kind = null, tryNum = 0) {
    // 根据kind类型分发到不同的处理方法
    if (kind === 'scene' || kind === 'preference') {
      return this.getModeDetail(id)
    }
    if (kind === 'radio') {
      return this.getRadioDetail(id)
    }
    if (kind === 'playlist') {
      return this.getPlaylistDetail(id, page, tryNum)
    }

    // 没有kind参数时，先根据ID特征判断类型
    // 模式ID特征：default/familiar/fresh 或短数字(1-2位)
    const isLikelyMode = id === 'default' || id === 'familiar' || id === 'fresh' ||
                          (String(id).length <= 2 && /^\d+$/.test(String(id)))
    if (isLikelyMode) {
      return this.getModeDetail(id)
    }

    // 尝试歌单详情，返回空则尝试电台
    const playlistResult = await this.getPlaylistDetail(id, page, 0)
    if (playlistResult && playlistResult.list && playlistResult.list.length > 0) {
      return playlistResult
    }

    // 歌单为空，尝试电台
    try {
      const radioResult = await this.getRadioDetail(id)
      if (radioResult && radioResult.list && radioResult.list.length > 0) {
        return radioResult
      }
    } catch (e) {
      // 忽略电台错误
    }

    // 都失败则返回歌单结果（可能为空）
    return playlistResult
  },

  // 获取模式曲目详情
  async getModeDetail(modeId) {
    const { getModeTracks, getModes } = await import('./modes.js')
    // 获取模式列表以找到对应名称
    let modeName = modeId
    try {
      const modesData = await getModes()
      const mode = modesData.list?.find(m => String(m.id) === String(modeId))
      if (mode && mode.name) {
        modeName = mode.name
      }
    } catch (e) {
      // 忽略错误
    }
    return getModeTracks(modeId, modeName)
  },

  // 获取电台曲目详情
  async getRadioDetail(radioId) {
    const { getRadioTracks } = await import('./modes.js')
    return getRadioTracks(radioId, '电台')
  },

  // 获取歌单曲目详情（POST API支持分页）
  async getPlaylistDetail(playlistId, page) {
    const pageSize = 100
    const cursor = page === 1 ? null : String((page - 1) * pageSize)

    const requestObj = httpFetch('https://api.qishui.com/luna/playlist/detail', {
      method: 'POST',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': 'https://music.douyin.com/',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        playlist_id: playlistId,
        cursor,
        count: pageSize,
        type: null,
        feed_playlist_extra: { har: null, commerce_block_pattern: null },
        sort_type: null,
        session_id: null,
        reverse: false,
        ab_param: "",
        limited_free_scene: 0,
      }),
      timeout: 8000,
    })

    const { body } = await requestObj.promise
    if (!body || !body.playlist) {
      return { list: [], total: 0, page, limit: pageSize, allPage: 1, source: 'qs' }
    }

    const mediaResources = safeGet(body, ['media_resources'], [])
    const playlistInfo = safeGet(body, ['playlist'], {})
    const nextCursor = body.next_cursor
    const totalCount = playlistInfo.count_tracks || mediaResources.length

    const list = []
    const ids = new Set()

    for (const item of mediaResources) {
      const track = safeGet(item, ['entity', 'track_wrapper', 'track']) || safeGet(item, ['entity', 'track'])
      if (!track || !track.id || ids.has(track.id)) continue
      ids.add(track.id)

      const artists = track.artists || []
      const album = track.album || {}
      const coverUrls = safeGet(album, ['url_cover', 'urls'], [])
      const coverUri = safeGet(album, ['url_cover', 'uri'], '')
      let img = ''
      if (coverUrls && coverUrls.length > 0) {
        img = String(coverUrls[0]) + String(coverUri) + '~c5_375x375.jpg'
      }

      list.push({
        singer: formatSingerName(artists, 'name'),
        name: track.name || '',
        albumName: album.name || '',
        albumId: album.id || '',
        songmid: String(track.id),
        source: 'qs',
        interval: track.duration ? formatPlayTime(track.duration / 1000) : null,
        img,
        lrc: null,
        types: [],
        _types: {},
        typeUrl: {},
      })
    }

    const hasMore = nextCursor !== null && nextCursor !== undefined && nextCursor > 0 && list.length >= pageSize

    const coverUrls = safeGet(playlistInfo, ['url_cover', 'urls'], [])
    const coverUri = safeGet(playlistInfo, ['url_cover', 'uri'], '')
    let infoImg = ''
    if (coverUrls && coverUrls.length > 0) {
      infoImg = String(coverUrls[0]) + String(coverUri) + '~c5_300x300.jpg'
    }

    return {
      list,
      page,
      limit: pageSize,
      total: hasMore ? page * pageSize + 1 : (page - 1) * pageSize + list.length,
      allPage: hasMore ? page + 1 : page,
      source: 'qs',
      info: {
        name: playlistInfo.title || '',
        img: infoImg,
        desc: playlistInfo.desc || '',
        author: safeGet(playlistInfo, ['owner', 'nickname'], ''),
        play_count: formatPlayCount(playlistInfo.count_tracks || 0),
      },
    }
  },

  async getAlbumDetail(albumId) {
    const url = `https://www.qishui.com/share/album?album_id=${albumId}`
    const requestObj = httpFetch(url, { headers: defaultHeaders })
    const { body } = await requestObj.promise

    if (!body || typeof body !== 'string') {
      throw new Error('获取专辑页面失败')
    }

    const marker = '_ROUTER_DATA = '
    const startIdx = body.indexOf(marker)
    if (startIdx < 0) throw new Error('专辑数据未找到')

    let depth = 0
    let inString = false
    let escaped = false
    let started = false
    let jsonStr = ''

    for (let i = startIdx + marker.length; i < body.length; i++) {
      const ch = body[i]
      if (inString) {
        jsonStr += ch
        if (escaped) { escaped = false; continue }
        if (ch === '\\') { escaped = true; continue }
        if (ch === '"') inString = false
        continue
      }
      if (ch === '"') { inString = true; jsonStr += ch; continue }
      if (ch === '{') { depth++; started = true }
      if (ch === '}') { depth-- }
      jsonStr += ch
      if (started && depth === 0) break
    }

    let pageData
    try {
      pageData = JSON.parse(jsonStr)
    } catch (e) {
      throw new Error('解析专辑数据失败')
    }

    const albumInfo = safeGet(pageData, ['loaderData', 'album_page', 'albumInfo'])
    const trackList = safeGet(pageData, ['loaderData', 'album_page', 'trackList'], [])

    if (!albumInfo || !albumInfo.id) throw new Error('专辑信息未找到')

    const artists = albumInfo.artists || []
    const cover = buildImageUrl(albumInfo.url_cover, '~c5_300x300.jpg')

    const list = []
    const ids = new Set()
    for (const track of trackList) {
      if (!track.id || ids.has(track.id)) continue
      ids.add(track.id)

      const trackArtists = track.artists || []
      const trackAlbum = track.album || {}
      const trackCoverUrls = safeGet(trackAlbum, ['url_cover', 'urls'], [])
      const trackCoverUri = safeGet(trackAlbum, ['url_cover', 'uri'], '')
      let trackImg = ''
      if (trackCoverUrls && trackCoverUrls.length > 0) {
        trackImg = String(trackCoverUrls[0]) + String(trackCoverUri) + '~c5_375x375.jpg'
      }
      if (!trackImg) trackImg = cover.replace('~c5_300x300.jpg', '~c5_375x375.jpg')

      list.push({
        singer: formatSingerName(trackArtists, 'name') || formatSingerName(artists, 'name'),
        name: track.name || '',
        albumName: trackAlbum.name || albumInfo.name || '',
        albumId: trackAlbum.id || albumInfo.id || '',
        songmid: String(track.id),
        source: 'qs',
        interval: track.duration ? formatPlayTime(track.duration / 1000) : null,
        img: trackImg,
        lrc: null,
        types: [],
        _types: {},
        typeUrl: {},
      })
    }

    return {
      list,
      total: albumInfo.count_tracks || list.length,
      allPage: 1,
      source: 'qs',
      info: {
        name: albumInfo.name || '',
        img: cover,
        desc: (albumInfo.pclines || []).join(' ').trim() || albumInfo.company || '',
        author: formatSingerName(artists, 'name'),
        play_count: formatPlayCount(albumInfo.count_tracks || 0),
      },
    }
  },

  getTags() {
    return Promise.resolve({
      tags: [],
      hotTag: [],
      source: 'qs',
    })
  },

  getDetailPageUrl(id) {
    return `https://music.douyin.com/qishui/playlist?playlist_id=${id}`
  },
}
