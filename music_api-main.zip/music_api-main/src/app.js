import express from 'express'
import cors from 'cors'
import path from 'path'
import { fileURLToPath } from 'url'
import musicRouter from './routes/music.js'
import sourceRouter from './routes/source.js'
import configRouter from './routes/config.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

const logClients = new Set()
const logBuffer = []
const MAX_LOG_BUFFER = 500

const origLog = console.log
const origWarn = console.warn
const origError = console.error

function broadcastLog(level, args) {
  const msg = args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ')
  const entry = { time: new Date().toISOString(), level, msg }
  logBuffer.push(entry)
  if (logBuffer.length > MAX_LOG_BUFFER) logBuffer.shift()
  const data = `data: ${JSON.stringify(entry)}\n\n`
  for (const client of logClients) {
    try { client.write(data) } catch (e) { logClients.delete(client) }
  }
}

console.log = (...args) => { origLog(...args); broadcastLog('info', args) }
console.warn = (...args) => { origWarn(...args); broadcastLog('warn', args) }
console.error = (...args) => { origError(...args); broadcastLog('error', args) }

const app = express()

app.use(cors())
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true, limit: '10mb' }))

app.use((req, res, next) => {
  if (req.path.startsWith('/api/') && req.path !== '/api/logs') {
    const start = Date.now()
    const queryStr = Object.keys(req.query).length > 0 ? JSON.stringify(req.query) : ''
    const bodyStr = req.body && Object.keys(req.body).length > 0 ? ' body=' + JSON.stringify(req.body).substring(0, 200) : ''
    broadcastLog('info', [`[REQ] ${req.method} ${req.path}${queryStr ? ' query=' + queryStr : ''}${bodyStr}`])
    const origJson = res.json.bind(res)
    res.json = (data) => {
      const duration = Date.now() - start
      const summary = typeof data === 'object' && data !== null
        ? { code: data.code, hasData: !!data.data, dataType: Array.isArray(data.data) ? `array[${data.data.length}]` : typeof data.data, error: data.error, duration: duration + 'ms' }
        : String(data).substring(0, 100)
      broadcastLog('info', [`[RES] ${req.method} ${req.path} ${duration}ms ${JSON.stringify(summary)}`])
      return origJson(data)
    }
  }
  next()
})

app.use(express.static(path.join(__dirname, '..', 'public')))

app.use('/api/music', musicRouter)
app.use('/api/source', sourceRouter)
app.use('/api/config', configRouter)

export function setShutdownCallback(cb) { app._shutdownCallback = cb }

app.post('/api/shutdown', (req, res) => {
  res.json({ code: 200, msg: '服务正在关闭...' })
  setImmediate(() => { if (app._shutdownCallback) app._shutdownCallback() })
})

app.get('/api/logs', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream')
  res.setHeader('Cache-Control', 'no-cache')
  res.setHeader('Connection', 'keep-alive')
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.flushHeaders()
  for (const entry of logBuffer) {
    res.write(`data: ${JSON.stringify(entry)}\n\n`)
  }
  logClients.add(res)
  req.on('close', () => logClients.delete(res))
})

app.get('/api', (req, res) => {
  res.json({
    name: 'Music API',
    version: '1.0.0',
    endpoints: {
      music: {
        search: 'GET /api/music/search?source=kw&keyword=xxx&page=1&limit=30',
        leaderboard: 'GET /api/music/leaderboard?source=kw',
        leaderboardDetail: 'GET /api/music/leaderboard/detail?source=kw&bangid=xxx&page=1',
        songlist: 'GET /api/music/songlist?source=kw&sortId=hot&tagId=&page=1',
        songlistDetail: 'GET /api/music/songlist/detail?source=kw&id=xxx&page=1',
        songlistParse: 'GET /api/music/songlist/parse?url=歌单链接 - 自动识别平台并解析歌单',
        songlistTags: 'GET /api/music/songlist/tags?source=kw',
        songlistSorts: 'GET /api/music/songlist/sorts?source=kw',
        songlistSearch: 'GET /api/music/songlist/search?source=kw&keyword=xxx&page=1&limit=20',
        lyric: 'GET /api/music/lyric?source=kw&songmid=xxx',
        hotSearch: 'GET /api/music/hot-search?source=kw',
        comment: 'GET /api/music/comment?source=kw&songmid=xxx&page=1&limit=20',
        hotComment: 'GET /api/music/comment/hot?source=kw&songmid=xxx&page=1&limit=100',
        tipSearch: 'GET /api/music/tip-search?source=kw&keyword=xxx',
        singerInfo: 'GET /api/music/singer/info?source=kw&id=xxx',
        singerSongs: 'GET /api/music/singer/songs?source=kw&id=xxx&page=1&limit=100',
        singerAlbums: 'GET /api/music/singer/albums?source=kw&id=xxx&page=1&limit=10',
        musicUrl: 'GET /api/music/music-url?source=kw&songmid=xxx&quality=128k',
        audioProxy: 'GET /api/music/audio-proxy/:format?url=xxx&playAuth=xxx (汽水音乐解密代理)',
        sources: 'GET /api/music/sources',
        sodaModes: 'GET /api/music/qs/modes',
        sodaModeTracks: 'GET /api/music/qs/mode/tracks?modeId=xxx&modeName=xxx',
        sodaDiscover: 'GET /api/music/qs/discover',
        sodaDiscoverDetail: 'GET /api/music/qs/discover/detail?id=xxx&kind=xxx',
        sodaRadioTracks: 'GET /api/music/qs/radio/tracks?radioId=xxx&radioName=xxx',
        sodaChartTracks: 'GET /api/music/qs/chart/tracks?chartId=xxx&chartName=xxx',
      },
      source: {
        list: 'GET /api/source/list',
        script: 'GET /api/source/script?id=xxx',
        add: 'POST /api/source/add { id, script, enabled }',
        update: 'PUT /api/source/update { id, script }',
        delete: 'DELETE /api/source/delete { id }',
        toggle: 'POST /api/source/toggle { id, enabled }',
        togglePlatform: 'POST /api/source/toggle-platform { id, platform, enabled }',
        reorder: 'POST /api/source/reorder { ids }',
        reload: 'POST /api/source/reload',
        status: 'GET /api/source/status',
        loaded: 'GET /api/source/loaded',
      },
      config: {
        get: 'GET /api/config',
        update: 'POST /api/config { quality }',
      },
    },
    supportedSources: ['kw', 'kg', 'tx', 'wy', 'mg', 'qs'],
  })
})

app.use((err, req, res, _next) => {
  console.error('[Server] Unhandled error:', err)
  res.status(500).json({ code: 500, error: err.message || 'Internal Server Error' })
})

export default app
