import express from 'express'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { getMusicUrlResult, getConfigQuality } from './music.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const router = express.Router()
const queuePath = path.join(__dirname, '..', '..', 'queue.json')
const playingPath = path.join(__dirname, '..', '..', 'queue-playing.json')

let queueVersion = Date.now()

function loadPlaying() {
  try {
    if (fs.existsSync(playingPath)) {
      return JSON.parse(fs.readFileSync(playingPath, 'utf-8'))
    }
  } catch (e) { console.error('[Queue] loadPlaying error:', e.message) }
  return null
}

function savePlaying(p) {
  try {
    fs.writeFileSync(playingPath, JSON.stringify(p, null, 2))
  } catch (e) { console.error('[Queue] savePlaying error:', e.message) }
}

let globalPlaying = loadPlaying()

function loadQueue() {
  try {
    if (fs.existsSync(queuePath)) {
      const data = JSON.parse(fs.readFileSync(queuePath, 'utf-8'))
      if (data && Array.isArray(data.songs)) return data
    }
  } catch (e) { console.error('[Queue] load error:', e.message) }
  return { songs: [], current: -1, title: '播放列表', updatedAt: 0 }
}

function saveQueue(q) {
  try {
    fs.writeFileSync(queuePath, JSON.stringify(q, null, 2))
  } catch (e) { console.error('[Queue] save error:', e.message) }
}

router.post('/get', (req, res) => {
  res.json({ code: 200, data: loadQueue(), version: queueVersion })
})

router.post('/set', (req, res) => {
  const q = loadQueue()
  const { songs, current, title } = req.body || {}
  if (Array.isArray(songs)) q.songs = songs
  if (typeof current === 'number') q.current = current
  if (title !== undefined) q.title = title
  q.updatedAt = Date.now()
  saveQueue(q)
  res.json({ code: 200, data: q })
})

router.post('/action', (req, res) => {
  const { action, song, index, songs, title } = req.body || {}
  const q = loadQueue()
  let changed = false
  switch (action) {
    case 'add':
      if (!song) return res.status(400).json({ error: '缺少 song 参数' })
      if (!q.songs.find(s => s.songmid === song.songmid)) { q.songs.push(song); changed = true }
      break
    case 'add-all':
      if (!Array.isArray(songs)) return res.status(400).json({ error: '缺少 songs 参数' })
      songs.forEach(s => { if (!q.songs.find(x => x.songmid === s.songmid)) { q.songs.push(s); changed = true } })
      break
    case 'insert-next':
      if (!song) return res.status(400).json({ error: '缺少 song 参数' })
      {
        let pos = (typeof q.current === 'number' && q.current >= 0) ? q.current + 1 : q.songs.length
        if (pos > q.songs.length) pos = q.songs.length
        q.songs = q.songs.filter(s => s.songmid !== song.songmid)
        q.songs.splice(pos, 0, song)
        changed = true
      }
      break
    case 'play-now':
      if (!song) return res.status(400).json({ error: '缺少 song 参数' })
      {
        let pos = (typeof q.current === 'number' && q.current >= 0) ? q.current + 1 : 0
        if (pos > q.songs.length) pos = q.songs.length
        q.songs = q.songs.filter(s => s.songmid !== song.songmid)
        q.songs.splice(pos, 0, song)
        q.current = pos
        changed = true
      }
      break
    case 'replace-all':
      q.songs = Array.isArray(songs) ? songs : []
      q.current = 0
      changed = true
      break
    case 'clear':
      q.songs = []
      q.current = -1
      changed = true
      break
    case 'delete':
      if (typeof index !== 'number') return res.status(400).json({ error: '缺少 index 参数' })
      q.songs.splice(index, 1)
      if (q.current > index) q.current--
      else if (q.current === index) q.current = -1
      changed = true
      break
    default:
      return res.status(400).json({ error: '未知 action: ' + action })
  }
  if (title !== undefined) { q.title = title; changed = true }
  if (changed) {
    q.updatedAt = Date.now()
    queueVersion = Date.now()
    saveQueue(q)
    if (globalPlaying && (q.current === -1 || globalPlaying.index >= q.songs.length)) {
      globalPlaying = null
      savePlaying(null)
    }
  }
  res.json({ code: 200, data: q, version: queueVersion })
})

router.get('/stream', async (req, res) => {
  try {
    const q = loadQueue()
    let idx = parseInt(req.query.index)
    if (isNaN(idx) || idx < 0 || idx >= q.songs.length) {
      return res.status(404).json({ code: 404, error: '歌曲索引越界' })
    }
    const s = q.songs[idx]
    const quality = getConfigQuality()
    const songInfo = { ...s, songmid: s.songmid, source: s.source }
    if (songInfo._types && typeof songInfo._types === 'string') { try { songInfo._types = JSON.parse(songInfo._types) } catch {} }
    if (songInfo.types && typeof songInfo.types === 'string') { try { songInfo.types = JSON.parse(songInfo.types) } catch {} }
    const urls = await getMusicUrlResult(s.source, s.songmid, quality, songInfo)
    if (!urls.length) {
      return res.status(404).json({ code: 404, error: '未找到播放链接' })
    }
    const first = urls[0]
    let url = (first && first.url) ? first.url : first
    if (typeof url === 'object') url = url.url || url.src
    if (!url || typeof url !== 'string') {
      return res.status(404).json({ code: 404, error: '播放链接无效' })
    }
    if (url.indexOf('/') === 0) url = `http://localhost:5566${url}`
    if (url.indexOf('#') === -1) url += '#isMusic=true#'
    else if (url.indexOf('#isMusic=') === -1) url = url.replace('#', '#isMusic=true#')
    q.current = idx
    saveQueue(q)
    globalPlaying = { index: idx, song: s, time: Date.now(), version: queueVersion }
    savePlaying(globalPlaying)
    console.log(`[Queue] stream index=${idx} song=${s.name} url=${url.substring(0, 80)}...`)
    return res.redirect(url)
  } catch (error) {
    console.error('[Queue] stream error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

router.post('/playing', (req, res) => {
  res.json({ code: 200, data: globalPlaying })
})

router.post('/check', (req, res) => {
  const q = loadQueue()
  const clientVersion = (req.body && typeof req.body.version === 'number') ? req.body.version : -1
  res.json({
    code: 200,
    data: {
      version: queueVersion,
      changed: clientVersion !== -1 && clientVersion !== queueVersion,
      queue: q,
      playing: globalPlaying
    }
  })
})

router.get('/next', async (req, res) => {
  try {
    const q = loadQueue()
    if (!q.songs.length) return res.json({ code: 200, data: null })
    let idx = (typeof q.current === 'number' && q.current >= 0) ? q.current + 1 : 0
    if (idx >= q.songs.length) idx = 0
    const s = q.songs[idx]
    const quality = getConfigQuality()
    const songInfo = { ...s, songmid: s.songmid, source: s.source }
    if (songInfo._types && typeof songInfo._types === 'string') { try { songInfo._types = JSON.parse(songInfo._types) } catch {} }
    if (songInfo.types && typeof songInfo.types === 'string') { try { songInfo.types = JSON.parse(songInfo.types) } catch {} }
    const urls = await getMusicUrlResult(s.source, s.songmid, quality, songInfo)
    if (!urls.length) return res.json({ code: 404, error: '未找到播放链接' })
    const first = urls[0]
    let url = (first && first.url) ? first.url : first
    if (typeof url === 'object') url = url.url || url.src
    if (url && url.indexOf('/') === 0) url = `http://localhost:5566${url}`
    q.current = idx
    saveQueue(q)
    globalPlaying = { index: idx, song: s, time: Date.now(), version: queueVersion }
    savePlaying(globalPlaying)
    res.json({ code: 200, data: { index: idx, song: s, url: url } })
  } catch (error) {
    console.error('[Queue] next error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

export default router
