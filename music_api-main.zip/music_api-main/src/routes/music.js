import express from 'express'
import musicSdk from '../modules/musicSdk/index.js'
import { createRequire } from 'module'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import needle from 'needle'
import { decryptAudio } from '../modules/sodaDecrypt.js'
import { toggleSourcePlatform, reloadSources } from '../customSourceHandlers.js'
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const require = createRequire(import.meta.url)
const userApi = require('../modules/userApi.cjs')
const router = express.Router()
const sources = ['kw', 'kg', 'tx', 'wy', 'mg', 'qs']
const QUALITY_ORDER = ['24bit', 'flac', '320k', '192k', '128k']
const configPath = path.join(__dirname, '..', 'config.json')
function getConfigQuality() {
  try {
    if (fs.existsSync(configPath)) {
      const data = JSON.parse(fs.readFileSync(configPath, 'utf-8'))
      if (data && data.quality) return data.quality
    }
  } catch (e) {}
  return '320k'
}
function getQualityFallback(requested) {
  const idx = QUALITY_ORDER.indexOf(requested)
  if (idx >= 0) return QUALITY_ORDER.slice(idx)
  return ['128k']
}
function getSourceModule(source) {
  if (!musicSdk[source]) return null
  return musicSdk[source]
}
function validateSource(req, res, next) {
  const source = req.query.source || req.params.source || req.body?.source
  if (!source) {
    return res.status(400).json({ error: '缺少 source 参数' })
  }
  if (!sources.includes(source) && source !== 'user') {
    const mfSources = userApi.getLoadedApis().flatMap(api => Object.keys(api.sources || {}))
    if (!mfSources.includes(source)) {
      return res.status(400).json({ error: `不支持的音乐源: ${source}，支持的源: ${sources.join(', ')}, user, 以及插件源` })
    }
  }
  next()
}
router.get('/search', validateSource, async (req, res) => {
  try {
    const { source, keyword, page = 1, limit = 30 } = req.query
    if (!keyword) return res.status(400).json({ error: '缺少 keyword 参数' })
    const sdk = getSourceModule(source)
    if (!sdk || !sdk.musicSearch) {
      return res.status(400).json({ error: `源 ${source} 不支持搜索` })
    }
    const result = await sdk.musicSearch.search(keyword, parseInt(page), parseInt(limit))
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] search error:', error.message)
    if (error.message?.includes('try max num')) {
      res.json({ code: 200, data: { total: 0, list: [], allPage: 0, page: 1, limit: 30, source: req.query.source } })
    } else {
      res.status(500).json({ code: 500, error: error.message })
    }
  }
})
router.get('/leaderboard', validateSource, async (req, res) => {
  try {
    const { source } = req.query
    const sdk = getSourceModule(source)
    if (!sdk || !sdk.leaderboard) {
      return res.status(400).json({ error: `源 ${source} 不支持排行榜` })
    }
    const result = await sdk.leaderboard.getBoards()
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] leaderboard error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})
router.get('/hot-search', validateSource, async (req, res) => {
  try {
    const { source } = req.query
    const sdk = getSourceModule(source)
    if (!sdk) {
      return res.status(400).json({ error: `不支持的源 ${source}` })
    }
    const searchModule = sdk.topSearch || sdk.hotSearch
    if (!searchModule) {
      return res.status(400).json({ error: `源 ${source} 不支持热搜` })
    }
    const result = await (searchModule.get ? searchModule.get() : searchModule.getList())
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] hot-search error:', error.message)
    if (error.message?.includes('try max num')) {
      res.json({ code: 200, data: { list: [] } })
    } else {
      res.status(500).json({ code: 500, error: error.message })
    }
  }
})
router.get('/leaderboard/detail', validateSource, async (req, res) => {
  try {
    const { source, bangid, page = 1 } = req.query
    if (!bangid) return res.status(400).json({ error: '缺少 bangid 参数' })
    const sdk = getSourceModule(source)
    if (!sdk || !sdk.leaderboard) {
      return res.status(400).json({ error: `源 ${source} 不支持排行榜详情` })
    }
    const result = await sdk.leaderboard.getList(bangid, parseInt(page))
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] leaderboard detail error:', error.message)
    if (error.message?.includes('try max num')) {
      res.json({ code: 200, data: { total: 0, list: [], limit: 0, page: 1, source: req.query.source } })
    } else {
      res.status(500).json({ code: 500, error: error.message })
    }
  }
})

// 排行榜合并集合模式（获取多个榜单/电台的合并曲目）
router.get('/leaderboard/merged', async (req, res) => {
  try {
    const { ids, limit = 30 } = req.query
    if (!ids) return res.status(400).json({ error: '缺少 ids 参数（多个榜单ID用逗号分隔）' })
    const sdk = getSourceModule('qs')
    if (!sdk || !sdk.leaderboard?.getMergedCharts) {
      return res.status(400).json({ error: '当前源不支持合并集合模式' })
    }
    const chartIds = ids.split(',').map(s => s.trim()).filter(Boolean)
    const result = await sdk.leaderboard.getMergedCharts(chartIds, parseInt(limit))
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] leaderboard merged error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

// 所有榜单曲目合并（一键获取所有榜单的曲目）
router.get('/leaderboard/merged/all', async (req, res) => {
  try {
    const { limit = 30 } = req.query
    const sdk = getSourceModule('qs')
    if (!sdk || !sdk.leaderboard?.getAllMerged) {
      return res.status(400).json({ error: '当前源不支持合并集合模式' })
    }
    const result = await sdk.leaderboard.getAllMerged(parseInt(limit))
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] leaderboard merged all error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

// 所有电台曲目合并（一键获取所有电台的曲目）
router.get('/leaderboard/merged/radio', async (req, res) => {
  try {
    const { limit = 30 } = req.query
    const sdk = getSourceModule('qs')
    if (!sdk || !sdk.leaderboard?.getAllRadioMerged) {
      return res.status(400).json({ error: '当前源不支持电台合并模式' })
    }
    const result = await sdk.leaderboard.getAllRadioMerged(parseInt(limit))
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] leaderboard merged radio error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

// 发现页面（推荐歌单）
router.get('/discover', async (req, res) => {
  try {
    const sdk = getSourceModule('qs')
    if (!sdk || !sdk.getDiscover) {
      return res.status(400).json({ error: '当前源不支持发现功能' })
    }
    const result = await sdk.getDiscover()
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] discover error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

// 推荐歌单详情
router.get('/discover/detail', async (req, res) => {
  try {
    const { id, kind } = req.query
    if (!id) return res.status(400).json({ error: '缺少 id 参数' })
    const sdk = getSourceModule('qs')
    if (!sdk || !sdk.getDiscoverDetail) {
      return res.status(400).json({ error: '当前源不支持推荐歌单功能' })
    }
    const result = await sdk.getDiscoverDetail(id, kind || 'playlist')
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] discover detail error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})
router.get('/songlist', validateSource, async (req, res) => {
  try {
    const { source, sortId, tagId, page = 1 } = req.query
    const sdk = getSourceModule(source)
    if (!sdk || !sdk.songList) {
      return res.status(400).json({ error: `源 ${source} 不支持歌单` })
    }
    const result = await sdk.songList.getList(sortId, tagId, parseInt(page))
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] songlist error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})
router.get('/songlist/detail', validateSource, async (req, res) => {
  try {
    const { source, id, kind, page = 1 } = req.query
    if (!id) return res.status(400).json({ error: '缺少 id 参数' })
    const sdk = getSourceModule(source)
    if (!sdk || !sdk.songList) {
      return res.status(400).json({ error: `源 ${source} 不支持歌单详情` })
    }
    const result = await sdk.songList.getListDetail(id, parseInt(page), kind)
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] songlist detail error:', error.message)
    if (error.message?.includes('try max num')) {
      res.json({ code: 200, data: { total: 0, list: [], allPage: 0, page: 1, source: req.query.source } })
    } else {
      res.status(500).json({ code: 500, error: error.message })
    }
  }
})
router.get('/songlist/parse', async (req, res) => {
  try {
    const { url } = req.query
    if (!url) return res.status(400).json({ error: '缺少 url 参数' })
    const playlistPatterns = {
      kg: [
        { pattern: /kugou\.com\/songlist\/gcid_([a-zA-Z0-9]+)/i, type: 'gcid' },
        { pattern: /kugou\.com\/yy\/special\/single\/(\d+)/i, type: 'special' },
        { pattern: /kugou\.com\/mixsong\/([a-zA-Z0-9]+)/i, type: 'mixsong' },
        { pattern: /kugou\.com\/share\/([a-zA-Z0-9]+)/i, type: 'share' },
      ],
      kw: [
        { pattern: /kuwo\.cn\/playlist_detail\/(\d+)/i, type: 'pid' },
        { pattern: /kuwo\.cn\/playlist\/(\d+)/i, type: 'pid' },
        { pattern: /kuwo\.cn\/h5app\/playlist\/(\d+)/i, type: 'pid' },
        { pattern: /kuwo\.cn\/album_detail\/(\d+)/i, type: 'album' },
        { pattern: /kuwo\.cn\/.*[?&]pid=(\d+)/i, type: 'pid' },
      ],
      tx: [
        { pattern: /y\.qq\.com\/n\/ryqq\/playlist\/(\d+)/i, type: 'playlist' },
        { pattern: /y\.qq\.com\/n\/ryqq\/album\/([a-zA-Z0-9]+)/i, type: 'album' },
        { pattern: /qq\.com\/n\/ryqq\/playlist\/(\d+)/i, type: 'playlist' },
        { pattern: /y\.qq\.com\/.*[?&]id=(\d+)/i, type: 'playlist' },
        { pattern: /i[\d]*\.y\.qq\.com\/.*playlist.*[?&]id=(\d+)/i, type: 'playlist' },
        { pattern: /qq\.com\/.*[?&]id=(\d+)/i, type: 'playlist' },
      ],
      wy: [
        { pattern: /music\.163\.com\/playlist\?id=(\d+)/i, type: 'playlist' },
        { pattern: /music\.163\.com\/#\/playlist\?id=(\d+)/i, type: 'playlist' },
        { pattern: /music\.163\.com\/#\/.*playlist\?id=(\d+)/i, type: 'playlist' },
        { pattern: /music\.163\.com\/.*[?&]id=(\d+)/i, type: 'playlist' },
        { pattern: /163\.com\/playlist\/(\d+)/i, type: 'playlist' },
      ],
      mg: [
        { pattern: /migu\.cn\/v[\d]+\/music\/playlist\/(\d+)/i, type: 'playlist' },
        { pattern: /migu\.cn\/playlist\/([a-zA-Z0-9]+)/i, type: 'playlist' },
        { pattern: /migu\.cn\/.*[?&]playlistId=(\d+)/i, type: 'playlist' },
        { pattern: /migu\.cn\/.*[?&]id=(\d+)/i, type: 'playlist' },
        { pattern: /migu\.cn\/album\/([a-zA-Z0-9]+)/i, type: 'album' },
        { pattern: /c\.migu\.cn\/([a-zA-Z0-9]+)/i, type: 'short' },
      ],
      qs: [
        { pattern: /qishui\.com\/playlist\/([a-zA-Z0-9]+)/i, type: 'playlist' },
        { pattern: /qishui\.com\/.*[?&]playlistId=([a-zA-Z0-9]+)/i, type: 'playlist' },
        { pattern: /music\.douyin\.com\/playlist\/([a-zA-Z0-9]+)/i, type: 'playlist' },
      ],
    }
    let detectedSource = null
    let detectedId = null
    let detectedType = null
    for (const [source, patterns] of Object.entries(playlistPatterns)) {
      for (const { pattern, type } of patterns) {
        const match = url.match(pattern)
        if (match) {
          detectedSource = source
          detectedId = match[1]
          detectedType = type
          console.log(`[Parse] Detected ${source} playlist: ${detectedId} (type: ${detectedType})`)
          break
        }
      }
      if (detectedSource) break
    }
    if (!detectedSource || !detectedId) {
      return res.status(400).json({ error: '无法识别的歌单链接，支持的平台：酷我、酷狗、QQ 音乐、网易云、咪咕、汽水音乐' })
    }
    const sdk = getSourceModule(detectedSource)
    if (!sdk || !sdk.songList) {
      return res.status(400).json({ error: `源 ${detectedSource} 不支持歌单详情` })
    }
    let queryId = detectedId
    if (detectedSource === 'kg') {
      if (detectedType === 'gcid') {
        queryId = `http://m.kugou.com/songlist/gcid_${detectedId}/`
      } else if (detectedType === 'special') {
        queryId = `https://www.kugou.com/yy/special/single/${detectedId}.html`
      }
    } else if (detectedSource === 'mg' && detectedType === 'short') {
      queryId = url
    } else if (detectedSource === 'mg' && (detectedType === 'playlist' || detectedType === 'album')) {
      queryId = url
    }
    const result = await sdk.songList.getListDetail(queryId, 1)
    res.json({ code: 200, data: { source: detectedSource, id: detectedId, type: detectedType, ...result } })
  } catch (error) {
    console.error('[MusicAPI] songlist parse error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})
router.get('/songlist/tags', validateSource, async (req, res) => {
  try {
    const { source } = req.query
    const sdk = getSourceModule(source)
    if (!sdk || !sdk.songList) {
      return res.status(400).json({ error: `源 ${source} 不支持歌单标签` })
    }
    const result = await sdk.songList.getTags()
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] songlist tags error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})
router.get('/songlist/sorts', validateSource, async (req, res) => {
  try {
    const { source } = req.query
    const sdk = getSourceModule(source)
    if (!sdk || !sdk.songList) {
      return res.status(400).json({ error: `源 ${source} 不支持歌单` })
    }
    const sortList = sdk.songList.sortList || []
    res.json({ code: 200, data: { sorts: sortList, source } })
  } catch (error) {
    console.error('[MusicAPI] songlist sorts error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})
router.get('/lyric', validateSource, async (req, res) => {
  try {
    const { source, songmid } = req.query
    if (!songmid) return res.status(400).json({ error: '缺少 songmid 参数' })
    const sdk = getSourceModule(source)
    if (!sdk || !sdk.getLyric) {
      return res.status(400).json({ error: `源 ${source} 不支持歌词` })
    }
    const songInfo = {
      songmid,
      name: req.query.name || '',
      singer: req.query.singer || '',
      hash: req.query.hash || '',
      interval: req.query.interval || '',
      copyrightId: req.query.copyrightId || undefined,
      albumId: req.query.albumId || undefined,
      lrcUrl: req.query.lrcUrl || undefined,
      mrcUrl: req.query.mrcUrl || undefined,
      trcUrl: req.query.trcUrl || undefined,
    }
    const requestObj = sdk.getLyric(songInfo)
    const result = await (requestObj.promise || requestObj)
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] lyric error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})
router.get('/comment', validateSource, async (req, res) => {
  try {
    const { source, songmid, page = 1, limit = 20 } = req.query
    if (!songmid) return res.status(400).json({ error: '缺少 songmid 参数' })
    const sdk = getSourceModule(source)
    if (!sdk || !sdk.comment) {
      return res.status(400).json({ error: `源 ${source} 不支持评论` })
    }
    const result = await sdk.comment.getComment({ songmid }, parseInt(page), parseInt(limit))
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] comment error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})
router.get('/comment/hot', validateSource, async (req, res) => {
  try {
    const { source, songmid, page = 1, limit = 100 } = req.query
    if (!songmid) return res.status(400).json({ error: '缺少 songmid 参数' })
    const sdk = getSourceModule(source)
    if (!sdk || !sdk.comment) {
      return res.status(400).json({ error: `源 ${source} 不支持热门评论` })
    }
    const result = await sdk.comment.getHotComment({ songmid }, parseInt(page), parseInt(limit))
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] hot comment error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})
router.get('/tip-search', validateSource, async (req, res) => {
  try {
    const { source, keyword } = req.query
    if (!keyword) return res.status(400).json({ error: '缺少 keyword 参数' })
    const sdk = getSourceModule(source)
    if (!sdk || !sdk.tipSearch) {
      return res.status(400).json({ error: `源 ${source} 不支持搜索提示` })
    }
    const result = await sdk.tipSearch.search(keyword)
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] tip-search error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})
router.get('/singer/info', validateSource, async (req, res) => {
  try {
    const { source, id } = req.query
    if (!id) return res.status(400).json({ error: '缺少 id 参数' })
    const sdk = getSourceModule(source)
    if (!sdk || !sdk.singer) {
      return res.status(400).json({ error: `源 ${source} 不支持歌手信息` })
    }
    const result = await sdk.singer.getInfo(id)
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] singer info error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})
router.get('/singer/songs', validateSource, async (req, res) => {
  try {
    const { source, id, page = 1, limit = 100 } = req.query
    if (!id) return res.status(400).json({ error: '缺少 id 参数' })
    const sdk = getSourceModule(source)
    if (!sdk || !sdk.singer) {
      return res.status(400).json({ error: `源 ${source} 不支持歌手歌曲` })
    }
    const result = await sdk.singer.getSongList(id, parseInt(page), parseInt(limit))
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] singer songs error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})
router.get('/singer/albums', validateSource, async (req, res) => {
  try {
    const { source, id, page = 1, limit = 10 } = req.query
    if (!id) return res.status(400).json({ error: '缺少 id 参数' })
    const sdk = getSourceModule(source)
    if (!sdk || !sdk.singer) {
      return res.status(400).json({ error: `源 ${source} 不支持歌手专辑` })
    }
    const result = await sdk.singer.getAlbumList(id, parseInt(page), parseInt(limit))
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] singer albums error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})
async function getMusicUrlResult(source, songmid, quality, songInfo) {
  const qualityOrder = getQualityFallback(quality)
  for (const q of qualityOrder) {
    const tasks = []
    if (source === 'qs') {
      const sdk = getSourceModule(source)
      const scriptSongInfo = songInfo || { songmid, source: 'qs' }
      const qsSongInfo = {
        ...userApi.normalizeSongInfo(scriptSongInfo),
        id: songInfo?.id || songmid,
        songmid: songInfo?.songmid || songmid,
      }
      const scriptSources = ['qsvip', 'qs']

      for (const scriptSource of scriptSources) {
        const candidates = userApi.getCandidatesForSource(scriptSource)
        for (const api of candidates) {
          tasks.push({
            name: `${api.info.name}-${scriptSource}-${q}`,
            fn: async () => {
              const result = await api.callRequest('musicUrl', scriptSource, {
                musicInfo: qsSongInfo,
                quality: q,
                type: q
              })
              const url = (result && typeof result === 'object') ? (result.url || result.musicUrl || result.src) : result
              if (url && typeof url === 'string') {
                return { url, type: q, from: 'script', sourceName: api.info.name, sourceId: api.info._sourceId }
              }
              return null
            }
          })
        }
      }

      if (sdk && sdk.musicInfo && sdk.musicInfo.getMusicUrl) {
        tasks.push({
          name: `内置API-${q}`,
          fn: async () => {
            const result = await sdk.musicInfo.getMusicUrl(songmid, q)
            if (result) {
              const url = result.url || result
              if (url && typeof url === 'string') {
                return { url, type: q, from: 'original', sourceName: `内置API` }
              }
            }
            return null
          }
        })
      }
    } else {
      const scriptSource = source
      const scriptSongInfo = songInfo || { songmid, source: scriptSource }
      const candidates = userApi.getCandidatesForSource(scriptSource)
      for (const api of candidates) {
        tasks.push({
          name: `${api.info.name}-${q}`,
          fn: async () => {
            const normalizedSongInfo = userApi.normalizeSongInfo(scriptSongInfo)
            const result = await api.callRequest('musicUrl', scriptSource, {
              musicInfo: normalizedSongInfo,
              quality: q,
              type: q
            })
            const url = (result && typeof result === 'object') ? (result.url || result.musicUrl || result.src) : result
            if (url && typeof url === 'string') {
              return { url, type: q, from: 'script', sourceName: api.info.name, sourceId: api.info._sourceId }
            }
            return null
          }
        })
      }
    }
    const results = await Promise.allSettled(tasks.map(t => t.fn()))
    for (let i = 0; i < results.length; i++) {
      const result = results[i]
      if (result.status === 'fulfilled' && result.value) {
        const val = result.value
        const url = val.url?.url || val.url
        if (url && typeof url === 'string' && (url.startsWith('http') || url.startsWith('/api/'))) {
          return [{ url, type: q, from: val.from, sourceName: val.sourceName, sourceId: val.sourceId || val.sourceName }]
        }
      } else if (result.status === 'rejected') {
        console.warn(`[MusicAPI] ${tasks[i]?.name || '未知'} 获取链接失败:`, result.reason?.message || result.reason)
      }
    }
  }
  return []
}
// === URL Validation & Source Management ===
const _urlCache = new Map()
const _disabledSources = new Map()

function isValidPlayUrl(url) {
  if (!url || typeof url !== 'string') return false
  if (url.length < 15) return false
  if (url.length > 2048) return false
  if (!url.startsWith('http://') && !url.startsWith('https://') && !url.startsWith('/')) return false
  if (url.startsWith('data:') || url.startsWith('file://') || url.startsWith('blob:')) return false
  const lower = url.toLowerCase()
  const errorPatterns = ['404', '403', '502', '500', 'error', 'unavailable', 'notfound', 'not_found', 'forbidden', 'deny', 'login', 'auth', 'expired', 'invalid']
  for (const p of errorPatterns) { if (lower.includes(p)) return false }
  const audioExts = ['.mp3', '.m4a', '.flac', '.wav', '.aac', '.ogg', '.m4r', '.ape', '.opus', '.wma']
  const hasAudioExt = audioExts.some(ext => lower.includes(ext))
  const streamPatterns = ['/stream', '/play', '/audio', '/music', '/file/', 'songmid=', 'song_id=', 'mid=', 'file=', 'url=', 'redirect', 'cdn', 'media']
  const isStreaming = streamPatterns.some(p => lower.includes(p))
  try {
    const fullUrl = url.startsWith('/') ? `http://localhost` : url
    const parsed = new URL(fullUrl)
    if (!parsed.pathname || parsed.pathname.length <= 1) {
      if (!hasAudioExt && !isStreaming) return false
    }
  } catch { return false }
  return true
}

function isSourceDisabled(sourceId, source) {
  return _disabledSources.has(sourceId + ':' + source)
}

async function checkPlayUrl(source, sourceId, songmid, url) {
  if (!url) return { valid: false, disabled: false }
  const cacheKey = (sourceId || 'unknown') + ':' + source
  if (isSourceDisabled(sourceId || 'unknown', source)) return { valid: false, disabled: true }
  const entry = _urlCache.get(cacheKey) || { lastUrl: '', lastSongmid: '', sameCount: 0 }
  if (url === entry.lastUrl && songmid !== entry.lastSongmid) {
    entry.sameCount++
    console.warn('[MusicAPI] ' + (sourceId || 'unknown') + '/' + source + ' 返回相同链接 (' + entry.sameCount + '/3): ' + url.substring(0, 80))
    if (entry.sameCount >= 3) {
      _disabledSources.set(cacheKey, { reason: '连续3次返回相同链接' })
      try {
        if (sourceId && sourceId !== 'original') {
          await toggleSourcePlatform(sourceId, source, false)
          await reloadSources()
          console.error('[MusicAPI] ' + sourceId + '/' + source + ' 已自动取消平台勾选')
        }
      } catch(e) { console.error('[MusicAPI] 取消平台勾选失败:', e.message) }
      return { valid: false, disabled: true }
    }
    entry.lastUrl = url
    entry.lastSongmid = songmid
    _urlCache.set(cacheKey, entry)
    return { valid: false, disabled: false }
  }
  if (url !== entry.lastUrl) entry.sameCount = 0
  entry.lastUrl = url
  entry.lastSongmid = songmid
  _urlCache.set(cacheKey, entry)
  return { valid: true, disabled: false }
}

router.get('/play', async (req, res) => {
  try {
    const { source, songmid } = req.query
    if (!source || !songmid) return res.status(400).json({ error: '缺少 source 或 songmid 参数' })
    if (isSourceDisabled('', source)) {
      return res.status(503).json({ code: 503, error: `源 ` + source + ` 已暂时关闭，请稍后重试或切换其他源` })
    }
    const quality = getConfigQuality()
    const songInfo = { ...req.query, songmid }
    delete songInfo.source
    if (typeof songInfo._types === 'string') { try { songInfo._types = JSON.parse(songInfo._types) } catch {} }
    if (typeof songInfo.types === 'string') { try { songInfo.types = JSON.parse(songInfo.types) } catch {} }
    const urls = await getMusicUrlResult(source, songmid, quality, songInfo)
    if (!urls.length) return res.status(404).json({ code: 404, error: '未找到播放链接' })
    let playUrl = null
    for (const item of urls) {
      let url = (item && item.url) ? item.url : item
      if (typeof url === 'object') url = url.url || url.src
      if (!url || typeof url !== 'string') continue
      if (!isValidPlayUrl(url)) { console.warn(`[MusicAPI] 无效链接已跳过: ` + url.substring(0, 80)); continue }
      const check = await checkPlayUrl(source, item.sourceId || '', songmid, url)
      if (check.disabled) {
        return res.status(503).json({ code: 503, error: `源 ` + source + ` 已暂时关闭，请稍后重试或切换其他源` })
      }
      if (check.valid) { playUrl = url; break }
    }
    if (!playUrl) return res.status(404).json({ code: 404, error: '播放链接无效' })
    if (playUrl.indexOf('/') === 0) playUrl = `http://localhost:5566` + playUrl
    if (playUrl.indexOf('#') === -1) playUrl += '#isMusic=true#'
    else if (playUrl.indexOf('#isMusic=') === -1) playUrl = playUrl.replace('#', '#isMusic=true#')
    console.log(`[MusicAPI] play source=` + source + ` songmid=` + songmid + ` url=` + playUrl.substring(0, 80))
    return res.redirect(playUrl)
  } catch (error) {
    console.error('[MusicAPI] play error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})
router.get('/music-url', async (req, res) => {
  try {
    const { source, songmid } = req.query
    if (!source || !songmid) return res.status(400).json({ error: '缺少 source 或 songmid 参数' })
    const quality = getConfigQuality()
    const songInfo = { songmid, source, ...req.query }
    delete songInfo.source
    if (typeof songInfo._types === 'string') { try { songInfo._types = JSON.parse(songInfo._types) } catch {} }
    if (typeof songInfo.types === 'string') { try { songInfo.types = JSON.parse(songInfo.types) } catch {} }
    let urls = await getMusicUrlResult(source, songmid, quality, songInfo)
    if (urls.length === 0) {
      return res.status(404).json({ code: 404, error: `未找到 ${source} 平台 ${songmid} 的播放链接` })
    }
    res.json({ code: 200, data: urls })
  } catch (error) {
    console.error('[MusicAPI] music-url error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})
router.post('/music-url', async (req, res) => {
  try {
    const { source, songmid, songInfo: bodySongInfo } = req.body
    if (!source || !songmid) return res.status(400).json({ error: '缺少 source 或 songmid 参数' })
    const quality = getConfigQuality()
    const songInfo = bodySongInfo || { songmid, source }
    const urls = await getMusicUrlResult(source, songmid, quality, songInfo)
    if (urls.length === 0) {
      return res.status(404).json({ code: 404, error: `未找到 ${source} 平台 ${songmid} 的播放链接` })
    }
    res.json({ code: 200, data: urls })
  } catch (error) {
    console.error('[MusicAPI] music-url error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})
router.get('/detail', validateSource, async (req, res) => {
  try {
    const { source, songmid } = req.query
    if (!songmid) return res.status(400).json({ error: '缺少 songmid 参数' })
    const sdk = getSourceModule(source)
    if (!sdk || !sdk.musicInfo) {
      return res.status(400).json({ error: `源 ${source} 不支持歌曲详情` })
    }
    const result = await sdk.musicInfo.getMusicDetail(songmid)
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] detail error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})
// ============ 汽水音乐专属API ============
// 推荐模式列表
router.get('/qs/modes', async (req, res) => {
  try {
    const musicSdk = getSourceModule('qs')
    if (!musicSdk || !musicSdk.getModes) {
      return res.status(400).json({ error: '汽水音乐模块未加载' })
    }
    const result = await musicSdk.getModes()
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] qs/modes error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

// 推荐模式详情（曲目列表）
router.get('/qs/mode/tracks', async (req, res) => {
  try {
    const { modeId, modeName } = req.query
    if (!modeId) return res.status(400).json({ error: '缺少 modeId 参数' })
    const musicSdk = getSourceModule('qs')
    if (!musicSdk || !musicSdk.getModeTracks) {
      return res.status(400).json({ error: '汽水音乐模块未加载' })
    }
    const result = await musicSdk.getModeTracks(modeId, modeName || '')
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] qs/mode/tracks error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

// 发现页面
router.get('/qs/discover', async (req, res) => {
  try {
    const musicSdk = getSourceModule('qs')
    if (!musicSdk || !musicSdk.getDiscover) {
      return res.status(400).json({ error: '汽水音乐模块未加载' })
    }
    const result = await musicSdk.getDiscover()
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] qs/discover error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

// 发现详情（歌单/电台/榜单详情）
router.get('/qs/discover/detail', async (req, res) => {
  try {
    const { id, kind } = req.query
    if (!id) return res.status(400).json({ error: '缺少 id 参数' })
    const musicSdk = getSourceModule('qs')
    if (!musicSdk || !musicSdk.getDiscoverDetail) {
      return res.status(400).json({ error: '汽水音乐模块未加载' })
    }
    const result = await musicSdk.getDiscoverDetail(id, kind || 'playlist')
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] qs/discover/detail error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

// 电台曲目
router.get('/qs/radio/tracks', async (req, res) => {
  try {
    const { radioId, radioName } = req.query
    if (!radioId) return res.status(400).json({ error: '缺少 radioId 参数' })
    const musicSdk = getSourceModule('qs')
    if (!musicSdk || !musicSdk.getRadioTracks) {
      return res.status(400).json({ error: '汽水音乐模块未加载' })
    }
    const result = await musicSdk.getRadioTracks(radioId, radioName || '电台')
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] qs/radio/tracks error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

// 榜单曲目
router.get('/qs/chart/tracks', async (req, res) => {
  try {
    const { chartId, chartName } = req.query
    if (!chartId) return res.status(400).json({ error: '缺少 chartId 参数' })
    const musicSdk = getSourceModule('qs')
    if (!musicSdk || !musicSdk.getChartTracks) {
      return res.status(400).json({ error: '汽水音乐模块未加载' })
    }
    const result = await musicSdk.getChartTracks(chartId, chartName || '排行榜')
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] qs/chart/tracks error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

router.get('/songlist/search', validateSource, async (req, res) => {
  try {
    const { source, keyword, page = 1, limit = 20 } = req.query
    if (!keyword) return res.status(400).json({ error: '缺少 keyword 参数' })
    const sdk = getSourceModule(source)
    if (!sdk || !sdk.songList || !sdk.songList.search) {
      return res.status(400).json({ error: `源 ${source} 不支持歌单搜索` })
    }
    const result = await sdk.songList.search(keyword, parseInt(page), parseInt(limit))
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[MusicAPI] songlist search error:', error.message)
    if (error.message?.includes('try max num')) {
      res.json({ code: 200, data: { total: 0, list: [], allPage: 0, page: 1, source: req.query.source } })
    } else {
      res.status(500).json({ code: 500, error: error.message })
    }
  }
})
router.get('/mf-search', async (req, res) => {
  try {
    const { source, keyword, page = 1, type = 'music' } = req.query
    if (!source || !keyword) return res.status(400).json({ error: '缺少 source 或 keyword 参数' })
    const candidates = userApi.getCandidatesForSource(source)
    if (candidates.length === 0) return res.status(400).json({ error: `未找到支持 ${source} 的插件` })
    for (const api of candidates) {
      try {
        const result = await api.callRequest('search', source, { keyword, page: parseInt(page), type })
        if (result && result.data) {
          return res.json({ code: 200, data: result })
        }
      } catch (e) {
        console.warn(`[MusicAPI] mf-search ${api.info.name} 失败:`, e.message)
      }
    }
    res.json({ code: 200, data: { isEnd: true, data: [], total: 0 } })
  } catch (error) {
    console.error('[MusicAPI] mf-search error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

router.get('/mf-lyric', async (req, res) => {
  try {
    const { source, songmid } = req.query
    if (!source || !songmid) return res.status(400).json({ error: '缺少 source 或 songmid 参数' })
    const candidates = userApi.getCandidatesForSource(source)
    if (candidates.length === 0) return res.status(400).json({ error: `未找到支持 ${source} 的插件` })
    for (const api of candidates) {
      try {
        const songInfo = { songmid, source, _mfRaw: JSON.parse(req.query._mfRaw || 'null') }
        const result = await api.callRequest('lyric', source, { musicInfo: songInfo })
        if (result) return res.json({ code: 200, data: result })
      } catch (e) {
        console.warn(`[MusicAPI] mf-lyric ${api.info.name} 失败:`, e.message)
      }
    }
    res.json({ code: 200, data: '' })
  } catch (error) {
    console.error('[MusicAPI] mf-lyric error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

router.get('/mf-toplists', async (req, res) => {
  try {
    const { source } = req.query
    if (!source) return res.status(400).json({ error: '缺少 source 参数' })
    const candidates = userApi.getCandidatesForSource(source)
    for (const api of candidates) {
      try {
        const result = await api.callRequest('getTopLists', source, {})
        if (result) return res.json({ code: 200, data: result })
      } catch (e) {
        console.warn(`[MusicAPI] mf-toplists ${api.info.name} 失败:`, e.message)
      }
    }
    res.json({ code: 200, data: [] })
  } catch (error) {
    console.error('[MusicAPI] mf-toplists error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

router.get('/mf-toplist-detail', async (req, res) => {
  try {
    const { source, id, page = 1 } = req.query
    if (!source || !id) return res.status(400).json({ error: '缺少 source 或 id 参数' })
    const candidates = userApi.getCandidatesForSource(source)
    for (const api of candidates) {
      try {
        const result = await api.callRequest('getTopListDetail', source, { musicInfo: { id, _mfRaw: { id } }, page: parseInt(page) })
        if (result) return res.json({ code: 200, data: result })
      } catch (e) {
        console.warn(`[MusicAPI] mf-toplist-detail ${api.info.name} 失败:`, e.message)
      }
    }
    res.json({ code: 200, data: { isEnd: true, data: [], total: 0 } })
  } catch (error) {
    console.error('[MusicAPI] mf-toplist-detail error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

router.get('/sources', (req, res) => {
  res.json({
    code: 200,
    data: {
      sources: sources.map(s => ({
        id: s,
        name: {
          kw: '酷我',
          kg: '酷狗',
          tx: 'QQ音乐',
          wy: '网易云',
          mg: '咪咕',
          qs: '汽水音乐'
        }[s] || s,
      })),
      userApi: {
        loaded: userApi.getLoadedApis(),
      },
    },
  })
})
router.get('/audio-proxy/:format', async (req, res) => {
  try {
    const { url: audioUrl, playAuth } = req.query
    if (!audioUrl) return res.status(400).json({ error: '缺少 url 参数' })

    const format = req.params.format || 'm4a'
    const contentTypeMap = {
      m4a: 'audio/mp4',
      mp4: 'audio/mp4',
      aac: 'audio/aac',
      flac: 'audio/flac',
      mp3: 'audio/mpeg',
      wav: 'audio/wav',
      ogg: 'audio/ogg',
    }

    const requestHeaders = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
      Referer: 'https://music.douyin.com/',
      Cookie: 'odin_tt=1; ttwid=1',
    }

    const resp = await needle('get', audioUrl, null, {
      headers: requestHeaders,
      response_timeout: 30000,
      binary: true,
    })

    const encData = Buffer.isBuffer(resp.body) ? resp.body : Buffer.from(resp.body)

    if (!playAuth) {
      res.setHeader('Content-Type', contentTypeMap[format] || 'application/octet-stream')
      res.setHeader('Content-Length', encData.length)
      return res.end(encData)
    }

    const decrypted = decryptAudio(encData, playAuth)

    res.setHeader('Content-Type', contentTypeMap[format] || 'application/octet-stream')
    res.setHeader('Content-Length', decrypted.length)
    res.setHeader('Accept-Ranges', 'bytes')
    res.end(decrypted)
  } catch (error) {
    console.error('[MusicAPI] audio-proxy error:', error.message)
    if (!res.headersSent) {
      res.status(500).json({ code: 500, error: `音频解密失败: ${error.message}` })
    }
  }
})

export default router
export { getMusicUrlResult, getConfigQuality, getSourceModule, sources, isValidPlayUrl, isSourceDisabled, checkPlayUrl }
