/**
 * 汽水音乐搜索及本地解析播放测试
 * 运行方式: node test/search-play-test.js
 */
import http from 'http'

const BASE_URL = 'http://127.0.0.1:5566'

function request(path) {
  return new Promise((resolve, reject) => {
    const url = `${BASE_URL}${path}`
    const start = Date.now()
    http.get(url, (res) => {
      let data = ''
      res.on('data', chunk => { data += chunk })
      res.on('end', () => {
        const duration = Date.now() - start
        try {
          const json = JSON.parse(data)
          resolve({ status: res.statusCode, data: json, duration })
        } catch (e) {
          resolve({ status: res.statusCode, data, duration })
        }
      })
    }).on('error', reject)
  })
}

let testSongmid = null
let testLyricSongmid = null

async function testAll() {
  console.log('🎵 汽水音乐搜索及播放测试')
  console.log(`目标服务器: ${BASE_URL}\n`)

  let passCount = 0
  let failCount = 0

  // Test 1: 搜索功能
  console.log('--- Test 1: 搜索功能 (/api/music/search?source=qs&keyword=晴天) ---')
  try {
    const searchRes = await request('/api/music/search?source=qs&keyword=%E6%99%B4%E5%A4%A9&page=1&limit=10')
    if (searchRes.data.code === 200 && searchRes.data.data?.list?.length > 0) {
      const list = searchRes.data.data.list
      console.log(`✅ 搜索成功，共 ${list.length} 条结果 (${searchRes.duration}ms)`)
      console.log('   前3条:')
      list.slice(0, 3).forEach((t, i) => {
        console.log(`   ${i + 1}. ${t.name} - ${t.singer || '未知歌手'} (${t.songmid})`)
      })
      testSongmid = list[0].songmid
      testLyricSongmid = list[0].songmid
      passCount++
    } else {
      console.log('⚠️ 搜索异常:', searchRes.data.error || '未知错误')
      failCount++
    }
  } catch (err) {
    console.log('❌ 搜索测试失败:', err.message)
    failCount++
  }

  // Test 2: 搜索分页
  console.log('\n--- Test 2: 搜索分页 (/api/music/search?source=qs&keyword=七里香&page=2) ---')
  try {
    const page2Res = await request('/api/music/search?source=qs&keyword=%E4%B8%83%E9%87%8C%E9%A6%99&page=2&limit=5')
    if (page2Res.data.code === 200 && page2Res.data.data?.list?.length > 0) {
      console.log(`✅ 分页搜索成功，第2页共${page2Res.data.data.list.length}条 (${page2Res.duration}ms)`)
      console.log(`   总页数: ${page2Res.data.data.allPage}, 总数: ${page2Res.data.data.total}`)
      passCount++
    } else {
      console.log('⚠️ 分页搜索异常:', page2Res.data.error || '无数据')
      failCount++
    }
  } catch (err) {
    console.log('❌ 分页测试失败:', err.message)
    failCount++
  }

  // Test 3: 歌曲详情
  if (testSongmid) {
    console.log(`\n--- Test 3: 歌曲详情 (/api/music/detail?source=qs&songmid=${testSongmid}) ---`)
    try {
      const detailRes = await request(`/api/music/detail?source=qs&songmid=${testSongmid}`)
      if (detailRes.data.code === 200 && detailRes.data.data) {
        const detail = detailRes.data.data
        console.log(`✅ 获取歌曲详情成功 (${detailRes.duration}ms)`)
        console.log(`   歌名: ${detail.name}`)
        console.log(`   歌手: ${detail.singer}`)
        console.log(`   专辑: ${detail.albumName}`)
        console.log(`   时长: ${detail.interval || '未知'}`)
        console.log(`   可用音质: ${detail.types?.length > 0 ? detail.types.map(t => t.type).join(', ') : '未知'}`)
        passCount++
      } else {
        console.log('⚠️ 歌曲详情异常:', detailRes.data.error || '未知错误')
        failCount++
      }
    } catch (err) {
      console.log('❌ 歌曲详情测试失败:', err.message)
      failCount++
    }
  }

  // Test 4: 获取播放链接
  if (testSongmid) {
    console.log(`\n--- Test 4: 获取播放链接 (/api/music/music-url?source=qs&songmid=${testSongmid}&quality=320k) ---`)
    try {
      const urlRes = await request(`/api/music/music-url?source=qs&songmid=${testSongmid}&quality=320k`)
      if (urlRes.status === 200 && urlRes.data.code === 200 && urlRes.data.data?.length > 0) {
        const urlInfo = urlRes.data.data[0]
        console.log(`✅ 获取播放链接成功 (${urlRes.duration}ms)`)
        console.log(`   URL: ${urlInfo.url?.substring(0, 80)}...`)
        console.log(`   来源: ${urlInfo.from} (${urlInfo.sourceName})`)
        console.log(`   音质: ${urlInfo.type}`)
        passCount++
      } else {
        console.log('⚠️ 播放链接异常:', urlRes.data.error || '未知错误')
        failCount++
      }
    } catch (err) {
      console.log('❌ 播放链接测试失败:', err.message)
      failCount++
    }
  }

  // Test 5: 获取歌词
  if (testLyricSongmid) {
    console.log(`\n--- Test 5: 获取歌词 (/api/music/lyric?source=qs&songmid=${testLyricSongmid}) ---`)
    try {
      const lyricRes = await request(`/api/music/lyric?source=qs&songmid=${testLyricSongmid}`)
      if (lyricRes.data.code === 200 && (lyricRes.data.data?.lyric || lyricRes.data.data?.lxlyric)) {
        const lyric = lyricRes.data.data
        console.log(`✅ 获取歌词成功 (${lyricRes.duration}ms)`)
        const lrcPreview = (lyric.lyric || lyric.lxlyric || '').split('\n').slice(0, 3).join('\n')
        console.log('   预览:')
        console.log('   ' + lrcPreview)
        passCount++
      } else {
        console.log('⚠️ 歌词:', lyricRes.data.data || lyricRes.data.error || '无歌词')
        failCount++
      }
    } catch (err) {
      console.log('❌ 歌词测试失败:', err.message)
      failCount++
    }
  }

  // Test 6: 音质选择测试
  if (testSongmid) {
    console.log(`\n--- Test 6: 音质选择测试 ---`)
    const qualities = ['128k', '320k']
    for (const q of qualities) {
      try {
        const qRes = await request(`/api/music/music-url?source=qs&songmid=${testSongmid}&quality=${q}`)
        if (qRes.data.code === 200 && qRes.data.data?.length > 0) {
          const info = qRes.data.data[0]
          console.log(`   ${q} → ${info.type} | 代理: ${info.url?.substring(0, 60)}...`)
        } else {
          console.log(`   ${q} → 无可用链接`)
        }
      } catch (e) {
        console.log(`   ${q} → 请求失败`)
      }
    }
    passCount++
  }

  // Test 7: 搜索提示
  console.log('\n--- Test 7: 搜索提示 (/api/music/tip-search?source=qs&keyword=晴天) ---')
  try {
    const tipRes = await request('/api/music/tip-search?source=qs&keyword=%E6%99%B4%E5%A4%A9')
    if (tipRes.data.code === 200) {
      console.log(`✅ 获取搜索提示成功 (${tipRes.duration}ms)`)
      passCount++
    } else {
      console.log('⚠️ 搜索提示异常:', tipRes.data.error || '未知错误')
      failCount++
    }
  } catch (err) {
    console.log('❌ 搜索提示测试失败:', err.message)
    failCount++
  }

  console.log('\n\n========== 测试完成 ==========')
  console.log(`通过: ${passCount} / 失败: ${failCount}`)
  console.log('注: 歌词API页面结构已变化，需使用JS执行器解析')
}

testAll()
