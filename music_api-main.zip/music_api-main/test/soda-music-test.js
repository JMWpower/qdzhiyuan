/**
 * 汽水音乐推荐及排行功能测试
 * 运行方式: node test/soda-music-test.js
 */
import http from 'http'

const BASE_URL = 'http://127.0.0.1:5566'

function request(path) {
  return new Promise((resolve, reject) => {
    const url = `${BASE_URL}${path}`
    const start = Date.now()
    http.get(url, (res) => {
      let data = ''
      res.on('data', chunk => { data += chunk })
      res.on('end', () => {
        const duration = Date.now() - start
        try {
          const json = JSON.parse(data)
          resolve({ status: res.statusCode, data: json, duration })
        } catch (e) {
          resolve({ status: res.statusCode, data, duration })
        }
      })
    }).on('error', reject)
  })
}

async function testServer() {
  console.log('🚀 开始测试汽水音乐 API...')
  console.log(`目标服务器: ${BASE_URL}`)

  // 测试1: 服务状态
  console.log('\n\n--- Test 1: 服务状态检查 ---')
  try {
    const rootRes = await request('/api')
    if (rootRes.status === 200) {
      console.log('✅ 服务运行正常')
      console.log(`   支持的音乐源: ${rootRes.data.supportedSources?.join(', ')}`)
    } else {
      console.log('❌ 服务状态异常:', rootRes.status)
      return
    }
  } catch (err) {
    console.log('❌ 无法连接到服务:', err.message)
    console.log('   请确保服务已启动: npm start')
    return
  }

  // 测试2: 推荐模式列表
  console.log('\n\n--- Test 2: 推荐模式列表 (/api/music/qs/modes) ---')
  try {
    const modesRes = await request('/api/music/qs/modes')
    if (modesRes.data.code === 200 && modesRes.data.data?.list) {
      const list = modesRes.data.data.list
      console.log(`✅ 获取推荐模式成功，共 ${list.length} 个模式 (${modesRes.duration}ms)`)
      console.log('   前5个模式:')
      list.slice(0, 5).forEach((m, i) => {
        console.log(`   ${i + 1}. ${m.name} (${m.kind})`)
      })
    } else {
      console.log('⚠️ 获取推荐模式异常:', modesRes.data.error || '未知错误')
    }
  } catch (err) {
    console.log('❌ 测试失败:', err.message)
  }

  // 测试3: 推荐模式详情（默认模式 = 热歌榜）
  console.log('\n\n--- Test 3: 默认模式曲目 (/api/music/qs/mode/tracks?modeId=default) ---')
  try {
    const tracksRes = await request('/api/music/qs/mode/tracks?modeId=default&modeName=默认模式')
    if (tracksRes.data.code === 200 && tracksRes.data.data?.list) {
      const list = tracksRes.data.data.list
      console.log(`✅ 获取默认模式曲目成功，共 ${list.length} 首 (${tracksRes.duration}ms)`)
      console.log('   前5首:')
      list.slice(0, 5).forEach((t, i) => {
        console.log(`   ${i + 1}. ${t.name} - ${t.singer || '未知歌手'} (${t.songmid})`)
      })
    } else {
      console.log('⚠️ 获取默认模式曲目异常:', tracksRes.data.error || '未知错误')
    }
  } catch (err) {
    console.log('❌ 测试失败:', err.message)
  }

  // 测试4: 熟悉模式（怀旧电台）
  console.log('\n\n--- Test 4: 熟悉模式 - 怀旧电台 (/api/music/qs/mode/tracks?modeId=familiar) ---')
  try {
    const familiarRes = await request('/api/music/qs/mode/tracks?modeId=familiar&modeName=熟悉模式')
    if (familiarRes.data.code === 200 && familiarRes.data.data?.list) {
      const list = familiarRes.data.data.list
      console.log(`✅ 获取${familiarRes.data.data.name || '电台'}曲目成功，共 ${list.length} 首 (${familiarRes.duration}ms)`)
      console.log('   前3首:')
      list.slice(0, 3).forEach((t, i) => {
        console.log(`   ${i + 1}. ${t.name} - ${t.singer || '未知歌手'}`)
      })
    } else {
      console.log('⚠️ 获取熟悉模式曲目异常:', familiarRes.data.error || '未知错误')
    }
  } catch (err) {
    console.log('❌ 测试失败:', err.message)
  }

  // 测试5: 新鲜模式（新歌榜）
  console.log('\n\n--- Test 5: 新鲜模式 - 新歌榜 (/api/music/qs/mode/tracks?modeId=fresh) ---')
  try {
    const freshRes = await request('/api/music/qs/mode/tracks?modeId=fresh&modeName=新鲜模式')
    if (freshRes.data.code === 200 && freshRes.data.data?.list) {
      const list = freshRes.data.data.list
      console.log(`✅ 获取新歌榜曲目成功，共 ${list.length} 首 (${freshRes.duration}ms)`)
      console.log('   前3首:')
      list.slice(0, 3).forEach((t, i) => {
        console.log(`   ${i + 1}. ${t.name} - ${t.singer || '未知歌手'}`)
      })
    } else {
      console.log('⚠️ 获取新歌榜曲目异常:', freshRes.data.error || '未知错误')
    }
  } catch (err) {
    console.log('❌ 测试失败:', err.message)
  }

  // 测试6: 发现页面
  console.log('\n\n--- Test 6: 发现页面 (/api/music/qs/discover) ---')
  try {
    const discoverRes = await request('/api/music/qs/discover')
    if (discoverRes.data.code === 200 && discoverRes.data.data?.list) {
      const list = discoverRes.data.data.list
      console.log(`✅ 获取发现页面成功，共 ${list.length} 个条目 (${discoverRes.duration}ms)`)
      console.log('   前5个:')
      list.slice(0, 5).forEach((item, i) => {
        console.log(`   ${i + 1}. ${item.name} [${item.kind}] - ${item.desc.substring(0, 30)}...`)
      })
    } else {
      console.log('⚠️ 获取发现页面异常:', discoverRes.data.error || '未知错误')
    }
  } catch (err) {
    console.log('❌ 测试失败:', err.message)
  }

  // 测试7: 热搜
  console.log('\n\n--- Test 7: 热搜列表 (/api/music/hot-search?source=qs) ---')
  try {
    const hotRes = await request('/api/music/hot-search?source=qs')
    if (hotRes.data.code === 200 && hotRes.data.data?.list) {
      const list = hotRes.data.data.list
      console.log(`✅ 获取热搜成功，共 ${list.length} 条 (${hotRes.duration}ms)`)
      list.slice(0, 5).forEach((item, i) => {
        console.log(`   ${i + 1}. ${item.keyword || item.name || item}`)
      })
    } else {
      console.log('⚠️ 获取热搜异常:', hotRes.data.error || '未知错误')
    }
  } catch (err) {
    console.log('❌ 测试失败:', err.message)
  }

  // 测试8: 热歌榜
  console.log('\n\n--- Test 8: 热歌榜 (/api/music/qs/chart/tracks?chartId=7036274230471712007) ---')
  try {
    const chartRes = await request('/api/music/qs/chart/tracks?chartId=7036274230471712007&chartName=热歌榜')
    if (chartRes.data.code === 200 && chartRes.data.data?.list) {
      const list = chartRes.data.data.list
      console.log(`✅ 获取热歌榜成功，共 ${list.length} 首 (${chartRes.duration}ms)`)
      console.log('   前5首:')
      list.slice(0, 5).forEach((t, i) => {
        console.log(`   ${i + 1}. ${t.name} - ${t.singer || '未知歌手'} ${t.interval ? '(' + t.interval + ')' : ''}`)
      })
    } else {
      console.log('⚠️ 获取热歌榜异常:', chartRes.data.error || '未知错误')
    }
  } catch (err) {
    console.log('❌ 测试失败:', err.message)
  }

  // 测试9: 排行榜列表
  console.log('\n\n--- Test 9: 排行榜列表 (/api/music/leaderboard?source=qs) ---')
  try {
    const lbRes = await request('/api/music/leaderboard?source=qs')
    if (lbRes.data.code === 200 && lbRes.data.data?.list) {
      const list = lbRes.data.data.list
      console.log(`✅ 获取排行榜列表成功，共 ${list.length} 个榜单 (${lbRes.duration}ms)`)
      list.forEach((b, i) => {
        console.log(`   ${i + 1}. ${b.name} (${b.id})`)
      })
    } else {
      console.log('⚠️ 获取排行榜列表异常:', lbRes.data.error || '未知错误')
    }
  } catch (err) {
    console.log('❌ 测试失败:', err.message)
  }

  // 测试10: 排行榜详情
  console.log('\n\n--- Test 10: 排行榜详情 (/api/music/leaderboard/detail?source=qs&bangid=7036274230471712007) ---')
  try {
    const lbDetailRes = await request('/api/music/leaderboard/detail?source=qs&bangid=7036274230471712007')
    if (lbDetailRes.data.code === 200 && lbDetailRes.data.data?.list) {
      const list = lbDetailRes.data.data.list
      console.log(`✅ 获取排行榜详情成功，共 ${list.length} 首 (${lbDetailRes.duration}ms)`)
      console.log('   前3首:')
      list.slice(0, 3).forEach((t, i) => {
        console.log(`   ${i + 1}. ${t.name} - ${t.singer || '未知歌手'}`)
      })
    } else {
      console.log('⚠️ 获取排行榜详情异常:', lbDetailRes.data.error || '未知错误')
    }
  } catch (err) {
    console.log('❌ 测试失败:', err.message)
  }

  console.log('\n\n========== 测试完成 ==========')
  console.log('注: 部分测试可能因网络限制或API变动而失败，属于正常现象')
}

testServer()
