js:
if (MY_RULE && MY_RULE.version && String(MY_RULE.version) !== "0") setItem("xj_rule_version", String(MY_RULE.version));
if (getItem("xj_firstopen") == MY_RULE.version) {
let fn = $.require('function');
try { fn.cacheManager.autoCleanIfExpired(); } catch (e) {}
let getDoubanRes = fn.getDoubanRes;
let cachedFetch = fn.cachedFetch;
let d = [];
var fyclass = "剧集";
try {
    var cfg = fn.getXjBase();
    fyclass = cfg.fyclass || fyclass;
} catch (e) {}
var qdHomeMode = 'douban';
if (typeof cfg !== 'undefined' && cfg) {
    if (cfg.xj_home_mode === 'bocai') qdHomeMode = 'bocai';
    else if (cfg.xj_home_mode === 'tmdb') qdHomeMode = 'tmdb';
    else if (cfg.xj_home_mode === 'music') qdHomeMode = 'music';
}
if (qdHomeMode === 'bocai') {
    var _qhSrc = getMyVar("bocai_home_source", "");
    if (!_qhSrc) { try { _qhSrc = fn.getXjBase().last_bocai_home_source || ''; } catch(e) {} }
    if (_qhSrc === 'tmdb_home') qdHomeMode = 'tmdb';
}
if (qdHomeMode === 'music') {
    var _xjMusicDl = fileExist("hiker://files/data/music_api/package.json");
    if (_xjMusicDl) {
        var _xjNodeOk = false;
        try { var _xjc = JSON.parse(fetch("http://localhost:5566/api/config", { timeout: 3000 })); if (_xjc && _xjc.code === 200) _xjNodeOk = true; } catch(e) {}
        var _xjStopped = getItem("mk_node_manually_stopped", "") === "1";
        if (!_xjNodeOk && !_xjStopped && fileExist("hiker://files/data/music_api/node_modules/express/package.json")) {
            try {
                var _xjMNS = null;
                try { _xjMNS = $.require("musicNodeService.js"); } catch(e1) {}
                if (_xjMNS && _xjMNS.ensureRunning) {
                    var _xjPP = getPath("hiker://files/data/music_api/").replace(/^file:\/\//, "");
                    var _xjMI = getPath("hiker://files/data/music_api/index.js").replace(/^file:\/\//, "");
                    _xjMNS.ensureRunning(_xjPP, _xjMI, "music-api-node", "music-api-node");
                }
            } catch(e) { log("Node服务启动失败: " + e.message); }
            var _xjw = 0;
            while (_xjw < 8000) {
                java.lang.Thread.sleep(500); _xjw += 500;
                try { var _xjr = JSON.parse(fetch("http://localhost:5566/api/config", { timeout: 2000 })); if (_xjr && _xjr.code === 200) { _xjNodeOk = true; break; } } catch(e) {}
            }
        }
        if (!_xjNodeOk) qdHomeMode = 'douban';
    }
}
if (qdHomeMode === 'music' && MY_PAGE === 1) {
    if (getVar("mk_queue_loaded", "") !== "1") {
        putVar("mk_queue_loaded", "1");
        try {
            var _mqFile = "hiker://files/rules/星集Media/music/queue.json";
            var _mqData = null;
            if (fileExist(_mqFile)) _mqData = JSON.parse(readFile(_mqFile));
            if (!_mqData || !Array.isArray(_mqData.songs)) _mqData = { songs: [], current: -1, title: "播放列表" };
            if (typeof _mqData.current !== "number") _mqData.current = -1;
            if (!_mqData.title) _mqData.title = "播放列表";
            if (!Array.isArray(_mqData.pending)) _mqData.pending = [];
            putMyVar("musicQueue", JSON.stringify(_mqData));
        } catch(e) {}
    }
}
if (MY_PAGE === 1) {
    try {
        var lunboCacheKey = 'xj_lunbo_cache_v2';
        var lunboCache = getMyVar(lunboCacheKey, '');
        var lunboRule = '';
        if (lunboCache) {
            try { var ld = JSON.parse(lunboCache); if (ld.ts && (Date.now() - ld.ts < 2 * 60 * 60 * 1000)) lunboRule = ld.data; } catch(e) {}
        }
        if (!lunboRule) {
            lunboRule = JSON.parse(fetch("hiker://page/lunbo", {})).rule;
            putMyVar(lunboCacheKey, JSON.stringify({ts: Date.now(), data: lunboRule}));
        }
        eval(lunboRule);
    } catch (e) {
        log("轮播数据加载失败: " + e.message);
    }
    if (typeof banner === 'function' && typeof lundata !== 'undefined' && qdHomeMode !== 'music') banner('海报轮播', true, d, lundata, {
        time: 5000,
        col_type: 'card_pic_1',
        desc: '0'
    });
}
if (qdHomeMode === 'bocai') {
    var _bocaiNav = function(bd) {
        bd.push({ title: '🔥 热映', col_type: 'text_4', url: 'hiker://page/nowplaying#noHistory##noRecordHistory#' });
        bd.push({ title: '⭐ 收藏', col_type: 'text_4', url: 'hiker://collection?rule=星集Media#noRecordHistory#' });
        bd.push({ title: '🕘 历史', col_type: 'text_4', url: 'hiker://history?rule=星集Media#noRecordHistory#' });
        bd.push({ title: '⚙️ 设置', col_type: 'text_4', url: 'hiker://page/parse#noHistory##noRecordHistory##noPre#' });
        bd.push({ col_type: 'line' });
    };
    var _bocaiSrc = '';
    try { _bocaiSrc = String((JSON.parse(fetch("hiker://page/ruleHome", {})) || {}).rule || ''); } catch (eBH) { _bocaiSrc = ''; }
    _bocaiSrc = _bocaiSrc.replace(/^[\uFEFF\s]*js:[\s\r\n]*/, '');
    if (!_bocaiSrc) {
        d.push({ title: '选映主页加载失败: 未获取到ruleHome子页面', col_type: 'text_center_1', url: 'hiker://empty' });
        d.push({ col_type: 'line' });
        _bocaiNav(d);
        setResult(d);
    } else {
        try {
            (function(xj_EMBED, xj_EMBED_D) { eval(_bocaiSrc); })(true, d);
        } catch (eB2) {
            d.push({ title: '选映主页加载失败: ' + (eB2.message || eB2), col_type: 'text_center_1', url: 'hiker://empty' });
            d.push({ col_type: 'line' });
            _bocaiNav(d);
            setResult(d);
        }
    }
 } else if (qdHomeMode === 'tmdb') {
var tmdbConfig = {};
try {
    tmdbConfig = fn.getXjBase();
} catch (e) {
    log("读取TMDB配置失败: " + e);
}
var TMDB_KEY = tmdbConfig.tmdb_key || "";

var TMDB_API_CANDIDATES = [
    "https://api.themoviedb.org",
    "https://api.tmdb.org",
    "https://tmdb.nastool.org"
];

function tmdbAutoSelectApi() {
    var cached = getMyVar("tmdb_api_cached", "");
    if (cached) {
        try {
            var data = JSON.parse(cached);
            if (data.ts && (Date.now() - data.ts < 24 * 60 * 60 * 1000) && data.url) {
                return data.url;
            }
        } catch (e) {}
    }
    if (!TMDB_KEY) return TMDB_API_CANDIDATES[0] + "/3";
    for (var i = 0; i < TMDB_API_CANDIDATES.length; i++) {
        var baseUrl = TMDB_API_CANDIDATES[i];
        try {
            var resp = fetch(baseUrl + "/3/configuration?language=zh-CN", {
                headers: {
                    "User-Agent": "Mozilla/5.0",
                    "Authorization": "Bearer " + TMDB_KEY
                },
                timeout: 5000
            });
            if (resp && resp.trim() && resp.trim().charAt(0) === '{') {
                putMyVar("tmdb_api_cached", JSON.stringify({ ts: Date.now(), url: baseUrl + "/3" }));
                return baseUrl + "/3";
            }
        } catch (e) {
            log("TMDB代理测速失败: " + baseUrl + " - " + e.message);
        }
    }
    return TMDB_API_CANDIDATES[0] + "/3";
}

var TMDB_API = tmdbAutoSelectApi();
var TMDB_IMG_BASE = "https://image.tmdb.org/t/p";
var tmdbFyclass = getMyVar("tmdb_fyclass", "电影");

function tmdbParseTextStyle(text) {
    if (!text) return "";
    var parts = [];
    var i = 0;
    while (i < text.length) {
        if (text.charAt(i) === '\u300c') {
            i++;
            var inner = [];
            while (i < text.length && text.charAt(i) !== '\u300d') {
                inner.push(text.charAt(i));
                i++;
            }
            if (i < text.length) i++;
            parts.push('<b><font color=#FF5D50>', inner.join(''), '</font></b>');
        } else if (text.charAt(i) === '\u300e') {
            i++;
            var inner = [];
            while (i < text.length && text.charAt(i) !== '\u300f') {
                inner.push(text.charAt(i));
                i++;
            }
            if (i < text.length) i++;
            parts.push('<b><font color=#FFA500>', inner.join(''), '</font></b>');
        } else {
            parts.push(text.charAt(i));
            i++;
        }
    }
    return parts.join('');
}

function tmdbFetch(path, params) {
    if (!TMDB_KEY) {
        return { error: "请先在管理页配置TMDB读取令牌" };
    }
    var sep = path.indexOf('?') === -1 ? '?' : '&';
    var url = TMDB_API + path + sep + "language=zh-CN";
    if (params) {
        for (var k in params) {
            url += "&" + k + "=" + encodeURIComponent(params[k]);
        }
    }
    try {
        var resp = fetch(url, {
            headers: {
                "User-Agent": "Mozilla/5.0",
                "Authorization": "Bearer " + TMDB_KEY
            },
            timeout: 10000
        });
        if (!resp || resp.trim() === '') {
            return { error: "TMDB接口无响应，请检查网络或代理地址" };
        }
        var trimmed = resp.replace(/^\s+/, '');
        if (trimmed.charAt(0) === '<') {
            log("TMDB返回HTML: path=" + path + " | " + trimmed.substring(0, 150));
            return { error: "TMDB代理返回HTML: " + path };
        }
        return JSON.parse(resp);
    } catch (e) {
        log("TMDB请求失败: " + e.message + " | URL: " + url);
        return { error: e.message };
    }
}

function tmdbGetGenreMap() {
    var cached = getMyVar("tmdb_genre_map", "");
    if (cached) {
        try {
            var data = JSON.parse(cached);
            if (data.ts && (Date.now() - data.ts < 7 * 24 * 60 * 60 * 1000) && data.data) {
                return data.data;
            }
        } catch (e) {}
    }
    var map = {};
    try {
        var movieGenres = tmdbFetch("/genre/movie/list");
        if (movieGenres && movieGenres.genres) {
            for (var i = 0; i < movieGenres.genres.length; i++) {
                map[movieGenres.genres[i].id] = movieGenres.genres[i].name;
            }
        }
    } catch (e) {
        log("获取电影类型失败: " + e.message);
    }
    try {
        var tvGenres = tmdbFetch("/genre/tv/list");
        if (tvGenres && tvGenres.genres) {
            for (var i = 0; i < tvGenres.genres.length; i++) {
                map[tvGenres.genres[i].id] = tvGenres.genres[i].name;
            }
        }
    } catch (e) {
        log("获取剧集类型失败: " + e.message);
    }
    if (Object.keys(map).length > 0) {
        putMyVar("tmdb_genre_map", JSON.stringify({ ts: Date.now(), data: map }));
    }
    return map;
}

function tmdbGenreNames(genreIds, genreMap) {
    if (!genreIds || !genreMap) return "";
    var names = [];
    for (var i = 0; i < genreIds.length && i < 3; i++) {
        if (genreMap[genreIds[i]]) {
            names.push(genreMap[genreIds[i]]);
        }
    }
    return names.join(" / ");
}

function tmdbRatingText(vote) {
    if (!vote || vote === 0) return "暂无评分";
    return "⭐ " + vote.toFixed(1);
}

var tmdbNavButtons = [
    { title: "电影 | Movie", key: "电影", icon: "47.png" },
    { title: "节目 | TV Show", key: "节目", icon: "58.png" }
];

var tmdbSubCategories = {
    "电影": [
        { id: "now_playing", name: "正在热映" },
        { id: "popular", name: "热门" },
        { id: "upcoming", name: "即将上映" },
        { id: "top_rated", name: "最高评分" }
    ],
    "节目": [
        { id: "on_the_air", name: "正在播出" },
        { id: "airing_today", name: "今日播出" },
        { id: "popular", name: "热门" },
        { id: "top_rated", name: "最高评分" }
    ]
};

var tmdbGenreMapData = {
    "电影": [
        { id: "", name: "全部类型" },
        { id: "28", name: "动作" }, { id: "12", name: "冒险" }, { id: "16", name: "动画" },
        { id: "35", name: "喜剧" }, { id: "80", name: "犯罪" }, { id: "99", name: "纪录" },
        { id: "18", name: "剧情" }, { id: "10751", name: "家庭" }, { id: "14", name: "奇幻" },
        { id: "36", name: "历史" }, { id: "27", name: "恐怖" }, { id: "10402", name: "音乐" },
        { id: "9648", name: "悬疑" }, { id: "10749", name: "爱情" }, { id: "878", name: "科幻" },
        { id: "10770", name: "电视电影" }, { id: "53", name: "惊悚" }, { id: "10752", name: "战争" },
        { id: "37", name: "西部" }
    ],
    "节目": [
        { id: "", name: "全部类型" },
        { id: "10759", name: "动作冒险" }, { id: "16", name: "动画" }, { id: "35", name: "喜剧" },
        { id: "80", name: "犯罪" }, { id: "99", name: "纪录" }, { id: "18", name: "剧情" },
        { id: "10751", name: "家庭" }, { id: "10762", name: "儿童" }, { id: "9648", name: "悬疑" },
        { id: "10763", name: "新闻" }, { id: "10764", name: "真人秀" }, { id: "10765", name: "科幻奇幻" },
        { id: "10766", name: "肥皂剧" }, { id: "10767", name: "脱口秀" }, { id: "10768", name: "战争政治" },
        { id: "37", name: "西部" }
    ]
};


function tmdbAddFilterOptions(d, category) {
    var filter_genre = getMyVar("tmdb_filter_genre", "");
    var filter_year = getMyVar("tmdb_filter_year", "");
    var filter_score = getMyVar("tmdb_filter_score", "");

    var genres = tmdbGenreMapData[category] || tmdbGenreMapData["电影"];
    for (var i = 0; i < genres.length; i++) {
        var g = genres[i];
        var isSelected = (filter_genre === g.id);
        d.push({
            title: isSelected ? '\u201c\u201c' + g.name: g.name,
            col_type: 'scroll_button',
            url: $('hiker://empty#noLoading##noRecordHistory#').lazyRule(function(gid) {
                if (gid === "") {
                    clearMyVar("tmdb_filter_genre");
                } else {
                    putMyVar("tmdb_filter_genre", gid);
                }
                refreshPage(true);
                return 'hiker://empty';
            }, g.id)
        });
    }
    d.push({ col_type: 'blank_block' });

    var years = ["全部年代", "2026", "2025", "2024", "2023", "2022", "2021", "2020", "2019", "2020年代", "2010年代", "2000年代", "90年代", "80年代"];
    for (var i = 0; i < years.length; i++) {
        var title = years[i];
        var isSelected = (filter_year === title) || (filter_year === "" && i === 0);
        d.push({
            title: isSelected ? '\u201c\u201c' + title: title,
            col_type: 'scroll_button',
            url: $('hiker://empty#noLoading##noRecordHistory#').lazyRule(function(year) {
                if (year === "全部年代") {
                    clearMyVar("tmdb_filter_year");
                    clearMyVar("tmdb_custom_year");
                } else {
                    putMyVar("tmdb_filter_year", year);
                    clearMyVar("tmdb_custom_year");
                }
                refreshPage(true);
                return 'hiker://empty';
            }, years[i])
        });
    }
    d.push({ col_type: 'blank_block' });

    var filter_language = getMyVar("tmdb_filter_language", "zh");
    var languages = [
        { id: "all", name: "全部语言" },
        { id: "zh", name: "汉语" }, { id: "en", name: "英语" }, { id: "ja", name: "日语" },
        { id: "ko", name: "朝鲜语" }, { id: "de", name: "德语" }, { id: "fr", name: "法语" },
        { id: "es", name: "西班牙语" }, { id: "it", name: "意大利语" }, { id: "pt", name: "葡萄牙语" },
        { id: "ru", name: "俄语" }, { id: "hi", name: "印地语" }, { id: "th", name: "泰语" }
    ];
    for (var i = 0; i < languages.length; i++) {
        var l = languages[i];
        var isSelected = (filter_language === l.id);
        d.push({
            title: isSelected ? '\u201c\u201c' + l.name : l.name,
            col_type: 'scroll_button',
            url: $('hiker://empty#noLoading##noRecordHistory#').lazyRule(function(lid) {
                putMyVar("tmdb_filter_language", lid);
                refreshPage(true);
                return 'hiker://empty';
            }, l.id)
        });
    }
    d.push({ col_type: 'blank_block' });

    d.push({ col_type: 'line' });
}

function tmdbBuildDiscoverParams(category, subId) {
    var filter_genre = getMyVar("tmdb_filter_genre", "");
    var filter_year = getMyVar("tmdb_filter_year", "");
    var filter_score = getMyVar("tmdb_filter_score", "");
    var filter_language = getMyVar("tmdb_filter_language", "zh");
    var custom_year = getMyVar("tmdb_custom_year", "");

    var isMovie = (category === "电影");
    var params = {
        sort_by: isMovie ? "primary_release_date.desc" : "first_air_date.desc",
        "vote_count.gte": 0
    };

    var today = new Date().toISOString().split('T')[0];
    if (isMovie) {
        switch (subId) {
            case "now_playing":
                var past = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
                params["primary_release_date.gte"] = past;
                params["primary_release_date.lte"] = today;
                break;
            case "popular":
                params.sort_by = "popularity.desc";
                break;
            case "upcoming":
                params["primary_release_date.gte"] = today;
                params.sort_by = "popularity.desc";
                break;
            case "top_rated":
                params.sort_by = "vote_average.desc";
                params["vote_count.gte"] = 200;
                break;
        }
    } else {
        switch (subId) {
            case "on_the_air":
                var pastWeek = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
                var nextWeek = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
                params["air_date.gte"] = pastWeek;
                params["air_date.lte"] = nextWeek;
                break;
            case "airing_today":
                params["air_date.gte"] = today;
                params["air_date.lte"] = today;
                break;
            case "popular":
                params.sort_by = "popularity.desc";
                break;
            case "top_rated":
                params.sort_by = "vote_average.desc";
                params["vote_count.gte"] = 200;
                break;
        }
    }

    if (filter_genre) {
        params.with_genres = filter_genre;
    }
    if (filter_score) {
        params["vote_average.gte"] = filter_score;
    }
    if (filter_language && filter_language !== "all") {
        params.with_original_language = filter_language;
    }

    var actualYear = filter_year === "自定义" ? custom_year : filter_year;
    if (actualYear) {
        if (actualYear.indexOf("年代") !== -1) {
            var decade = parseInt(actualYear);
            if (!isNaN(decade)) {
                if (isMovie) {
                    params["primary_release_date.gte"] = decade + "-01-01";
                    params["primary_release_date.lte"] = (decade + 9) + "-12-31";
                } else {
                    params["first_air_date.gte"] = decade + "-01-01";
                    params["first_air_date.lte"] = (decade + 9) + "-12-31";
                }
            }
        } else if (actualYear === "90年代") {
            if (isMovie) {
                params["primary_release_date.gte"] = "1990-01-01";
                params["primary_release_date.lte"] = "1999-12-31";
            } else {
                params["first_air_date.gte"] = "1990-01-01";
                params["first_air_date.lte"] = "1999-12-31";
            }
        } else if (actualYear === "80年代") {
            if (isMovie) {
                params["primary_release_date.gte"] = "1980-01-01";
                params["primary_release_date.lte"] = "1989-12-31";
            } else {
                params["first_air_date.gte"] = "1980-01-01";
                params["first_air_date.lte"] = "1989-12-31";
            }
        } else {
            if (isMovie) {
                params["primary_release_date.gte"] = actualYear + "-01-01";
                params["primary_release_date.lte"] = actualYear + "-12-31";
            } else {
                params["first_air_date.gte"] = actualYear + "-01-01";
                params["first_air_date.lte"] = actualYear + "-12-31";
            }
        }
    }
    return params;
}

function tmdbGetSubCategoryPath(category, subId) {
    if (category === "电影") {
        return "/movie/" + subId;
    } else {
        return "/tv/" + subId;
    }
}

function tmdbGetDiscoverPath(category) {
    var subList = tmdbSubCategories[category] || [];
    var defaultSub = subList.length > 0 ? subList[0].id : "";
    var subId = getMyVar("tmdb_sub_category", defaultSub);
    if (subId) {
        return tmdbGetSubCategoryPath(category, subId);
    }
    if (category === "电影") return "/movie/popular";
    return "/tv/popular";
}

function tmdbFetchNowPlaying() {
    var cacheKey = "tmdb_nowplaying";
    var cached = getMyVar(cacheKey, "");
    if (cached) {
        try {
            var data = JSON.parse(cached);
            if (data.ts && (Date.now() - data.ts < 60 * 60 * 1000)) {
                return data.data;
            }
        } catch (e) {}
    }
    var result = tmdbFetch("/movie/now_playing");
    if (result && result.results) {
        putMyVar(cacheKey, JSON.stringify({ ts: Date.now(), data: result.results }));
        return result.results;
    }
    return [];
}

function tmdbHasActiveFilters() {
    var filter_genre = getMyVar("tmdb_filter_genre", "");
    var filter_year = getMyVar("tmdb_filter_year", "");
    var filter_score = getMyVar("tmdb_filter_score", "");
    var filter_language = getMyVar("tmdb_filter_language", "zh");
    return !!(filter_genre || filter_year || filter_score || (filter_language !== "all"));
}

function tmdbFetchDiscover(category, pg) {
    var hasFilters = tmdbHasActiveFilters();
    var subList = tmdbSubCategories[category] || [];
    var defaultSub = subList.length > 0 ? subList[0].id : "";
    var subId = getMyVar("tmdb_sub_category", defaultSub);

    var path;
    var params = { page: pg || 1 };

    if (hasFilters) {
        path = (category === "电影") ? "/discover/movie" : "/discover/tv";
        var discoverParams = tmdbBuildDiscoverParams(category, subId);
        for (var k in discoverParams) {
            params[k] = discoverParams[k];
        }
    } else {
        path = tmdbGetSubCategoryPath(category, subId);
    }

    var cacheKey = "tmdb_list_" + path + "_p" + params.page + "_" + subId + "_" + (params.with_genres || "") + "_" + (params.with_original_language || "") + "_" + (params.sort_by || "");
    var cached = getMyVar(cacheKey, "");
    if (cached) {
        try {
            var data = JSON.parse(cached);
            if (data.ts && (Date.now() - data.ts < 30 * 60 * 1000)) {
                return data.data;
            }
        } catch (e) {}
    }
    var result = tmdbFetch(path, params);
    if (result && result.results) {
        putMyVar(cacheKey, JSON.stringify({ ts: Date.now(), data: result }));
        return result;
    }
    return { results: [], total_pages: 1 };
}

var tmdbTipsTitle = {
    "电影": "#电影 | 自定义匹配内容不一定精准 | tmdb",
    "节目": "#节目 | 自定义匹配内容不一定精准 | tmdb"
}[tmdbFyclass] || "#电影 | 自定义匹配内容不一定精准 | tmdb";

function renderTmdbUI(d) {
    d.push({
        url: $.toString(function() {
            var panJump = $.require('function').openPanInput(input);
            if (panJump) return panJump;
            return $('hiker://empty/search?page=fypage&word=' + encodeURIComponent(input) + '#noRecordHistory#').rule(function() {
                var keyword = getParam('word');
                if (/%[0-9A-Fa-f]{2}/.test(keyword)) { try { keyword = decodeURIComponent(keyword); } catch (eDec) {} }
                var pg = getParam('page') || 1;
                var sd = [];
                var TMDB_API_URL = "";
                var TMDB_API_KEY = "";
                try {
                    var cfg = $.require('function').getXjBase();
                    TMDB_API_URL = cfg.tmdb_api ? cfg.tmdb_api.replace(/\/+$/, '') : "https://api.tmdb.org/3";
                    if (TMDB_API_URL.indexOf('/3') === -1) {
                        TMDB_API_URL = TMDB_API_URL + '/3';
                    }
                    TMDB_API_KEY = cfg.tmdb_key || "";
                } catch (e) {}
                if (!TMDB_API_KEY) {
                    sd.push({ title: "请先在管理页配置TMDB读取令牌", col_type: "text_center_1" });
                    setResult(sd);
                    return;
                }
                var IMG = "https://image.tmdb.org/t/p";
                var url = TMDB_API_URL + "/search/multi?language=zh-CN&query=" + encodeURIComponent(keyword) + "&page=" + pg;
                try {
                    var resp = fetch(url, {
                        headers: {
                            "User-Agent": "Mozilla/5.0",
                            "Authorization": "Bearer " + TMDB_API_KEY
                        },
                        timeout: 10000
                    });
                    var json = JSON.parse(resp);
                    if (json && json.results) {
                        for (var i = 0; i < json.results.length; i++) {
                            var item = json.results[i];
                            if (item.media_type === "person") continue;
                            var isMovie = item.media_type === "movie";
                            var title = isMovie ? item.title : item.name;
                            var date = isMovie ? item.release_date : item.first_air_date;
                            var year = date ? date.substring(0, 4) : "";
                            var poster = item.poster_path ? IMG + "/w342" + item.poster_path : "";
                            var typeTag = isMovie ? "[电影]" : "[剧集]";
                            var rating = item.vote_average ? "⭐ " + item.vote_average.toFixed(1) : "暂无评分";
                            sd.push({
                                title: typeTag + " " + title,
                                desc: rating + " | " + year,
                                pic_url: poster,
                                col_type: "movie_1_vertical_pic",
                                url: "hiker://page/tmdb_Detail?type=" + item.media_type + "&id=" + item.id
                            });
                        }
                    }
                    if (sd.length === 0) {
                        sd.push({ title: "未找到相关结果", col_type: "text_center_1" });
                    }
                } catch (e) {
                    sd.push({ title: "搜索失败: " + e.message, col_type: "text_center_1" });
                }
                setResult(sd);
            });
        }),
        col_type: 'input',
        title: "🔍"
    });
    d.push({ title: '热映', col_type: 'icon_5', pic_url: 'https://cdn.jsdelivr.net/gh/JMWpower/qdzhiyuan@main/icons/%E7%83%AD%E6%98%A02.png', url: 'hiker://page/nowplaying#noHistory##noRecordHistory#' });
    d.push({ title: '收藏', col_type: 'icon_5', pic_url: 'https://cdn.jsdelivr.net/gh/JMWpower/qdzhiyuan@main/icons/%E6%94%B6%E8%97%8F2.png', url: 'hiker://collection?rule=星集Media#noRecordHistory#' });
    d.push({ title: '历史', col_type: 'icon_5', pic_url: 'https://cdn.jsdelivr.net/gh/JMWpower/qdzhiyuan@main/icons/%E5%8E%86%E5%8F%B22.png', url: 'hiker://history?rule=星集Media#noRecordHistory#' });
    d.push({ title: "选映", col_type: "icon_5", pic_url: 'https://cdn.jsdelivr.net/gh/JMWpower/qdzhiyuan@main/icons/%E9%80%89%E6%98%A02.png', url: 'hiker://page/ruleHome#noHistory##noRecordHistory#' });
	d.push({ title: '设置', col_type: 'icon_5', pic_url: 'https://cdn.jsdelivr.net/gh/JMWpower/qdzhiyuan@main/icons/%E8%AE%BE%E7%BD%AE2.png', url: 'hiker://page/parse#noHistory##noRecordHistory##noPre#' });
    d.push({ col_type: 'line' });

    for (var i = 0; i < tmdbNavButtons.length; i++) {
        var btn = tmdbNavButtons[i];
        d.push({
            title: btn.title,
            col_type: "text_2",
            url: $("#noLoading##noRecordHistory#").lazyRule(function(param) {
                putMyVar("tmdb_fyclass", param);
                putMyVar("tmdb_fypage", "1");
                clearMyVar("tmdb_filter_genre");
                clearMyVar("tmdb_filter_year");
                clearMyVar("tmdb_filter_sort");
                clearMyVar("tmdb_filter_score");
                clearMyVar("tmdb_filter_language");
                clearMyVar("tmdb_custom_year");
                var subs = {
                    "电影": "now_playing",
                    "节目": "on_the_air"
                };
                putMyVar("tmdb_sub_category", subs[param] || "");
                refreshPage(true);
                return "hiker://empty";
            }, btn.key)
        });
    }

    d.push({
        url: "hiker://empty",
        col_type: "line"
    });

    d.push({
        url: "hiker://history?rule=星集Media#noRecordHistory#",
        pic_url: "https://ghproxy.net/https://raw.githubusercontent.com/ls125781003/tubiao/main/q/" + (tmdbFyclass === "节目" ? "58.png" : "47.png"),
        col_type: "avatar",
        title: tmdbTipsTitle
    });

    var subList = tmdbSubCategories[tmdbFyclass] || [];
    var defaultSub = subList.length > 0 ? subList[0].id : "";
    var currentSub = getMyVar("tmdb_sub_category", defaultSub);
    if (!currentSub && defaultSub) {
        putMyVar("tmdb_sub_category", defaultSub);
        currentSub = defaultSub;
    }
    for (var i = 0; i < subList.length; i++) {
        var sub = subList[i];
        var isActive = (currentSub === sub.id);
        d.push({
            title: isActive ? '\u2018\u2018\u2019\u2019<b><font color="#FF5D50">' + sub.name + '</font></b>' : sub.name,
            col_type: 'scroll_button',
            url: $('hiker://empty#noLoading##noRecordHistory#').lazyRule(function(sid) {
                putMyVar("tmdb_sub_category", sid);
                clearMyVar("tmdb_filter_genre");
                clearMyVar("tmdb_filter_year");
                clearMyVar("tmdb_filter_score");
                putMyVar("tmdb_filter_language", "zh");
                refreshPage(true);
                return 'hiker://empty';
            }, sub.id)
        });
    }
    d.push({ col_type: 'blank_block' });

    tmdbAddFilterOptions(d, tmdbFyclass);
}

function renderTmdbContent(d) {
    var genreMap = tmdbGetGenreMap();
    var data = tmdbFetchDiscover(tmdbFyclass, page);
    var items = data.results || [];

    if (items.length > 0) {
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            var title = item.title || item.name || "";
            var date = item.release_date || item.first_air_date || "";
            var year = date ? date.substring(0, 4) : "";
            var poster = item.poster_path ? TMDB_IMG_BASE + "/w342" + item.poster_path : "";
            var isMovie = (tmdbFyclass === "电影") || (item.media_type === "movie");
            var mediaType = isMovie ? "movie" : "tv";
            var genres = tmdbGenreNames(item.genre_ids, genreMap);
            var desc = tmdbRatingText(item.vote_average);
            if (year) desc += " | " + year;
            if (genres) desc += " | " + genres;

            d.push({
                title: tmdbParseTextStyle(title),
                desc: tmdbParseTextStyle(desc),
                pic_url: poster,
                col_type: "movie_3_marquee",
                url: "hiker://page/tmdb_Detail?type=" + mediaType + "&id=" + item.id 
            });
        }
    } else if (page === 1) {
        d.push({
            title: '没有了，真的一点都没有了!',
            url: "hiker://empty",
            col_type: "text_center_1",
            extra: {
                onClick: "refreshPage(true)"
            }
        });
    }
}

var page = parseInt(MY_PAGE) || 1;
if (MY_PAGE === 1) {
    renderTmdbUI(d);
}
renderTmdbContent(d);
setResult(d);
 } else if (qdHomeMode === 'music') {
var API_BASE = "http://localhost:5566";
var fypage = parseInt(MY_PAGE) || 1;
var LOGO_BASE = "https://cdn.jsdelivr.net/gh/JMWpower/qdzhiyuan@main/logo/";
var PLATFORMS = [
    { id: "wy", name: "网易云", icon: LOGO_BASE + "网易云.png" },
    { id: "kg", name: "酷狗", icon: LOGO_BASE + "酷狗.png" },
    { id: "kw", name: "酷我", icon: LOGO_BASE + "酷我.png" },
    { id: "tx", name: "QQ", icon: LOGO_BASE + "QQ.png" },
    { id: "mg", name: "咪咕", icon: LOGO_BASE + "咪咕.png" },
    { id: "qs", name: "汽水", icon: LOGO_BASE + "汽水.png" }
];
var ALL_PLATFORMS = [
    { id: "wy", name: "网易云" },
    { id: "kg", name: "酷狗" },
    { id: "kw", name: "酷我" },
    { id: "tx", name: "QQ" },
    { id: "mg", name: "咪咕" },
    { id: "qs", name: "汽水" }
];
var TABS = ["推荐", "排行"];
var titleMap = {
    "wy": "网易云 - 发现好音乐",
    "kg": "酷狗 - 就是歌多",
    "kw": "酷我 - 好音质 用酷我",
    "tx": "QQ - 听我想听",
    "mg": "咪咕 - 放肆听、趣玩乐",
    "qs": "汽水 - 发现更多好音乐"
};

function getPlatformIcon(id) {
    for (var i = 0; i < PLATFORMS.length; i++) { if (PLATFORMS[i].id === id) return PLATFORMS[i].icon; }
    return "";
}
function getPlatformName(id) {
    for (var i = 0; i < ALL_PLATFORMS.length; i++) { if (ALL_PLATFORMS[i].id === id) return ALL_PLATFORMS[i].name; }
    return id;
}

    var musicDownloaded = fileExist("hiker://files/data/music_api/package.json");
    if (!musicDownloaded) {
        var md = [];
        md.push({ col_type: "line" });
        md.push({ title: "音乐服务未下载", col_type: "text_center_1", url: "hiker://empty", extra: { lineVisible: false } });
        md.push({ title: "请先在设置中下载音乐服务", col_type: "text_center_1", url: "hiker://empty", extra: { lineVisible: false } });
        md.push({ col_type: "line" });
        md.push({ title: "前往设置", col_type: "text_center_1", url: "hiker://page/parse#noHistory##noRecordHistory##noPre#", extra: { backgroundColor: "#1051CF66" } });
        setResult(md);
        $.exports = md;
    } else {
    var currentPlatform = getItem("mk_current_platform", "wy");
    var currentTab = getItem("mk_current_tab", "推荐");

    var md = [];

    if (MY_PAGE === 1) {
        if (typeof banner === 'function' && typeof lundata !== 'undefined' && lundata.length > 0) banner('海报轮播', true, md, lundata, {
            time: 5000,
            col_type: 'card_pic_1',
            desc: '0'
        });

        md.push({
            title: "搜索",
            desc: "#输入歌名或歌单链接...",
            col_type: "input",
            url: "'hiker://page/musicSongs?type=ss&pt=" + currentPlatform + "&sspage=fypage&keyword='+encodeURIComponent(input)"
        });

        TABS.forEach(function(tab) {
            md.push({
                title: currentTab === tab ? "● " + tab : tab,
                col_type: "text_5",
                url: $("#noLoading#").lazyRule((t) => { setItem("mk_current_tab", t); refreshPage(true); return "hiker://empty"; }, tab)
            });
        });
        md.push({ title: "收藏", col_type: "text_5", url: "hiker://page/musicFav" });
        md.push({ title: "列表", col_type: "text_5", url: "hiker://page/musicQueue?ts=" + Date.now() + "#noRecordHistory##noCache#" });
        md.push({ title: "设置", col_type: "text_5", url: "hiker://page/parse#noHistory##noRecordHistory##noPre#" });
        md.push({ col_type: "line" });

        md.push({
            title: titleMap[currentPlatform] || "星集Media 畅享好听o(*￣▽￣*)ブ",
            img: getPlatformIcon(currentPlatform),
            col_type: "avatar",
            url: $("#noLoading#").lazyRule((platforms) => {
                const hikerPop = $.require("hikerPop.js");
                var cur = getItem("mk_current_platform", "wy");
                var curIdx = 0;
                var opts = platforms.map(function(p, i) { if (p.id === cur) curIdx = i; return (p.id === cur ? "√ " : "") + p.name; });
                hikerPop.selectCenter({
                    options: opts,
                    columns: 2,
                    title: "请选择",
                    position: curIdx,
                    click(a, i) {
                        hikerPop.runOnNewThread(() => {
                            if (platforms[i]) setItem("mk_current_platform", platforms[i].id);
                            setItem("mk_current_tab", "推荐");
                            refreshPage(true);
                        });
                    }
                });
                return "hiker://empty";
            }, ALL_PLATFORMS)
        });
    }

    if (currentTab === "推荐") {
        var currentSortId = getItem("mk_sort_" + currentPlatform, "");
        var currentTagId = getItem("mk_tag_" + currentPlatform, "");
        var currentTagCat = getItem("mk_tagCat_" + currentPlatform, "");
        var currentSortName = "";
        var sortsList = [];
        var hotTags = [];

        try {
            var sortsRes = fetch(API_BASE + "/api/music/songlist/sorts?source=" + currentPlatform, { timeout: 5000 });
            var sortsData = JSON.parse(sortsRes);
            if (sortsData && sortsData.data && sortsData.data.sorts) {
                sortsList = sortsData.data.sorts;
            }
        } catch(e) {}

        if (sortsList.length > 0) {
            if (!currentSortId) {
                currentSortId = String(sortsList[0].id);
                setItem("mk_sort_" + currentPlatform, currentSortId);
            } else {
                var sortExists = false;
                for (var si = 0; si < sortsList.length; si++) {
                    if (String(sortsList[si].id) === currentSortId) { sortExists = true; currentSortName = sortsList[si].name; break; }
                }
                if (!sortExists) { currentSortId = String(sortsList[0].id); currentSortName = sortsList[0].name; setItem("mk_sort_" + currentPlatform, currentSortId); }
            }
        }
        if (!currentSortId) currentSortId = "hot";
        if (!currentSortName) currentSortName = "推荐";

        var currentTagName = "";
        var tagNameMap = {};
        var tagGroups = [];

        try {
            var tagsRes = fetch(API_BASE + "/api/music/songlist/tags?source=" + currentPlatform, { timeout: 5000 });
            var tagsData = JSON.parse(tagsRes);
            if (tagsData && tagsData.data) {
                if (tagsData.data.hotTag) hotTags = tagsData.data.hotTag;
                if (tagsData.data.tags) {
                    tagsData.data.tags.forEach(function(cat) {
                        if (cat.list && cat.list.length > 0) {
                            tagGroups.push({ name: cat.name, list: cat.list });
                        }
                    });
                }
                var allTags = [];
                if (hotTags) allTags = allTags.concat(hotTags);
                tagGroups.forEach(function(g) { allTags = allTags.concat(g.list); });
                allTags.forEach(function(t) {
                    var tId = String(t.id || t.name || "");
                    var tName = t.name || t.id || "";
                    if (tId && tName) tagNameMap[tId] = tName;
                });
                currentTagName = tagNameMap[currentTagId] || "";
            }
        } catch(e) {}

        if (MY_PAGE === 1) {
            if (sortsList.length > 1) {
                md.push({
                    title: (String(sortsList[0].id) === currentSortId ? "● " : "") + sortsList[0].name,
                    col_type: "scroll_button",
                    url: $("#noLoading#").lazyRule((p, sId) => { setItem("mk_sort_" + p, String(sId)); setItem("mk_tag_" + p, ""); refreshPage(true); return "hiker://empty"; }, currentPlatform, sortsList[0].id)
                });
                for (var ssi = 1; ssi < sortsList.length; ssi++) {
                    (function(s) {
                        md.push({
                            title: (String(s.id) === currentSortId ? "● " : "") + s.name,
                            col_type: "scroll_button",
                            url: $("#noLoading#").lazyRule((p, sId) => { setItem("mk_sort_" + p, String(sId)); setItem("mk_tag_" + p, ""); refreshPage(true); return "hiker://empty"; }, currentPlatform, s.id)
                        });
                    })(sortsList[ssi]);
                }
                md.push({ col_type: "blank_block" });
            }

            if (hotTags.length > 0 || tagGroups.length > 0) {
                md.push({
                    title: (!currentTagCat ? "● " : "") + "热门",
                    col_type: "scroll_button",
                    url: $("#noLoading#").lazyRule((p) => { setItem("mk_tagCat_" + p, ""); setItem("mk_tag_" + p, ""); refreshPage(true); return "hiker://empty"; }, currentPlatform)
                });
                tagGroups.forEach(function(group) {
                    md.push({
                        title: (currentTagCat === group.name ? "● " : "") + group.name,
                        col_type: "scroll_button",
                        url: $("#noLoading#").lazyRule((p, catName) => { setItem("mk_tagCat_" + p, catName); setItem("mk_tag_" + p, ""); refreshPage(true); return "hiker://empty"; }, currentPlatform, group.name)
                    });
                });
                md.push({ col_type: "blank_block" });

                var displayTags = [];
                if (currentTagCat && tagGroups.length > 0) {
                    for (var gi = 0; gi < tagGroups.length; gi++) {
                        if (tagGroups[gi].name === currentTagCat) {
                            displayTags = tagGroups[gi].list;
                            break;
                        }
                    }
                    if (displayTags.length === 0) { currentTagCat = ""; setItem("mk_tagCat_" + currentPlatform, ""); }
                }
                if (!currentTagCat) displayTags = hotTags;

                if (displayTags.length > 0) {
                    md.push({
                        title: (currentTagId ? "" : "● ") + "全部",
                        col_type: "scroll_button",
                        url: $("#noLoading#").lazyRule((p) => { setItem("mk_tag_" + p, ""); refreshPage(true); return "hiker://empty"; }, currentPlatform)
                    });
                    displayTags.forEach(function(t) {
                        var tId = String(t.id || t.name || "");
                        var tName = t.name || t.id || "";
                        md.push({
                            title: (tId === currentTagId ? "● " : "") + tName,
                            col_type: "scroll_button",
                            url: $("#noLoading#").lazyRule((p, tagId) => { setItem("mk_tag_" + p, tagId); refreshPage(true); return "hiker://empty"; }, currentPlatform, tId)
                        });
                    });
                }
            }
            md.push({ col_type: "line" });
            md.push({ title: getPlatformName(currentPlatform) + " " + currentSortName + "歌单" + (currentTagName ? " · " + currentTagName : ""), col_type: "text_center_1", url: "hiker://empty", extra: { lineVisible: false } });
        }

        try {
            var listUrl = API_BASE + "/api/music/songlist?source=" + currentPlatform + "&sortId=" + encodeURIComponent(currentSortId) + "&tagId=" + encodeURIComponent(currentTagId) + "&page=" + fypage;
            var res = fetch(listUrl, { timeout: 10000 });
            var data = JSON.parse(res);
            if (data && data.data && data.data.list && data.data.list.length > 0) {
                data.data.list.forEach(function(item) {
                    var listId = item.id || item.listId || "";
                    var listName = item.name || item.title || "";
                    md.push({
                        title: listName,
                        img: item.img || item.pic || item.cover || "",
                        desc: item.desc || (item.play_count ? "播放 " + item.play_count : ""),
                        col_type: "card_pic_3_center",
                        url: "hiker://page/musicSongs?type=gd&pt=" + currentPlatform + "&id=" + listId + "&title=" + encodeURIComponent(listName) + "&img=" + encodeURIComponent(item.img || item.pic || item.cover || ""),
                        extra: {
                            longClick: [{
                                title: "❤收藏歌单",
                                js: $.toString(function(pPt, pId, pName, pImg) {
                                    var p = "hiker://files/rules/星集Media/music/fav_playlists.json";
                                    var arr = [];
                                    try { if (fileExist(p)) arr = JSON.parse(readFile(p)); } catch(e) {}
                                    for (var i = 0; i < arr.length; i++) { if (arr[i].id === pId && arr[i].pt === pPt) return "toast://已收藏"; }
                                    arr.push({ name: pName, pt: pPt, id: pId, img: pImg });
                                    writeFile(p, JSON.stringify(arr));
                                    return "toast://歌单已收藏";
                                }, currentPlatform, String(listId), listName, item.img || item.pic || item.cover || "")
                            }]
                        }
                    });
                });
            } else { md.push({ title: "暂无推荐内容", col_type: "text_center_1", url: "hiker://empty" }); }
        } catch(e) { md.push({ title: "加载失败: " + e.message, col_type: "text_center_1", url: "hiker://empty" }); }

    } else if (currentTab === "排行") {
        if (MY_PAGE === 1) {
            md.push({ title: getPlatformName(currentPlatform) + " ★ 排行榜", col_type: "text_center_1", url: "hiker://empty", extra: { lineVisible: false } });
        }
        try {
            var res = fetch(API_BASE + "/api/music/leaderboard?source=" + currentPlatform, { timeout: 10000 });
            var data = JSON.parse(res);
            var boards = [];
            if (data && data.code === 200) {
                if (data.data && Array.isArray(data.data.list)) boards = data.data.list;
                else if (Array.isArray(data.data)) boards = data.data;
            }
            var platformIcon = getPlatformIcon(currentPlatform);
            if (boards.length > 0) {
                boards.forEach(function(board) {
                    var bangid = String(board.bangid || board.id || "");
                    var bangName = board.name || "排行榜";
                    var boardImg = board.img || board.pic || board.cover || platformIcon || "";
                    md.push({
                        title: bangName,
                        img: boardImg,
                        col_type: "card_pic_3_center",
                        url: "hiker://page/musicSongs?type=lb&pt=" + currentPlatform + "&id=" + bangid + "&title=" + encodeURIComponent(bangName) + (boardImg ? "&img=" + encodeURIComponent(boardImg) : "")
                    });
                });
            } else { md.push({ title: "暂无排行榜数据", col_type: "text_center_1", url: "hiker://empty" }); }
        } catch(e) { md.push({ title: "加载失败: " + e.message, col_type: "text_center_1", url: "hiker://empty" }); }
    }

    setResult(md);
    $.exports = md;
    }
} else {
var classMap = {
    "剧集": "电视剧",
    "电影": "电影",
    "综艺": "综艺",
    "动漫": "动漫"
};
var titleMap = {
    "剧集": "#电视剧 | episode | Form_douban",
    "电影": "#电影 | movie | Form_douban",
    "综艺": "#综艺 | variety | Form_douban",
    "动漫": "#动漫 | anime | Form_douban"
};
var navButtons = [{
        title: "剧集",
        icon: "%E5%89%A7%E9%9B%86.png"
    },
    {
        title: "电影",
        icon: "%E7%94%B5%E5%BD%B1.png"
    },
    {
        title: "综艺",
        icon: "%E7%BB%BC%E8%89%BA.png"
    },
    {
        title: "动漫",
        icon: "%E5%8A%A8%E6%BC%AB.png"
    }
];

function addFilterOptions(d, category) {
    var color = '#FF5D50';
    var filter_local = getMyVar("filter_local", "");
    var filter_type = getMyVar("filter_type", "");
    var filter_year = getMyVar("filter_year", "");
    var filter_platform = getMyVar("filter_platform", "");
    var filter_content = getMyVar("filter_content", "true");
    var filter_score = getMyVar("filter_score", "0,10");
    var custom_local = getMyVar("custom_local", "");
    var custom_type = getMyVar("custom_type", "");
    var custom_year = getMyVar("custom_year", "");
    var filter_rank = getMyVar("filter_rank", "R");

    var locals = ["全部地区", "自定义", "中国大陆", "美国", "日本", "韩国", "英国", "中国香港", "中国台湾", "印度", "泰国", "俄罗斯"];
    for (var i = 0; i < locals.length; i++) {
        var title = locals[i];
        if (title === "自定义") {
            var displayTitle = filter_local === "自定义" ? '自定义:' + (custom_local || '未输入') : title;
            var isSelected = filter_local === "自定义";
            d.push({
                title: isSelected ? '““””<b> <font color=' + color + '>' + displayTitle + ' </font></b>' : displayTitle,
                col_type: 'scroll_button',
                url: $(custom_local, '直接输入具体地区,例如中国大陆').input(() => {
                    if (input.trim() !== "") {
                        putMyVar("custom_local", input.trim());
                        putMyVar("filter_local", "自定义");
                    } else {
                        clearMyVar("filter_local");
                        clearMyVar("custom_local");
                    }
                    refreshPage();
                    return 'hiker://empty';
                })
            });
        } else {
            var isSelected = (filter_local === title) || (filter_local === "" && i === 0);
            d.push({
                title: isSelected ? '““””<b> <font color=' + color + '>' + title + ' </font></b>' : title,
                col_type: 'scroll_button',
                url: $('hiker://empty#noLoading##noRecordHistory#').lazyRule((local) => {
                    if (local === "全部地区") {
                        clearMyVar("filter_local");
                        clearMyVar("custom_local");
                    } else {
                        putMyVar("filter_local", local);
                        clearMyVar("custom_local");
                    }
                    refreshPage();
                    return 'hiker://empty';
                }, locals[i])
            });
        }
    }
    d.push({
        col_type: 'blank_block'
    });

    var types;
    if (category == "电影") {
        types = ["全部类型", "自定义", "剧情", "喜剧", "动作", "爱情", "科幻", "动画", "悬疑", "惊悚", "恐怖", "犯罪", "同性", "音乐", "歌舞", "传记", "历史", "战争", "西部", "奇幻", "冒险", "灾难", "武侠"];
    } else if (category == "剧集") {
        types = ["全部类型", "自定义", "喜剧", "爱情", "悬疑", "武侠", "古装", "家庭", "犯罪", "科幻", "恐怖", "历史", "战争", "动作", "冒险", "传记", "剧情", "奇幻", "惊悚", "灾难", "歌舞", "音乐"];
    } else if (category == "综艺") {
        types = ["全部类型", "自定义", "真人秀", "脱口秀", "音乐", "歌舞"];
    } else if (category == "动漫") {
        types = ["全部类型", "自定义", "热血", "格斗", "恋爱", "校园", "搞笑", "冒险", "科幻", "魔法", "神话", "竞技", "悬疑", "奇幻", "战争", "历史", "励志", "治愈", "机战", "少女", "少年", "亲子", "益智"];
    }

    for (var i = 0; i < types.length; i++) {
        var title = types[i];
        if (title === "自定义") {
            var displayTitle = filter_type === "自定义" ? '自定义:' + (custom_type || '未输入') : title;
            var isSelected = filter_type === "自定义";
            d.push({
                title: isSelected ? '““””<b> <font color=' + color + '>' + displayTitle + ' </font></b>' : displayTitle,
                col_type: 'scroll_button',
                url: $(custom_type, '直接输入具体类型,例如剧情').input(() => {
                    if (input.trim() !== "") {
                        putMyVar("custom_type", input.trim());
                        putMyVar("filter_type", "自定义");
                    } else {
                        clearMyVar("filter_type");
                        clearMyVar("custom_type");
                    }
                    refreshPage();
                    return 'hiker://empty';
                })
            });
        } else {
            var isSelected = (filter_type === title) || (filter_type === "" && i === 0);
            d.push({
                title: isSelected ? '““””<b> <font color=' + color + '>' + title + ' </font></b>' : title,
                col_type: 'scroll_button',
                url: $('hiker://empty#noLoading##noRecordHistory#').lazyRule((type) => {
                    if (type === "全部类型") {
                        clearMyVar("filter_type");
                        clearMyVar("custom_type");
                    } else {
                        putMyVar("filter_type", type);
                        clearMyVar("custom_type");
                    }
                    refreshPage();
                    return 'hiker://empty';
                }, types[i])
            });
        }
    }

    d.push({
        col_type: 'blank_block'
    });

    var years = ["全部年代", "自定义", "2026", "2025", "2024", "2023", "2022", "2021", "2020", "2019", "2020年代", "2010年代", "2000年代", "90年代", "80年代", "70年代", "60年代", "更早"];
    for (var i = 0; i < years.length; i++) {
        var title = years[i];
        if (title === "自定义") {
            var displayTitle = filter_year === "自定义" ? '自定义:' + (custom_year || '未输入') : title;
            var isSelected = filter_year === "自定义";
            d.push({
                title: isSelected ? '““””<b> <font color=' + color + '>' + displayTitle + ' </font></b>' : displayTitle,
                col_type: 'scroll_button',
                url: $(custom_year, '直接输入具体年份,例如2000').input(() => {
                    if (/^\d{4}$/.test(input.trim())) {
                        putMyVar("custom_year", input.trim());
                        putMyVar("filter_year", "自定义");
                    } else {
                        clearMyVar("filter_year");
                        clearMyVar("custom_year");
                    }
                    refreshPage();
                    return 'hiker://empty';
                })
            });
        } else {
            var isSelected = (filter_year === title) || (filter_year === "" && i === 0);
            d.push({
                title: isSelected ? '““””<b> <font color=' + color + '>' + title + ' </font></b>' : title,
                col_type: 'scroll_button',
                url: $('hiker://empty#noLoading##noRecordHistory#').lazyRule((year) => {
                    if (year === "全部年代") {
                        clearMyVar("filter_year");
                        clearMyVar("custom_year");
                    } else {
                        putMyVar("filter_year", year);
                        clearMyVar("custom_year");
                    }
                    refreshPage();
                    return 'hiker://empty';
                }, years[i])
            });
        }
    }
    d.push({
        col_type: 'blank_block'
    });
    if (category != "电影") {
        var platforms = ["全部平台", "腾讯视频", "爱奇艺", "优酷", "芒果TV", "哔哩哔哩", "Netflix", "HBO", "BBC", "NHK"];
        for (var i = 0; i < platforms.length; i++) {
            var title = platforms[i];
            var isSelected = (filter_platform === title) || (filter_platform === "" && i === 0);
            d.push({
                title: isSelected ? '““””<b> <font color=' + color + '>' + title + ' </font></b>' : title,
                col_type: 'scroll_button',
                url: $('hiker://empty#noLoading##noRecordHistory#').lazyRule((platform) => {
                    if (platform === "全部平台") {
                        clearMyVar("filter_platform");
                    } else {
                        putMyVar("filter_platform", platform);
                    }
                    refreshPage();
                    return 'hiker://empty';
                }, platforms[i])
            });
        }
    }
    d.push({
        col_type: 'blank_block'
    });

    var ranks = {
        "默认": "U",
        "热度": "T",
        "时间": "R",
        "评分": "S",
    };
    for (var r in ranks) {
        d.push({
            title: filter_rank === ranks[r] ? '““””<b> <font color=' + color + '>' + r + ' </font></b>' : r,
            col_type: 'scroll_button',
            url: $('hiker://empty#noLoading##noRecordHistory#').lazyRule((rank) => {
                putMyVar("filter_rank", rank);
                refreshPage();
                return 'hiker://empty';
            }, ranks[r])
        });
    }
    var contents = {
        "全部内容": "",
        "仅有片源": "true"
    };
    for (var c in contents) {
        d.push({
            title: filter_content === contents[c] ? '““””<b> <font color=' + color + '>' + c + ' </font></b>' : c,
            col_type: 'scroll_button',
            url: $('hiker://empty#noLoading##noRecordHistory#').lazyRule((val) => {
                putMyVar("filter_content", val);
                refreshPage();
                return 'hiker://empty';
            }, contents[c])
        });
    }

    d.push({
        title: '““””<b> <font color=' + color + '>评分:' + filter_score.replace(',', '-') + ' </font></b>',
        col_type: 'scroll_button',
        url: $(filter_score.replace(',', '-'), '请输入评分(如: 8) 或评分区间(如: 7-9)').input(() => {
            let scoreRange = input.trim();
            if (scoreRange) {
                if (scoreRange.includes('-')) {
                    scoreRange = scoreRange.replace('-', ',');
                } else {
                    scoreRange = scoreRange + ',10';
                }
                putMyVar("filter_score", scoreRange);
            } else {
                putMyVar("filter_score", "0,10");
            }
            refreshPage();
            return 'hiker://empty';
        })
    });

    d.push({
        col_type: 'line'
    });
}

function isAnimation(item) {
    var animationKeywords = ['动画', 'anime', '卡通', '动漫', '儿童', '综艺', '真人秀', "脱口秀"];

    function containsAnimationKeyword(text) {
        if (typeof text !== 'string') {
            return false;
        }
        for (var i = 0; i < animationKeywords.length; i++) {
            if (text.indexOf(animationKeywords[i]) !== -1) {
                return true;
            }
        }
        return false;
    }
    if (item.title && containsAnimationKeyword(item.title)) {
        return true;
    }
    if (item.genres && Array.isArray(item.genres)) {
        for (var i = 0; i < item.genres.length; i++) {
            if (containsAnimationKeyword(item.genres[i])) {
                return true;
            }
        }
    }
    if (item.card_subtitle && containsAnimationKeyword(item.card_subtitle)) {
        return true;
    }
    if (item.subtype && containsAnimationKeyword(item.subtype)) {
        return true;
    }
    if (item.tags && Array.isArray(item.tags)) {
        for (var i = 0; i < item.tags.length; i++) {
            if (containsAnimationKeyword(item.tags[i])) {
                return true;
            }
        }
    }
    if (item.categories && Array.isArray(item.categories)) {
        for (var i = 0; i < item.categories.length; i++) {
            if (containsAnimationKeyword(item.categories[i])) {
                return true;
            }
        }
    }
    return false;
}

function GetDatas(keyword) {
    var page = parseInt(MY_PAGE) || 1;
    var result = [];
    var filter_local = getMyVar("filter_local", "");
    var filter_type = getMyVar("filter_type", "");
    var filter_year = getMyVar("filter_year", "");
    var filter_platform = getMyVar("filter_platform", "");
    var filter_content = getMyVar("filter_content", "true");
    var filter_score = getMyVar("filter_score", "0,10");
    var custom_local = getMyVar("custom_local", "");
    var custom_type = getMyVar("custom_type", "");
    var custom_year = getMyVar("custom_year", "");
    var filter_rank = getMyVar("filter_rank", "R");
    var actual_local = filter_local === "自定义" ? custom_local : filter_local;
    var actual_type = filter_type === "自定义" ? custom_type : filter_type;
    var actual_year = filter_year === "自定义" ? custom_year : filter_year;

    var url, dataKey;

    if (keyword === "剧集") {
        var tags = [actual_type, actual_local, actual_year, filter_platform].filter(t => t).join(',');
        url = "https://frodo.douban.com/api/v2/tv/recommend?start=" + ((page - 1) * 20) + "&count=20&tags=" + encodeURIComponent(tags) + "&sort=" + filter_rank + (filter_content ? "&playable=" + filter_content : "") + "&score_range=" + filter_score;
        dataKey = "items";
    } else if (keyword === "电影") {
        var q = [actual_type, actual_local, actual_year, filter_platform].filter(t => t).join(',');
        url = "https://frodo.douban.com/api/v2/movie/recommend?start=" + ((page - 1) * 20) + "&count=20&tags=" + encodeURIComponent(q) + "&sort=" + filter_rank + (filter_content ? "&playable=" + filter_content : "") + "&score_range=" + filter_score;
        dataKey = "items";
    } else if (keyword === "综艺") {
        var tags = ["综艺", actual_type, actual_local, actual_year, filter_platform].filter(t => t).join(',');
        url = "https://frodo.douban.com/api/v2/tv/recommend?start=" + ((page - 1) * 20) + "&count=20&tags=" + encodeURIComponent(tags) + "&sort=" + filter_rank + (filter_content ? "&playable=" + filter_content : "") + "&score_range=" + filter_score;
        dataKey = "items";
    } else if (keyword === "动漫") {
        var tags = ["动漫", actual_type, actual_local, actual_year, filter_platform].filter(t => t).join(',');
        url = "https://frodo.douban.com/api/v2/tv/recommend?start=" + ((page - 1) * 20) + "&count=20&tags=" + encodeURIComponent(tags) + "&sort=" + filter_rank + (filter_content ? "&playable=" + filter_content : "") + "&score_range=" + filter_score;
        dataKey = "items";
    }

    try {
        let cacheKey = 'home_' + keyword + '_' + page + '_' + actual_local + '_' + actual_type + '_' + actual_year + '_' + filter_platform + '_' + filter_score + '_' + filter_rank + '_' + filter_content;
        let response = cachedFetch(cacheKey, url, () => getDoubanRes(url));
        let get_datas = response[dataKey] || [];

        if (!get_datas || get_datas.length === 0) {
            log('豆瓣API返回无数据, URL: ' + url);
            return [];
        }
        if (keyword === "剧集") {
            get_datas = get_datas.filter(function(item) {
                return !isAnimation(item);
            });
            //log('过滤动画儿童内容后剩余: ' + get_datas.length + ' 条数据');
        }

        get_datas.map(function(item, i) {
            result.push({
                title: item.title,
                img: (item.pic ? item.pic.large : item.cover_url) + '@Referer=https://m.douban.com/',
                id: item.id,
                col_type: 'movie_3_marquee',
                source: item.rating ? '豆瓣评分 : ' + item.rating.value : '暂无评分',
                doubanId: item.id,
                target_type: item.type || item.subtype,
                year: item.year
            });
        });
    } catch (e) {
        log("豆瓣API请求失败: " + e.message);
        toast(String(e.message || '豆瓣API请求失败'));
        return [];
    }

    return result;
}

function fetchData() {
    try {
        var data = GetDatas(fyclass);
        if (data && data.length > 0) {
            data.forEach(function(item) {
                d.push({
                    title: item.title,
                    content: item.title,
                    col_type: item.col_type,
                    pic_url: item.img,
                    url: 'hiker://page/douban_Detail?rule=&simple=true&doubanId=' + item.id,
                    desc: item.source,
                    extra: {
                        id: item.doubanId,
                        title: item.title,
                        target_type: item.target_type
                    }
                });
            });
        } else {
            d.push({
                title: '没有了，真的一点都没有了!',
                url: "hiker://empty",
                col_type: "text_center_1",
                extra: {
                    onClick: "refreshPage(true)"
                }
            });
        }
    } catch (e) {
        log("请求出错: " + e.message);
        d.push({
            title: '请求失败，请稍候重试',
            url: "hiker://empty",
            col_type: "text_center_1",
            extra: {
                onClick: "refreshPage(true)"
            }
        });
    }
}

var tips_title = titleMap[fyclass] || "#热门剧集 | episode | Form_douban";
if (MY_PAGE === 1) {
    for (var i = 0; i < navButtons.length; i++) {
        var btn = navButtons[i];
        var isActive = btn.title === fyclass;
        d.push({
            title: isActive ? '\u2018\u2018\u2019\u2019<b><font color="#FF5D50">' + btn.title + '</font></b>' : btn.title,
            pic_url: "https://cdn.jsdelivr.net/gh/JMWpower/qdzhiyuan@main/icons/" + btn.icon,
            col_type: "icon_5",
            url: $("#noLoading##noRecordHistory#").lazyRule(function(param) {
                try {
                    var fn = $.require('function');
                    var cfg = fn.getXjBase();
                    cfg.fyclass = param;
                    fn.saveXjBase(cfg);
                } catch (e) {}
                putMyVar("fypage", "1");
                clearMyVar("filter_local");
                clearMyVar("filter_type");
                clearMyVar("filter_year");
                clearMyVar("filter_platform");
                //clearMyVar("filter_content");
                clearMyVar("filter_score");
                clearMyVar("custom_local");
                clearMyVar("custom_type");
                clearMyVar("custom_year");
                clearMyVar("filter_rank");
                log("切换源: " + param);
                refreshPage(true);
                return "hiker://empty";
            }, btn.title)
        });
    }
    d.push({
        title: "选映",
        url: "hiker://page/ruleHome#noRecordHistory##noHistory#",
        pic_url: "https://cdn.jsdelivr.net/gh/JMWpower/qdzhiyuan@main/icons/%E9%80%89%E6%98%A0.png",
        col_type: "icon_5"
    });
    d.push({
        url: $.toString(function() {
            var panJump = null;
            try { panJump = $.require('function').openPanInput(input); } catch (e) {}
            if (panJump) return panJump;
            return $('hiker://empty/search?page=fypage&word=' + encodeURIComponent(input) + '#noRecordHistory#').rule(function() {
                var d = [];
                var word = getParam('word');
                if (/%[0-9A-Fa-f]{2}/.test(word)) { try { word = decodeURIComponent(word); } catch (eDec) {} }
                try {
                    var fn = $.require('function');
                    var url = 'https://frodo.douban.com/api/v2/search/subjects?q=' + encodeURIComponent(word) + '&type=movie&start=' + (((parseInt(getParam('page')) || 1) - 1) * 20);
                    var json = fn.getDoubanRes(url);
                    var list = ((((json || {}).subjects) || {}).items) || [];
                    list.forEach(function(item) {
                        if (item && (item.target_type == 'tv' || item.target_type == 'movie') && item.target) {
                            var rating = item.target.rating;
                            d.push({
                                title: item.target.title,
                                content: rating == null ? (item.target.null_rating_reason + '\n' + item.target.card_subtitle) : (fn.star(rating.value) + '\n' + item.target.card_subtitle),
                                desc: '上映年份：' + item.target.year,
                                pic_url: item.target.cover_url + '@Referer=https://m.douban.com/',
                                url: 'hiker://page/douban_Detail#noHistory##immersiveTheme#',
                                col_type: 'movie_1_vertical_pic',
                                extra: {
                                    id: item.target.id,
                                    title: item.target.title,
                                    target_type: item.target_type
                                }
                            });
                        }
                    });
                    if (d.length === 0) {
                        var raw = '';
                        try { raw = JSON.stringify(json); } catch (eStr) {}
                        d.push({ title: '未找到[' + word + '] 响应:' + (raw || '空').substring(0, 100), col_type: 'text_center_1' });
                    }
                } catch (e) {
                    d.push({ title: '搜索失败: ' + ((e && e.message) || e), col_type: 'text_center_1' });
                }
                setResult(d);
            })
        }),
        col_type: 'input',
        title: "🔍"
    });
    d.push({
        url: "hiker://empty",
        col_type: "line"
    });
    d.push({ title: '🔥 热映', col_type: 'text_4', url: 'hiker://page/nowplaying#noHistory##noRecordHistory#' });
    d.push({ title: '⭐ 收藏', col_type: 'text_4', url: 'hiker://collection?rule=星集Media#noRecordHistory#' });
    d.push({ title: '🕘 历史', col_type: 'text_4', url: 'hiker://history?rule=星集Media#noRecordHistory#' });
    d.push({ title: '⚙️ 设置', col_type: 'text_4', url: 'hiker://page/parse#noHistory##noRecordHistory##noPre#' });
    d.push({ col_type: 'line' });
    d.push({
        url: "hiker://empty",
        pic_url: "hiker://images/icon3",
        col_type: "avatar",
        title: tips_title
    });
    addFilterOptions(d, fyclass);
}

fetchData();
setResult(d);
}
} else if (MY_PAGE === 1) {
    let d = [];
    if (getAppVersion() < 5600) {
        setResult([{
            col_type: "text_center_1",
            url:"hiker://empty",
            title: "当前海阔版本过低，不支持新版本" + MY_RULE.title,
            desc: "请获取最新版本(>=8.83)或回退到老版本小程序"
        }])
    }
    try {
        var _fn = $.require('function');
        var _hmCfg = _fn.getXjBase();
        if (!_hmCfg.xj_home_mode) {
            _hmCfg.xj_home_mode = 'douban';
            _fn.saveXjBase(_hmCfg);
        }
    } catch (e) {}
    let content = `<small>1. 本小程序是一个空壳小程序，无任何内置资源。<br>2. 本小程序开源完全免费，付费购买均为骗局，请勿上当。<br>3. 本小程序免费无偿使用，不接受任何指责和无理要求。<br>4. 本小程序开发初衷源于兴趣爱好，乐于分享，禁止贩卖。<br>5. 本小程序仅用于个人学习研究，请于导入24小时内删除！。<br>6. 本工具仅查看豆瓣&TMDB影视数据用于影视内容筛选，无内置直接播放功能。<br><font color="#51CF66">本小程序为青豆剧场新版,更名为星集Media,旧版青豆剧场不再维护更新。</font><br><font color="#1E90FF">芝麻开门: 星集MediaYYDS</font><br><font color="#FF0000">用户自行导入的任意外部内容本小程序均无法保证其安全性,请自行甄别,安装本小程序即代表您已阅读并同意以上内容,所有带来的后果由用户自行承担</font></small>`;

    d.push({
        title: "““””<strong>星集Media - 使用前须知</strong>",
        desc: "““星集Media - author[不知道叫啥好]””",
        col_type: "text_center_1",
        url: "hiker://empty",
        extra: {
            lineVisible: false
        }
    });

    d.push({
        title: content,
        "col_type": "rich_text"
    }, {
        title: "当前版本：" + MY_RULE.version,
        col_type: "text_1",
        url: "hiker://empty",
        extra: {
            titleVisible: false
        }
    }, {
        title: "📋 查看更新日志",
        col_type: "text_center_1",
        url: $("#noLoading#").lazyRule(() => {
            try {
                var rule = JSON.parse(fetch("hiker://page/updateLog", {})).rule;
                eval(rule);
            } catch (e) {
                return "toast://更新日志加载失败: " + e.message;
            }
            return "hiker://empty";
        }),
    }, {col_type: 'big_blank_block'}, {
        title: "““我同意以上要求””",
        url: $('', '请输入口令').input(function() {
            if (input.trim() === '星集MediaYYDS') {
                setItem("xj_firstopen", String(MY_RULE.version));
                refreshPage();
                return "toast://感谢理解,请勿相信任何广告信息";
            }
            return "toast://口令错误";
        }),
        col_type: "text_center_1"
    }, {col_type: 'big_big_blank_block'});

    setResult(d);
}
