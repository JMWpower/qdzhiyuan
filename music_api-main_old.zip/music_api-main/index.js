#!/usr/bin/env node

/**
 * Music Node Server - 启动入口
 * 此文件用于从项目根目录启动服务
 */

import { fileURLToPath } from 'url'
import { dirname, join } from 'path'
import { createRequire } from 'module'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

const require = createRequire(import.meta.url)

// 引入并启动服务
const app = (await import('./src/app.js')).default
const { setShutdownCallback } = await import('./src/app.js')
const config = (await import('./config.js')).default
const userApi = require('./src/modules/userApi.cjs')

import http from 'http'
import fs from 'fs'
import path from 'path'
// 全局错误处理，防止未捕获的 Promise 拒绝导致进程崩溃
process.on('unhandledRejection', (reason, promise) => {
  console.error('[Process] 未处理的 Promise 拒绝:', reason)
  // 不退出进程，继续运行
})

process.on('uncaughtException', (error) => {
  console.error('[Process] 未捕获的异常:', error.message)
  // 不退出进程，继续运行
})

global.lx = {
  config: {},
}

const startServer = async () => {
  const port = config.port
  const host = config.host

  const scriptDir = path.join(__dirname, 'Script')
  if (!fs.existsSync(scriptDir)) {
    fs.mkdirSync(scriptDir, { recursive: true })
  }

  try {
    await userApi.initUserApis()
  } catch (error) {
    console.error('[Init] 初始化自定义规则脚本失败:', error.message)
  }

const server = http.createServer(app)

  server.listen(port, host, () => {
    console.log(`[Server] 服务已启动: http://${host}:${port}`)
    console.log(`[Server] 规则脚本管理: http://${host}:${port}/Script.html`)
    console.log()
  })

  const shutdown = (signal) => {
    console.log(`\n[Server] 收到 ${signal} 信号，正在关闭服务...`)
    server.close(() => {
      console.log('[Server] HTTP 服务已关闭')
    })
    setTimeout(() => {
      console.log('[Server] 强制退出')
      process.exit(0)
    }, 5000)
  }

  setShutdownCallback(() => {
    console.log('\n[Server] 收到 API_SHUTDOWN 信号，正在关闭服务...')
    server.close(() => {
      console.log('[Server] HTTP 服务已关闭')
    })
  })

  process.on('SIGINT', () => shutdown('SIGINT'))
  process.on('SIGTERM', () => shutdown('SIGTERM'))
}

startServer().catch(err => {
  console.error('❌ 启动失败:', err)
  process.exit(1)
})
