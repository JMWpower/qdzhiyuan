export default {
  port: process.env.PORT || 5566,
  host: process.env.HOST || '0.0.0.0',
  proxy: {
    enabled: false,
    address: '',
  },
}
