import needle from 'needle'
import { debugRequest } from './env.js'
import { requestMsg } from './message.js'
import { bHh } from './modules/musicSdk/options.js'
import { deflateRaw } from 'zlib'
import * as tunnel from 'tunnel'

const httpsRxp = /^https:/

const getRequestAgent = async url => {
  const config = global.lx?.config || {}
  const proxyEnabled = config['proxy.all.enabled']
  const proxyAddress = config['proxy.all.address']

  if (proxyEnabled && proxyAddress) {
    try {
      const proxyUrl = new URL(proxyAddress)
      if (proxyUrl.protocol === 'http:' || proxyUrl.protocol === 'https:') {
        const isHttps = httpsRxp.test(url)
        const tunnelOptions = {
          proxy: {
            host: proxyUrl.hostname,
            port: proxyUrl.port,
            proxyAuth: proxyUrl.username ? `${proxyUrl.username}:${proxyUrl.password}` : undefined
          }
        }
        return (isHttps ? tunnel.httpsOverHttp : tunnel.httpOverHttp)(tunnelOptions)
      } else if (proxyUrl.protocol.startsWith('socks')) {
        const { SocksProxyAgent } = await import('socks-proxy-agent')
        return new SocksProxyAgent(proxyAddress)
      }
    } catch (e) { }
  }

  if (process.env.HTTPS_PROXY) {
    try {
      const proxyUrl = new URL(process.env.HTTPS_PROXY)
      const tunnelOptions = {
        proxy: {
          host: proxyUrl.hostname,
          port: proxyUrl.port,
          proxyAuth: proxyUrl.username ? `${proxyUrl.username}:${proxyUrl.password}` : undefined
        }
      }
      return (httpsRxp.test(url) ? tunnel.httpsOverHttp : tunnel.httpOverHttp)(tunnelOptions)
    } catch (e) { }
  }

  return undefined
}

const request = (url, options, callback) => {
  let data
  if (options.body) {
    data = options.body
  } else if (options.form) {
    data = options.form
    options.json = false
  } else if (options.formData) {
    data = options.formData
    options.json = false
  }
  options.response_timeout = options.timeout

  return needle.request(options.method || 'get', url, data, options, (err, resp, body) => {
    if (!err) {
      body = resp.body = resp.raw.toString()
      try {
        resp.body = JSON.parse(resp.body)
      } catch (_) { }
      body = resp.body
    }
    callback(err, resp, body)
  }).request
}

const defaultHeaders = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
}

const buildHttpPromise = (url, options) => {
  let obj = {
    isCancelled: false,
    cancelHttp: () => {
      if (!obj.requestObj) return obj.isCancelled = true
      cancelHttp(obj.requestObj)
      obj.requestObj = null
      obj.promise = obj.cancelHttp = null
      if (obj.cancelFn) obj.cancelFn(new Error(requestMsg.cancelRequest))
      obj.cancelFn = null
    },
  }
  obj.promise = new Promise((resolve, reject) => {
    obj.cancelFn = reject
    debugRequest && console.log(`\n---send request------${url}------------`)
    fetchData(url, options.method, options, (err, resp, body) => {
      debugRequest && console.log(`\n---response------${url}------------`)
      debugRequest && console.log(body)
      obj.requestObj = null
      obj.cancelFn = null
      if (err) return reject(err)
      resolve(resp)
    }).then(ro => {
      obj.requestObj = ro
      if (obj.isCancelled) obj.cancelHttp()
    })
  })
  return obj
}

export const httpFetch = (url, options = { method: 'get' }) => {
  const requestObj = buildHttpPromise(url, options)
  requestObj.promise = requestObj.promise.catch(err => {
    if (err.message === 'socket hang up') {
      return Promise.reject(new Error(requestMsg.unachievable))
    }
    switch (err.code) {
      case 'ETIMEDOUT':
      case 'ESOCKETTIMEDOUT':
        return Promise.reject(new Error(requestMsg.timeout))
      case 'ENOTFOUND':
        return Promise.reject(new Error(requestMsg.notConnectNetwork))
      default:
        return Promise.reject(err)
    }
  })
  return requestObj
}

export const cancelHttp = requestObj => {
  if (!requestObj) return
  if (!requestObj.abort) return
  requestObj.abort()
}

export const httpGet = (url, options, callback) => {
  if (typeof options === 'function') {
    callback = options
    options = {}
  }
  if (options.method == null) options.method = 'get'
  debugRequest && console.log(`\n---send request-------${url}------------`)
  return fetchData(url, 'get', options, function (err, resp, body) {
    debugRequest && console.log(`\n---response------${url}------------`)
    if (err) {
      debugRequest && console.log(JSON.stringify(err))
    }
    callback(err, resp, body)
  })
}

export const httpPost = (url, data, options, callback) => {
  if (typeof options === 'function') {
    callback = options
    options = {}
  }
  options.data = data
  debugRequest && console.log(`\n---send request-------${url}------------`)
  return fetchData(url, 'post', options, function (err, resp, body) {
    debugRequest && console.log(`\n---response------${url}------------`)
    if (err) {
      debugRequest && console.log(JSON.stringify(err))
    }
    callback(err, resp, body)
  })
}

export const http_jsonp = (url, options, callback) => {
  if (typeof options === 'function') {
    callback = options
    options = {}
  }
  let jsonpCallback = 'jsonpCallback'
  if (url.indexOf('?') < 0) url += '?'
  url += `&${options.jsonpCallback}=${jsonpCallback}`
  options.format = 'script'
  debugRequest && console.log(`\n---send request-------${url}------------`)
  return fetchData(url, 'get', options, function (err, resp, body) {
    debugRequest && console.log(`\n---response------${url}------------`)
    if (err) {
      debugRequest && console.log(JSON.stringify(err))
    } else {
      try {
        body = JSON.parse(body.replace(new RegExp(`^${jsonpCallback}\\(({.*})\\)$`), '$1'))
      } catch (e) { }
    }
    callback(err, resp, body)
  })
}

const handleDeflateRaw = data => new Promise((resolve, reject) => {
  deflateRaw(data, (err, buf) => {
    if (err) return reject(err)
    resolve(buf)
  })
})

const regx = /(?:\d\w)+/g

const fetchData = async (url, method, {
  headers = {},
  format = 'json',
  timeout = 15000,
  ...options
}, callback) => {
  headers = Object.assign({}, headers)
  if (headers[bHh]) {
    const path = url.replace(/^https?:\/\/[\w.:]+\//, '/')
    let s = Buffer.from(bHh, 'hex').toString()
    s = s.replace(s.substr(-1), '')
    s = Buffer.from(s, 'base64').toString()
    const v1 = '2050201'
    const v2 = '10'
    let v = v1.split('-')[0].split('.').map(n => n.length < 3 ? n.padStart(3, '0') : n).join('')
    headers[s] = !s || `${(await handleDeflateRaw(Buffer.from(JSON.stringify(`${path}${v}`.match(regx), null, 1).concat(v)).toString('base64'))).toString('hex')}&${parseInt(v)}${v2}`
    delete headers[bHh]
  }
  return request(url, {
    ...options,
    method,
    headers: Object.assign({}, defaultHeaders, headers),
    timeout,
    agent: await getRequestAgent(url),
    json: format === 'json',
    rejectUnauthorized: false,
  }, (err, resp, body) => {
    if (err) return callback(err, null)
    callback(null, resp, body)
  })
}

export const checkUrl = (url, options = {}) => {
  return new Promise((resolve, reject) => {
    fetchData(url, 'head', options, (err, resp) => {
      if (err) return reject(err)
      if (resp.statusCode === 200) {
        resolve()
      } else {
        reject(new Error(resp.statusCode))
      }
    })
  })
}
