import express from 'express'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const router = express.Router()

const configPath = path.join(__dirname, '..', 'config.json')

const defaultConfig = {
  quality: '320k',
  qualities: [
    { value: '24bit', label: '24bit 超高清' },
    { value: 'flac', label: 'FLAC 无损' },
    { value: '320k', label: '320kbps 高品' },
    { value: '192k', label: '192kbps 较高' },
    { value: '128k', label: '128kbps 标准' },
  ],
}

function readConfig() {
  try {
    if (fs.existsSync(configPath)) {
      const data = JSON.parse(fs.readFileSync(configPath, 'utf-8'))
      return { ...defaultConfig, ...data }
    }
  } catch (e) {
    console.error('[ConfigAPI] 读取配置失败:', e.message)
  }
  return { ...defaultConfig }
}

function writeConfig(config) {
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf-8')
}

router.get('/', (req, res) => {
  res.json({ code: 200, data: readConfig() })
})

router.post('/', (req, res) => {
  try {
    const config = readConfig()
    const { quality } = req.body
    if (quality) config.quality = quality
    writeConfig(config)
    res.json({ code: 200, data: config })
  } catch (error) {
    console.error('[ConfigAPI] 保存配置失败:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

export default router