import express from 'express'
import * as sourceHandlers from '../customSourceHandlers.js'
import { createRequire } from 'module'

const require = createRequire(import.meta.url)
const userApi = require('../modules/userApi.cjs')

const router = express.Router()

router.post('/import-url', async (req, res) => {
  try {
    const { url } = req.body
    if (!url) return res.status(400).json({ error: '缺少 url 参数' })
    console.log(`[SourceAPI] import-url: fetching ${url}`)
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
      signal: AbortSignal.timeout(30000),
    })
    if (!response.ok) throw new Error(`HTTP ${response.status} ${response.statusText}`)
    const content = await response.text()
    if (!content || content.length < 10) {
      return res.status(400).json({ error: '获取到的脚本内容为空或无效' })
    }
    res.json({ code: 200, data: { url, content } })
  } catch (error) {
    console.error('[SourceAPI] import-url error:', error.message)
    res.status(500).json({ code: 500, error: `获取远程脚本失败: ${error.message}` })
  }
})

router.get('/list', async (req, res) => {
  try {
    const sources = await sourceHandlers.listSources()
    res.json({ code: 200, data: sources })
  } catch (error) {
    console.error('[SourceAPI] list error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

router.get('/script', async (req, res) => {
  try {
    const { id } = req.query
    if (!id) return res.status(400).json({ error: '缺少 id 参数' })
    const script = await sourceHandlers.getSourceScript(id)
    res.type('text/javascript').send(script)
  } catch (error) {
    console.error('[SourceAPI] get script error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

router.post('/add', async (req, res) => {
  try {
    const { id, script, name, description, enabled, allowUnsafeVM } = req.body
    if (!id || !script) return res.status(400).json({ error: '缺少 id 或 script 参数' })
    const result = await sourceHandlers.addSource(id, script, { name, description, enabled, allowUnsafeVM })
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[SourceAPI] add error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

router.put('/update', async (req, res) => {
  try {
    const { id, script, name, description, enabled, allowUnsafeVM } = req.body
    if (!id) return res.status(400).json({ error: '缺少 id 参数' })
    const result = await sourceHandlers.updateSource(id, { script, name, description, enabled, allowUnsafeVM })
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[SourceAPI] update error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

router.delete('/delete', async (req, res) => {
  try {
    const { id } = req.body
    if (!id) return res.status(400).json({ error: '缺少 id 参数' })
    const result = await sourceHandlers.deleteSource(id)
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[SourceAPI] delete error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

router.post('/toggle', async (req, res) => {
  try {
    const { id, enabled } = req.body
    if (!id || enabled === undefined) return res.status(400).json({ error: '缺少 id 或 enabled 参数' })
    const result = await sourceHandlers.toggleSource(id, enabled)
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[SourceAPI] toggle error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

router.post('/toggle-platform', async (req, res) => {
  try {
    const { id, platform, enabled } = req.body
    if (!id || !platform || enabled === undefined) return res.status(400).json({ error: '缺少 id、platform 或 enabled 参数' })
    const result = await sourceHandlers.toggleSourcePlatform(id, platform, enabled)
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[SourceAPI] toggle-platform error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

router.post('/reload', async (req, res) => {
  try {
    const result = await sourceHandlers.reloadSources()
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[SourceAPI] reload error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

router.get('/status', async (req, res) => {
  try {
    const result = await sourceHandlers.getSourceStatus()
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[SourceAPI] status error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

router.get('/loaded', (req, res) => {
  try {
    const loadedApis = userApi.getLoadedApis()
    res.json({ code: 200, data: loadedApis })
  } catch (error) {
    console.error('[SourceAPI] loaded error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

router.post('/reorder', async (req, res) => {
  try {
    const { ids } = req.body
    if (!Array.isArray(ids) || ids.length === 0) return res.status(400).json({ error: '缺少 ids 数组参数' })
    const result = await sourceHandlers.reorderSources(ids)
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[SourceAPI] reorder error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

router.post('/test', async (req, res) => {
  try {
    const { id, source, songmid, quality = '128k' } = req.body
    if (!source || !songmid) return res.status(400).json({ error: '缺少 source 或 songmid 参数' })

    const songInfo = { songmid, source }
    const result = await userApi.callUserApiGetMusicUrl(source, songInfo, quality)
    res.json({ code: 200, data: result })
  } catch (error) {
    console.error('[SourceAPI] test error:', error.message)
    res.status(500).json({ code: 500, error: error.message })
  }
})

export default router
