import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { createRequire } from 'module'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const require = createRequire(import.meta.url)
const userApi = require('./modules/userApi.cjs')

const getScriptRoot = () => {
  return path.join(__dirname, '..', 'Script')
}

function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true })
  }
}

function getMetaPath() {
  return path.join(getScriptRoot(), 'sources.json')
}

function readSourcesMeta() {
  const metaPath = getMetaPath()
  if (!fs.existsSync(metaPath)) return []
  try {
    return JSON.parse(fs.readFileSync(metaPath, 'utf-8'))
  } catch (e) {
    return []
  }
}

function writeSourcesMeta(sources) {
  const metaPath = getMetaPath()
  ensureDir(getScriptRoot())
  fs.writeFileSync(metaPath, JSON.stringify(sources, null, 2))
}

export async function listSources() {
  const sources = readSourcesMeta()
  return sources.map(s => {
    const apiStatus = userApi.getApiStatus(s.id) || { status: 'unknown' }
    if (apiStatus.status === 'unknown' && s._initFailed) {
      apiStatus.status = 'failed'
      apiStatus.error = s._initError || '初始化失败'
    }
    return {
      id: s.id,
      name: s.name,
      description: s.description || '',
      version: s.version || 1,
      author: s.author || '',
      homepage: s.homepage || '',
      enabled: s.enabled,
      allowUnsafeVM: s.allowUnsafeVM || false,
      supportedSources: s.supportedSources || [],
      enabledSources: s.enabledSources || s.supportedSources || [],
      status: apiStatus,
      isMusicFree: s.isMusicFree || false,
    }
  })
}

export async function reorderSources(ids) {
  const sources = readSourcesMeta()
  const sourceMap = new Map(sources.map(s => [s.id, s]))
  const reordered = []
  for (const id of ids) {
    const s = sourceMap.get(id)
    if (s) { reordered.push(s); sourceMap.delete(id) }
  }
  for (const s of sourceMap.values()) reordered.push(s)
  writeSourcesMeta(reordered)
  return { count: reordered.length }
}

export async function getSourceScript(sourceId) {
  const scriptRoot = getScriptRoot()
  let scriptPath = path.join(scriptRoot, sourceId)
  if (!fs.existsSync(scriptPath) && fs.existsSync(scriptPath + '.js')) {
    scriptPath = scriptPath + '.js'
  }
  if (!fs.existsSync(scriptPath)) {
    throw new Error(`源脚本不存在: ${sourceId}`)
  }
  return fs.readFileSync(scriptPath, 'utf-8')
}

export async function addSource(sourceId, script, options = {}) {
  const scriptRoot = getScriptRoot()
  ensureDir(scriptRoot)
  const scriptPath = path.join(scriptRoot, sourceId + '.js')
  const metadata = userApi.extractMetadata(script)

  fs.writeFileSync(scriptPath, script, 'utf-8')

  const sources = readSourcesMeta()
  const existingIndex = sources.findIndex(s => s.id === sourceId)
  const sourceEntry = {
    id: sourceId,
    name: metadata.name || options.name || sourceId,
    description: metadata.description || options.description || '',
    version: metadata.version || options.version || 1,
    author: metadata.author || options.author || '',
    homepage: metadata.homepage || options.homepage || '',
    enabled: options.enabled !== undefined ? options.enabled : true,
    allowUnsafeVM: options.allowUnsafeVM || false,
    supportedSources: [],
    isMusicFree: userApi.isMusicFreePlugin(script),
  }

  if (existingIndex >= 0) {
    sources[existingIndex] = sourceEntry
  } else {
    sources.push(sourceEntry)
  }

  writeSourcesMeta(sources)

  if (sourceEntry.enabled) {
    try {
      const result = await userApi.loadUserApi({
        id: sourceId,
        name: sourceEntry.name,
        description: sourceEntry.description,
        version: sourceEntry.version,
        author: sourceEntry.author,
        homepage: sourceEntry.homepage,
        script,
        sources: {},
        enabled: true,
        allowUnsafeVM: sourceEntry.allowUnsafeVM,
      }, true)
      if (result.success && result.apiInstance) {
        const runtimeSources = Object.keys(result.apiInstance.info.sources).sort()
        if (runtimeSources.length > 0) {
          sourceEntry.supportedSources = runtimeSources
          sourceEntry.enabledSources = sourceEntry.enabledSources && sourceEntry.enabledSources.length > 0
            ? sourceEntry.enabledSources.filter(s => runtimeSources.includes(s))
            : [...runtimeSources]
          const updatedSources = readSourcesMeta()
          const idx = updatedSources.findIndex(s => s.id === sourceId)
          if (idx >= 0) {
            updatedSources[idx].supportedSources = runtimeSources
            updatedSources[idx].enabledSources = sourceEntry.enabledSources
            writeSourcesMeta(updatedSources)
          }
        }
      } else {
        if (fs.existsSync(scriptPath)) {
          fs.unlinkSync(scriptPath)
        }
        const updatedSources = readSourcesMeta()
        const idx = updatedSources.findIndex(s => s.id === sourceId)
        if (idx >= 0) {
          updatedSources.splice(idx, 1)
          writeSourcesMeta(updatedSources)
        }
        throw new Error(`此规则脚本不可用：${result.error || '初始化失败'}`)
      }
    } catch (e) {
      console.error(`[SourceHandler] 加载源 ${sourceId} 失败:`, e.message)
      if (fs.existsSync(scriptPath)) {
        fs.unlinkSync(scriptPath)
      }
      const updatedSources = readSourcesMeta()
      const idx = updatedSources.findIndex(s => s.id === sourceId)
      if (idx >= 0) {
        updatedSources.splice(idx, 1)
        writeSourcesMeta(updatedSources)
      }
      throw new Error(`此规则脚本不可用：${e.message}`)
    }
  }

  return sourceEntry
}

export async function updateSource(sourceId, updates) {
  const sources = readSourcesMeta()
  const index = sources.findIndex(s => s.id === sourceId)
  if (index < 0) throw new Error(`源不存在: ${sourceId}`)

  if (updates.script !== undefined) {
    const scriptRoot = getScriptRoot()
    let scriptPath = path.join(scriptRoot, sourceId + '.js')
    if (!fs.existsSync(scriptPath)) scriptPath = path.join(scriptRoot, sourceId)
    fs.writeFileSync(scriptPath, updates.script, 'utf-8')
    const metadata = userApi.extractMetadata(updates.script)
    if (metadata.name) sources[index].name = metadata.name
    if (metadata.description) sources[index].description = metadata.description
    if (metadata.version) sources[index].version = metadata.version
    if (metadata.author) sources[index].author = metadata.author
  }

  if (updates.enabled !== undefined) sources[index].enabled = updates.enabled
  if (updates.allowUnsafeVM !== undefined) sources[index].allowUnsafeVM = updates.allowUnsafeVM
  if (updates.name !== undefined) sources[index].name = updates.name
  if (updates.description !== undefined) sources[index].description = updates.description
  if (updates.enabledSources !== undefined) sources[index].enabledSources = updates.enabledSources

  writeSourcesMeta(sources)

  if (updates.enabled === true || updates.script !== undefined) {
    const scriptRoot = getScriptRoot()
    let scriptPath = path.join(scriptRoot, sourceId + '.js')
    if (!fs.existsSync(scriptPath)) scriptPath = path.join(scriptRoot, sourceId)
    if (fs.existsSync(scriptPath)) {
        const script = fs.readFileSync(scriptPath, 'utf-8')
        try {
          await userApi.loadUserApi({
            id: sourceId,
            name: sources[index].name,
            description: sources[index].description,
            version: sources[index].version,
            author: sources[index].author,
            script,
            sources: {},
            enabled: sources[index].enabled,
            allowUnsafeVM: sources[index].allowUnsafeVM,
          }, true)
        } catch (e) {
        console.error(`[SourceHandler] 重新加载源 ${sourceId} 失败:`, e.message)
      }
    }
  }

  return sources[index]
}

export async function deleteSource(sourceId) {
  const sources = readSourcesMeta()
  const filtered = sources.filter(s => s.id !== sourceId)

  if (filtered.length === sources.length) {
    throw new Error(`源不存在: ${sourceId}`)
  }

  writeSourcesMeta(filtered)

  const scriptRoot = getScriptRoot()
  let scriptPath = path.join(scriptRoot, sourceId + '.js')
  if (!fs.existsSync(scriptPath)) scriptPath = path.join(scriptRoot, sourceId)
  if (fs.existsSync(scriptPath)) {
    fs.unlinkSync(scriptPath)
  }

  return { success: true, id: sourceId }
}

export async function toggleSource(sourceId, enabled) {
  return updateSource(sourceId, { enabled })
}

export async function toggleSourcePlatform(sourceId, platform, enabled) {
  const sources = readSourcesMeta()
  const index = sources.findIndex(s => s.id === sourceId)
  if (index < 0) throw new Error(`源不存在: ${sourceId}`)

  const supported = sources[index].supportedSources || []
  if (!supported.includes(platform)) throw new Error(`源不支持平台: ${platform}`)

  let enabledSources = sources[index].enabledSources || [...supported]
  if (enabled) {
    if (!enabledSources.includes(platform)) enabledSources.push(platform)
  } else {
    enabledSources = enabledSources.filter(s => s !== platform)
  }

  sources[index].enabledSources = enabledSources
  writeSourcesMeta(sources)

  return sources[index]
}

export async function reloadSources() {
  await userApi.initUserApis()
  return { success: true }
}

export async function getSourceStatus() {
  const sources = readSourcesMeta()
  return sources.map(s => ({
    id: s.id,
    name: s.name,
    enabled: s.enabled,
    status: userApi.getApiStatus(s.id) || { status: 'unknown' },
  }))
}
