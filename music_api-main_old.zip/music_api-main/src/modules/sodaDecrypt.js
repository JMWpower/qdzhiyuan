import crypto from 'crypto'

function bitcount(n) {
  let u = n >>> 0
  u = u - ((u >> 1) & 0x55555555)
  u = (u & 0x33333333) + ((u >> 2) & 0x33333333)
  return ((((u + (u >> 4)) & 0x0F0F0F0F) * 0x01010101) >>> 24)
}

function decodeBase36(c) {
  if (c >= 48 && c <= 57) return c - 48
  if (c >= 97 && c <= 122) return c - 97 + 10
  return 0xFF
}

function decryptSpadeInner(keyBytes) {
  const result = Buffer.alloc(keyBytes.length)
  const buff = Buffer.concat([Buffer.from([0xFA, 0x55]), keyBytes])
  for (let i = 0; i < result.length; i++) {
    let v = (keyBytes[i] ^ buff[i]) - bitcount(i) - 21
    while (v < 0) v += 255
    result[i] = v
  }
  return result
}

function extractKey(playAuth) {
  const bytesData = Buffer.from(playAuth, 'base64')
  if (bytesData.length < 3) throw new Error('auth data too short')

  const paddingLen = ((bytesData[0] ^ bytesData[1] ^ bytesData[2]) - 48)
  if (bytesData.length < paddingLen + 2) throw new Error('invalid padding length')

  const innerInput = bytesData.subarray(1, bytesData.length - paddingLen)
  const tmpBuff = decryptSpadeInner(innerInput)
  if (tmpBuff.length === 0) throw new Error('decryption failed')

  const skipBytes = decodeBase36(tmpBuff[0])
  const endIndex = 1 + (bytesData.length - paddingLen - 2) - skipBytes
  if (endIndex > tmpBuff.length || endIndex < 1) throw new Error('index out of bounds')

  const hexKey = tmpBuff.subarray(1, endIndex).toString('utf8')
  return hexKey
}

function findBox(data, boxType, start, end) {
  if (end > data.length) end = data.length
  const target = Buffer.from(boxType, 'ascii')
  let pos = start
  while (pos + 8 <= end) {
    const size = data.readUInt32BE(pos)
    if (size < 8) break
    if (data[pos + 4] === target[0] && data[pos + 5] === target[1] && data[pos + 6] === target[2] && data[pos + 7] === target[3]) {
      return { offset: pos, size, data: data.subarray(pos + 8, pos + size) }
    }
    pos += size
  }
  return null
}

function parseStsz(data) {
  if (data.length < 12) return []
  const sampleSizeFixed = data.readUInt32BE(4)
  const sampleCount = data.readUInt32BE(8)
  const sizes = new Array(sampleCount)
  if (sampleSizeFixed !== 0) {
    for (let i = 0; i < sampleCount; i++) sizes[i] = sampleSizeFixed
  } else {
    for (let i = 0; i < sampleCount; i++) {
      if (12 + i * 4 + 4 <= data.length) {
        sizes[i] = data.readUInt32BE(12 + i * 4)
      }
    }
  }
  return sizes
}

function parseSenc(data) {
  if (data.length < 8) return []
  const flags = data.readUInt32BE(0) & 0x00FFFFFF
  const sampleCount = data.readUInt32BE(4)
  const ivs = []
  let ptr = 8
  const hasSubsamples = (flags & 0x02) !== 0
  for (let i = 0; i < sampleCount; i++) {
    if (ptr + 8 > data.length) break
    ivs.push(data.subarray(ptr, ptr + 8))
    ptr += 8
    if (hasSubsamples) {
      if (ptr + 2 > data.length) break
      const subCount = data.readUInt16BE(ptr)
      ptr += 2 + (subCount * 6)
    }
  }
  return ivs
}

export function decryptAudio(fileData, playAuth) {
  const hexKey = extractKey(playAuth)
  const keyBytes = Buffer.from(hexKey, 'hex')

  let moov = findBox(fileData, 'moov', 0, fileData.length)
  if (!moov) throw new Error('moov box not found')

  let stbl = findBox(fileData, 'stbl', moov.offset, moov.offset + moov.size)
  if (!stbl) {
    const trak = findBox(fileData, 'trak', moov.offset + 8, moov.offset + moov.size)
    if (trak) {
      const mdia = findBox(fileData, 'mdia', trak.offset + 8, trak.offset + trak.size)
      if (mdia) {
        const minf = findBox(fileData, 'minf', mdia.offset + 8, mdia.offset + mdia.size)
        if (minf) {
          stbl = findBox(fileData, 'stbl', minf.offset + 8, minf.offset + minf.size)
        }
      }
    }
  }
  if (!stbl) throw new Error('stbl box not found')

  const stsz = findBox(fileData, 'stsz', stbl.offset + 8, stbl.offset + stbl.size)
  if (!stsz) throw new Error('stsz box not found')
  const sampleSizes = parseStsz(stsz.data)

  let senc = findBox(fileData, 'senc', moov.offset + 8, moov.offset + moov.size)
  if (!senc) {
    senc = findBox(fileData, 'senc', stbl.offset + 8, stbl.offset + stbl.size)
  }
  if (!senc) throw new Error('senc box not found')
  const ivs = parseSenc(senc.data)

  const mdat = findBox(fileData, 'mdat', 0, fileData.length)
  if (!mdat) throw new Error('mdat box not found')

  const aesMode = keyBytes.length === 16 ? 'aes-128-ctr' : 'aes-256-ctr'

  const decryptedData = Buffer.from(fileData)

  let readPtr = mdat.offset + 8
  const decryptedMdatParts = []

  for (let i = 0; i < sampleSizes.length; i++) {
    const size = sampleSizes[i]
    if (readPtr + size > decryptedData.length) break
    const chunk = decryptedData.subarray(readPtr, readPtr + size)

    if (i < ivs.length) {
      const iv = ivs[i]
      const paddedIv = Buffer.alloc(16)
      iv.copy(paddedIv)
      const stream = crypto.createDecipheriv(aesMode, keyBytes, paddedIv)
      const decrypted = Buffer.concat([stream.update(chunk), stream.final()])
      decryptedMdatParts.push(decrypted)
    } else {
      decryptedMdatParts.push(chunk)
    }
    readPtr += size
  }

  const decryptedMdat = Buffer.concat(decryptedMdatParts)
  if (decryptedMdat.length === mdat.size - 8) {
    decryptedMdat.copy(decryptedData, mdat.offset + 8)
  } else {
    throw new Error('decrypted size mismatch')
  }

  const stsd = findBox(fileData, 'stsd', stbl.offset + 8, stbl.offset + stbl.size)
  if (stsd) {
    const stsdOffset = stsd.offset
    const stsdData = decryptedData.subarray(stsdOffset, stsdOffset + stsd.size)
    const encaIdx = stsdData.indexOf(Buffer.from('enca', 'ascii'))
    if (encaIdx !== -1) {
      stsdData.write('mp4a', encaIdx, 4, 'ascii')
    }
  }

  return decryptedData
}
