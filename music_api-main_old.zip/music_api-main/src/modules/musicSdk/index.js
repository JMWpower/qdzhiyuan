import kw from './kw/index.js'
import kg from './kg/index.js'
import tx from './tx/index.js'
import wy from './wy/index.js'
import mg from './mg/index.js'
import qs from './qs/index.js'
import { supportQuality } from './api-source.js'
export { dateFormat, dateFormat2, decodeName, sizeFormate, formatPlayTime, formatPlayCount } from '../../utils.js'


const sources = {
  sources: [
    { name: '酷我音乐', id: 'kw' },
    { name: '酷狗音乐', id: 'kg' },
    { name: 'QQ音乐', id: 'tx' },
    { name: '网易音乐', id: 'wy' },
    { name: '咪咕音乐', id: 'mg' },
    { name: '虾米音乐', id: 'xm' },
    { name: '汽水音乐', id: 'qs' },
  ],
  kw,
  kg,
  tx,
  wy,
  mg,
  qs,
}
export default {
  ...sources,
  init() {
    const tasks = []
    for (let source of sources.sources) {
      let sm = sources[source.id]
      sm && sm.init && tasks.push(sm.init())
    }
    return Promise.all(tasks)
  },
  supportQuality,
}
