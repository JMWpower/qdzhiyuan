import apiSourceInfo from './api-source-info.js'
import { createRequire } from 'module'

const require = createRequire(import.meta.url)
const userApi = require('../userApi.cjs')

const supportQuality = {}

for (const api of apiSourceInfo) {
  supportQuality[api.id] = api.supportQualitys
}

supportQuality['qs'] = ['128k', '320k', 'flac', 'flac24bit']

const getUserApis = () => {
  const loadedApis = userApi.getLoadedApis ? userApi.getLoadedApis() : []
  const apis = {}

  for (const apiInfo of loadedApis) {
    if (!apiInfo.enabled || !apiInfo.sources) continue
    for (const source of Object.keys(apiInfo.sources)) {
      apis[source] = {
        getMusicUrl: (songInfo, type) => {
          return userApi.callUserApiGetMusicUrl(source, songInfo, type)
        },
      }
    }
  }

  return apis
}

const apis = source => {
  const userApis = getUserApis()
  if (userApis[source]) {
    return userApis[source]
  }
  throw new Error(`未找到支持 ${source} 平台的自定义源，请在设置中添加或启用相关源`)
}

export { apis, supportQuality }
