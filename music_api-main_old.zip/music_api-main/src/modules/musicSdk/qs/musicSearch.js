import { httpFetch } from '../../../request.js'
import { sizeFormate, formatPlayTime } from '../../../utils.js'
import { formatSingerName } from '../utils.js'

const defaultSearchParams = {
  aid: '386088',
  app_name: 'luna_pc',
  region: 'cn',
  geo_region: 'cn',
  os_region: 'cn',
  sim_region: '',
  device_id: '1088932190113307',
  cdid: '',
  iid: '2332504177791808',
  version_name: '3.0.0',
  version_code: '30000000',
  channel: 'official',
  build_mode: 'master',
  network_carrier: '',
  ac: 'wifi',
  tz_name: 'Asia/Shanghai',
  resolution: '',
  device_platform: 'windows',
  device_type: 'Windows',
  os_version: 'Windows 11 Home China',
  fp: '1088932190113307',
  search_method: 'input',
  debug_params: '',
  search_scene: '',
}

const defaultHeaders = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
  Referer: 'https://music.douyin.com/',
  Cookie: 'odin_tt=1; ttwid=1',
}

function safeGet(obj, path, defaultValue = null) {
  if (!obj || typeof obj !== 'object') return defaultValue
  let current = obj
  for (const key of path) {
    if (current == null || typeof current !== 'object') return defaultValue
    current = current[key]
  }
  return current != null ? current : defaultValue
}

export default {
  limit: 20,
  total: 0,
  page: 0,
  allPage: 1,

  musicSearch(keyword, page, limit) {
    const cursor = (page - 1) * limit
    const params = {
      ...defaultSearchParams,
      q: keyword,
      cursor,
      search_id: `${Date.now()}-${Math.random().toString(36).substring(2, 10)}`,
      from_search_id: `${Date.now()}-${Math.random().toString(36).substring(2, 10)}`,
    }
    const queryString = Object.entries(params)
      .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
      .join('&')

    const requestObj = httpFetch(`https://api.qishui.com/luna/pc/search/track?${queryString}`, {
      headers: defaultHeaders,
    })
    return requestObj.promise.then(({ body }) => body)
  },

  handleResult(rawList) {
    if (!rawList || !Array.isArray(rawList)) return []
    const list = []
    const ids = new Set()

    for (const item of rawList) {
      const track = safeGet(item, ['entity', 'track'])
      if (!track || !track.id || ids.has(track.id)) continue
      ids.add(track.id)

      const artists = safeGet(item, ['entity', 'track', 'artists'], [])
      const album = safeGet(item, ['entity', 'track', 'album'], {})
      const coverUrls = safeGet(album, ['url_cover', 'urls'], [])
      const coverUri = safeGet(album, ['url_cover', 'uri'], '')
      let img = ''
      if (coverUrls && coverUrls.length > 0) {
        img = String(coverUrls[0]) + String(coverUri) + '~c5_375x375.jpg'
      }

      const types = []
      const _types = {}

      list.push({
        singer: formatSingerName(artists, 'name'),
        name: track.name || '',
        albumName: album.name || '',
        albumId: album.id || '',
        songmid: String(track.id),
        source: 'qs',
        interval: track.duration ? formatPlayTime(track.duration / 1000) : null,
        img,
        lrc: null,
        types,
        _types,
        typeUrl: {},
        duration: track.duration || 0,
      })
    }
    return list
  },

  search(keyword, page = 1, limit, retryNum = 0) {
    if (++retryNum > 3) return Promise.reject(new Error('try max num'))
    if (limit == null) limit = this.limit
    limit = Math.min(limit, 20)

    return this.musicSearch(keyword, page, limit).then(result => {
      if (!result) return Promise.reject(new Error('搜索失败'))

      const statusInfo = result.status_info || {}
      const data = safeGet(result, ['result_groups', 0, 'data'], [])
      let list = this.handleResult(data)

      if (list == null) return this.search(keyword, page, limit, retryNum)

      const total = safeGet(result, ['result_groups', 0, 'total'], 0) || list.length
      this.total = total
      this.page = page
      this.allPage = Math.ceil(this.total / limit)

      return {
        list,
        allPage: this.allPage,
        limit,
        total: this.total,
        source: 'qs',
      }
    })
  },
}
