export default {
  list: [],
  async getBoards() {
    return { list: [], source: 'qs' }
  },
  async getList() {
    return { list: [], total: 0, limit: 0, page: 1, source: 'qs' }
  },
  getDetailPageUrl() {
    return null
  },
}
