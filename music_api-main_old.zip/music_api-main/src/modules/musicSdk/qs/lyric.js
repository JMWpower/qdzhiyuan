import { httpFetch } from '../../../request.js'

const defaultHeaders = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
  Referer: 'https://music.douyin.com/',
  Cookie: 'odin_tt=1; ttwid=1',
}

export default async (songmid) => {
  const { body } = await httpFetch(`https://music.douyin.com/qishui/share/track?track_id=${songmid}`, {
    headers: defaultHeaders,
  }).promise

  if (!body || typeof body !== 'string') throw new Error('获取歌词页面失败')

  const routerDataMatch = body.match(/_ROUTER_DATA\s*=\s*({[\s\S]*?});/)
  if (!routerDataMatch) throw new Error('未找到歌词数据')

  let routerData
  try {
    routerData = JSON.parse(routerDataMatch[1].trim())
  } catch (e) {
    throw new Error('歌词数据解析失败')
  }

  const sentences = routerData?.loaderData?.track_page?.audioWithLyricsOption?.lyrics?.sentences
  if (!sentences || !Array.isArray(sentences)) {
    throw new Error('未找到歌词内容')
  }

  const lrcLines = []
  const lxlrcLines = []

  for (const sentence of sentences) {
    if (!sentence || typeof sentence !== 'object') continue
    const startMs = sentence.startMs || 0
    const words = sentence.words || []
    const text = words.filter(w => w && typeof w === 'object').map(w => w.text || '').join('')

    const minutes = Math.floor(startMs / 60000)
    const seconds = Math.floor((startMs % 60000) / 1000)
    const mSeconds = startMs % 1000
    const timeTag = `[${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${String(mSeconds).padStart(3, '0')}]`

    lrcLines.push(`${timeTag}${text}`)

    if (words.length > 0 && words.every(w => w && typeof w === 'object' && w.startMs != null)) {
      const wordTags = []
      for (const word of words) {
        const wordStart = Math.max((word.startMs || 0) - startMs, 0)
        const wordDur = word.durationMs || 0
        wordTags.push(`<${wordStart},${wordDur}>${word.text || ''}`)
      }
      lxlrcLines.push(`${timeTag}${wordTags.join('')}`)
    }
  }

  return {
    lyric: lrcLines.join('\n'),
    lxlyric: lxlrcLines.join('\n'),
    tlyric: '',
    rlyric: '',
  }
}
