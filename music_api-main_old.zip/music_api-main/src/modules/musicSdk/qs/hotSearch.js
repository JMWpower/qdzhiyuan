export default {
  _requestObj: null,
  async getList() {
    return { source: 'qs', list: [] }
  },
}
