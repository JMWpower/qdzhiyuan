import { httpFetch } from '../../../request.js'
import { sizeFormate, formatPlayTime } from '../../../utils.js'
import { formatSingerName } from '../utils.js'

const defaultHeaders = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
  Referer: 'https://music.douyin.com/',
  Cookie: 'odin_tt=1; ttwid=1',
}

const mobileHeaders = {
  'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
  Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
}

function safeGet(obj, path, defaultValue = null) {
  if (!obj || typeof obj !== 'object') return defaultValue
  let current = obj
  for (const key of path) {
    if (current == null || typeof current !== 'object') return defaultValue
    current = current[key]
  }
  return current != null ? current : defaultValue
}

const qualityMap = {
  '128k': { bitrate: 128000, label: '标准' },
  '320k': { bitrate: 320000, label: '高品' },
  'flac': { bitrate: 999000, label: '无损' },
  'flac24bit': { bitrate: 1999000, label: 'Hi-Res' },
}

function rankAudioList(playInfoList) {
  if (!Array.isArray(playInfoList)) return []
  return [...playInfoList].sort((a, b) => {
    const sizeA = a.Size || 0
    const sizeB = b.Size || 0
    const brA = a.Bitrate || 0
    const brB = b.Bitrate || 0
    return (sizeB - sizeA) || (brB - brA)
  })
}

function getQualityType(audioInfo) {
  const bitrate = audioInfo.Bitrate || 0
  const format = (audioInfo.Format || '').toLowerCase()
  if (bitrate > 1000000 || format === 'flac' && bitrate > 800000) return 'flac24bit'
  if (bitrate > 800000 || format === 'flac') return 'flac'
  if (bitrate > 200000) return '320k'
  return '128k'
}

export default {
  async getMusicUrl(songmid, quality = '128k') {
    // 方法1: 通过移动端 share/track 页面获取播放链接 (参考 soda.py)
    try {
      const shareResp = await httpFetch(`https://music.douyin.com/qishui/share/track?track_id=${songmid}`, {
        headers: mobileHeaders,
      }).promise

      const html = shareResp.body
      if (typeof html === 'string') {
        const match = html.match(/_ROUTER_DATA\s*=\s*({.*?});/s)
        if (match) {
          const pageData = JSON.parse(match[1])
          const audioOption = safeGet(pageData, ['loaderData', 'track_page', 'audioWithLyricsOption'])
          if (audioOption && audioOption.url) {
            const originalUrl = audioOption.url
              .replace(/\\u002F/g, '/')
              .replace(/%7C/g, '|')
              .replace(/%3D/g, '=')
            const format = 'm4a'
            const proxyUrl = `/api/music/audio-proxy/${format}?url=${encodeURIComponent(originalUrl)}`

            return {
              url: proxyUrl,
              originalUrl,
              type: quality,
              quality,
              format,
              bitrate: 0,
              size: 0,
              duration: audioOption.duration || 0,
              playAuth: '',
            }
          }
        }
      }
    } catch (e) { }

    // 方法2: 通过 track_v2 API 获取播放链接 (备用)
    const trackResp = await httpFetch(`https://api.qishui.com/luna/pc/track_v2?track_id=${songmid}&media_type=track&queue_type=`, {
      headers: defaultHeaders,
    }).promise

    const trackData = trackResp.body
    if (!trackData || !trackData.track_player) {
      throw new Error('获取歌曲信息失败')
    }

    const urlPlayerInfo = trackData.track_player.url_player_info
    if (!urlPlayerInfo) {
      throw new Error('获取播放链接失败: 缺少 url_player_info')
    }

    const playerResp = await httpFetch(urlPlayerInfo, {
      headers: defaultHeaders,
    }).promise

    const playerData = playerResp.body
    const playInfoList = safeGet(playerData, ['Result', 'Data', 'PlayInfoList'], [])
    const validAudios = rankAudioList(playInfoList).filter(a => a.MainPlayUrl || a.BackupPlayUrl)

    if (validAudios.length === 0) {
      throw new Error('未找到可用的播放链接')
    }

    const targetQuality = qualityMap[quality] || qualityMap['128k']
    let selectedAudio = null

    for (const audio of validAudios) {
      const audioType = getQualityType(audio)
      if (audioType === quality) {
        selectedAudio = audio
        break
      }
    }

    if (!selectedAudio) {
      if (quality === '128k' || quality === '320k') {
        selectedAudio = validAudios.find(a => getQualityType(a) === '128k') || validAudios[validAudios.length - 1]
      } else {
        selectedAudio = validAudios[0]
      }
    }

    const originalUrl = selectedAudio.MainPlayUrl || selectedAudio.BackupPlayUrl
    const playAuth = safeGet(selectedAudio, ['PlayAuth'], '')
    const audioType = getQualityType(selectedAudio)

    const format = (selectedAudio.Format || 'm4a').toLowerCase()
    const proxyUrl = `/api/music/audio-proxy/${format}?url=${encodeURIComponent(originalUrl)}&playAuth=${encodeURIComponent(playAuth)}`

    return {
      url: proxyUrl,
      originalUrl,
      type: audioType,
      quality: audioType,
      format: selectedAudio.Format || 'm4a',
      bitrate: selectedAudio.Bitrate || 0,
      size: selectedAudio.Size || 0,
      sizeStr: sizeFormate(selectedAudio.Size || 0),
      duration: selectedAudio.Duration || 0,
      playAuth,
    }
  },

  async getMusicDetail(songmid) {
    const trackResp = await httpFetch(`https://api.qishui.com/luna/pc/track_v2?track_id=${songmid}&media_type=track&queue_type=`, {
      headers: defaultHeaders,
    }).promise

    const trackData = trackResp.body
    if (!trackData || !trackData.track_player) {
      throw new Error('获取歌曲详情失败')
    }

    const trackInfo = trackData.track || {}
    const artists = trackInfo.artists || []
    const album = trackInfo.album || {}
    const coverUrls = safeGet(album, ['url_cover', 'urls'], [])
    const coverUri = safeGet(album, ['url_cover', 'uri'], '')
    let img = ''
    if (coverUrls && coverUrls.length > 0) {
      img = String(coverUrls[0]) + String(coverUri) + '~c5_375x375.jpg'
    }

    const types = []
    const _types = {}

    const urlPlayerInfo = safeGet(trackData, ['track_player', 'url_player_info'])
    if (urlPlayerInfo) {
      try {
        const playerResp = await httpFetch(urlPlayerInfo, { headers: defaultHeaders }).promise
        const playerData = playerResp.body
        const playInfoList = safeGet(playerData, ['Result', 'Data', 'PlayInfoList'], [])
        for (const audio of playInfoList) {
          if (!audio.MainPlayUrl && !audio.BackupPlayUrl) continue
          const qType = getQualityType(audio)
          const size = sizeFormate(audio.Size || 0)
          if (!_types[qType]) {
            types.push({ type: qType, size })
            _types[qType] = { size }
          }
        }
      } catch (e) { }
    }

    return {
      singer: formatSingerName(artists, 'name'),
      name: trackInfo.name || '',
      albumName: album.name || '',
      albumId: album.id || '',
      songmid: String(trackInfo.id || songmid),
      source: 'qs',
      interval: trackInfo.duration ? formatPlayTime(trackInfo.duration / 1000) : null,
      img,
      lrc: null,
      types,
      _types,
      typeUrl: {},
    }
  },
}
