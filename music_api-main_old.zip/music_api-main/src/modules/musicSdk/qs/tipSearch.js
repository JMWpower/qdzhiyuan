export default {
  async search() {
    return []
  },
}
